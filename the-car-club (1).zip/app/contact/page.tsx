import React from 'react';
import { ContactRoute } from '@/components/routes/ContactRoute';
import { PublicLayout } from '@/components/public/public-layout';

export default function ContactPage() {
  return (
    <PublicLayout currentPath="/contact" onNavigate={() => {}}>
      <ContactRoute onNavigate={() => {}} />
    </PublicLayout>
  );
}
