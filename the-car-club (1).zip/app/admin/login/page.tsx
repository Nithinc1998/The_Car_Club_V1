import React from 'react';
import { AdminLoginRoute } from '@/components/routes/admin/AdminLoginRoute';

export default function AdminLoginPage() {
  return <AdminLoginRoute onNavigate={() => {}} />;
}
