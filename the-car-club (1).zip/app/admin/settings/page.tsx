import React from 'react';
import { AdminLayout } from '@/components/admin/admin-layout';
import { AdminSettingsRoute } from '@/components/routes/admin/AdminSettingsRoute';

export default function AdminSettingsPage() {
  return (
    <AdminLayout title="Dealership Settings" currentPath="/admin/settings" onNavigate={() => {}}>
      <AdminSettingsRoute onNavigate={() => {}} />
    </AdminLayout>
  );
}
