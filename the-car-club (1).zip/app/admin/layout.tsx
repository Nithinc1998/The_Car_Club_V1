import React from 'react';
import { AuthProvider } from '@/lib/auth';

export default function AdminAppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <AuthProvider>{children}</AuthProvider>;
}
