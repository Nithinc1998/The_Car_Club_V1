import React from 'react';
import { AdminLayout } from '@/components/admin/admin-layout';
import { AdminDashboardRoute } from '@/components/routes/admin/AdminDashboardRoute';

export default function AdminDashboardPage() {
  return (
    <AdminLayout title="Operations Dashboard" currentPath="/admin" onNavigate={() => {}}>
      <AdminDashboardRoute onNavigate={() => {}} />
    </AdminLayout>
  );
}
