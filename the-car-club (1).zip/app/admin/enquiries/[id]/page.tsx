import React from 'react';
import { AdminLayout } from '@/components/admin/admin-layout';
import { AdminEnquiryDetailRoute } from '@/components/routes/admin/AdminEnquiryDetailRoute';

export default function AdminEnquiryDetailPage({ params }: { params: { id: string } }) {
  return (
    <AdminLayout title="Enquiry Detail" currentPath={`/admin/enquiries/${params?.id || ''}`} onNavigate={() => {}}>
      <AdminEnquiryDetailRoute id={params?.id || ''} onNavigate={() => {}} />
    </AdminLayout>
  );
}
