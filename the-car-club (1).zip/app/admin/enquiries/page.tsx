import React from 'react';
import { AdminLayout } from '@/components/admin/admin-layout';
import { AdminEnquiriesRoute } from '@/components/routes/admin/AdminEnquiriesRoute';

export default function AdminEnquiriesPage() {
  return (
    <AdminLayout title="Customer Enquiries" currentPath="/admin/enquiries" onNavigate={() => {}}>
      <AdminEnquiriesRoute onNavigate={() => {}} />
    </AdminLayout>
  );
}
