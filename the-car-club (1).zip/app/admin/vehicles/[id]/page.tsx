import React from 'react';
import { AdminLayout } from '@/components/admin/admin-layout';
import { AdminVehicleDetailRoute } from '@/components/routes/admin/AdminVehicleDetailRoute';

export default function AdminVehicleDetailPage({ params }: { params: { id: string } }) {
  return (
    <AdminLayout title="Vehicle Record" currentPath={`/admin/vehicles/${params?.id || ''}`} onNavigate={() => {}}>
      <AdminVehicleDetailRoute id={params?.id || ''} onNavigate={() => {}} />
    </AdminLayout>
  );
}
