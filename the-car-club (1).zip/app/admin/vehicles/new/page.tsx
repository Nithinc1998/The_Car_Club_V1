import React from 'react';
import { AdminLayout } from '@/components/admin/admin-layout';
import { AdminNewVehicleRoute } from '@/components/routes/admin/AdminNewVehicleRoute';

export default function AdminNewVehiclePage() {
  return (
    <AdminLayout title="New Vehicle Intake" currentPath="/admin/vehicles/new" onNavigate={() => {}}>
      <AdminNewVehicleRoute onNavigate={() => {}} />
    </AdminLayout>
  );
}
