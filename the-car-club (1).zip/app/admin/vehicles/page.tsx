import React from 'react';
import { AdminLayout } from '@/components/admin/admin-layout';
import { AdminVehiclesRoute } from '@/components/routes/admin/AdminVehiclesRoute';

export default function AdminVehiclesPage() {
  return (
    <AdminLayout title="Vehicle Inventory" currentPath="/admin/vehicles" onNavigate={() => {}}>
      <AdminVehiclesRoute onNavigate={() => {}} />
    </AdminLayout>
  );
}
