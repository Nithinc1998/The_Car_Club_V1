import React from 'react';
import { CarsRoute } from '@/components/routes/CarsRoute';
import { PublicLayout } from '@/components/public/public-layout';

export default function CarsPage() {
  return (
    <PublicLayout currentPath="/cars" onNavigate={() => {}}>
      <CarsRoute onNavigate={() => {}} />
    </PublicLayout>
  );
}
