import React from 'react';
import { CarDetailRoute } from '@/components/routes/CarDetailRoute';
import { PublicLayout } from '@/components/public/public-layout';

export default function CarDetailPage({ params }: { params: { slug: string } }) {
  return (
    <PublicLayout currentPath={`/cars/${params?.slug || ''}`} onNavigate={() => {}}>
      <CarDetailRoute slug={params?.slug || ''} onNavigate={() => {}} />
    </PublicLayout>
  );
}
