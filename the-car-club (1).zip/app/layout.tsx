import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'The Car Club',
  description: 'A modern, minimal, premium automotive platform for curated vehicle presentation and customer enquiries.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-[#F7F7F5] text-[#111111] antialiased">
        {children}
      </body>
    </html>
  );
}
