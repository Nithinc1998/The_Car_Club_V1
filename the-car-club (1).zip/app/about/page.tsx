import React from 'react';
import { AboutRoute } from '@/components/routes/AboutRoute';
import { PublicLayout } from '@/components/public/public-layout';

export default function AboutPage() {
  return (
    <PublicLayout currentPath="/about" onNavigate={() => {}}>
      <AboutRoute onNavigate={() => {}} />
    </PublicLayout>
  );
}
