import React from 'react';
import { HomeRoute } from '@/components/routes/HomeRoute';
import { PublicLayout } from '@/components/public/public-layout';

export default function HomePage() {
  return (
    <PublicLayout currentPath="/" onNavigate={() => {}}>
      <HomeRoute onNavigate={() => {}} />
    </PublicLayout>
  );
}
