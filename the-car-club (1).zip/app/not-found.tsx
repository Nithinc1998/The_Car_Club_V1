import React from 'react';
import { NotFoundRoute } from '@/components/routes/NotFoundRoute';
import { PublicLayout } from '@/components/public/public-layout';

export default function NotFound() {
  return (
    <PublicLayout currentPath="/404" onNavigate={() => {}}>
      <NotFoundRoute currentPath="/404" onNavigate={() => {}} />
    </PublicLayout>
  );
}
