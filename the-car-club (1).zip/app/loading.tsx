import { LoadingState } from '@/components/routes/LoadingState';

export default function Loading() {
  return <LoadingState />;
}
