'use client';

import React from 'react';
import { ErrorState } from '@/components/routes/ErrorState';

export default function ErrorPage({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return <ErrorState error={error} onRetry={reset} />;
}
