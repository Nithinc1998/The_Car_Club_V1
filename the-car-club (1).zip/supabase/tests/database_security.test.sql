-- THE CAR CLUB — PHASE 12: DATABASE POLICY TESTS
-- Test Suite: supabase/tests/database_security.test.sql
-- Format: pgTAP database test suite for Supabase local testing and verification.

BEGIN;
SELECT plan(25);

-- 1. TEST SCHEMA & ENUMS EXISTENCE
SELECT has_type('public', 'vehicle_fuel_type', 'Enum vehicle_fuel_type exists');
SELECT has_type('public', 'vehicle_transmission', 'Enum vehicle_transmission exists');
SELECT has_type('public', 'vehicle_status', 'Enum vehicle_status exists');
SELECT has_type('public', 'profile_role', 'Enum profile_role exists');

-- 2. TEST DOMAIN TABLES EXISTENCE
SELECT has_table('public', 'profiles', 'Table profiles exists');
SELECT has_table('public', 'settings', 'Table settings exists');
SELECT has_table('public', 'vehicles', 'Table vehicles exists');
SELECT has_table('public', 'vehicle_media', 'Table vehicle_media exists');
SELECT has_table('public', 'vehicle_events', 'Table vehicle_events exists');
SELECT has_table('public', 'enquiries', 'Table enquiries exists');

-- 3. TEST RLS IS ENABLED ON ALL TABLES
SELECT tests.rls_enabled('public', 'profiles');
SELECT tests.rls_enabled('public', 'settings');
SELECT tests.rls_enabled('public', 'vehicles');
SELECT tests.rls_enabled('public', 'vehicle_media');
SELECT tests.rls_enabled('public', 'vehicle_events');
SELECT tests.rls_enabled('public', 'enquiries');

-- 4. TEST SECURITY DEFINER HELPER
SELECT has_function('public', 'is_admin', 'Helper is_admin exists');
SELECT is_definer('public', 'is_admin', 'Helper is_admin is SECURITY DEFINER');
SELECT has_function('public', 'initialize_first_admin', Array['text'], 'Helper initialize_first_admin exists');
SELECT is_definer('public', 'initialize_first_admin', Array['text'], 'Helper initialize_first_admin is SECURITY DEFINER');
SELECT has_function('public', 'count_admin_profiles', 'Helper count_admin_profiles exists');

-- 5. TEST VIEWS AND STORAGE
SELECT has_view('public', 'public_vehicles', 'View public_vehicles exists');

-- 6. TEST SEQUENCES
SELECT has_sequence('public', 'vehicle_stock_id_seq', 'Sequence vehicle_stock_id_seq exists');

-- 7. TEST SINGLETON CONSTRAINT ON SETTINGS
-- Attempting to insert a second settings row must fail due to unique constraint
PREPARE insert_second_settings AS
  INSERT INTO public.settings (is_singleton, dealership_name) VALUES (true, 'Unauthorized Second Dealership');
SELECT throws_ok(
  'insert_second_settings',
  '23505', -- unique_violation
  NULL,
  'Settings table guarantees singleton by rejecting secondary records'
);

-- 8. TEST PUBLISHING INTEGRITY TRIGGER
-- A vehicle cannot be published without an image in vehicle_media
PREPARE insert_published_without_image AS
  INSERT INTO public.vehicles (
    stock_id, slug, make, model, manufacturing_year,
    fuel_type, transmission, kilometers, owners, asking_price,
    is_published, status
  ) VALUES (
    'TCC-TEST1', 'test-slug', 'Porsche', '911', 2023,
    'PETROL', 'MANUAL', 1000, 1, 150000,
    true, 'AVAILABLE'
  );
SELECT throws_ok(
  'insert_published_without_image',
  NULL,
  NULL,
  'Publishing integrity rejects vehicle publication if no IMAGE exists in vehicle_media'
);

SELECT * FROM finish();
ROLLBACK;
