-- THE CAR CLUB: FULL PRODUCTION MIGRATIONS (00001 - 00012)
-- Consolidated safe deployment for Supabase
-- All destructive DROP TABLE statements removed
-- Storage.objects ownership preserved



-- ==========================================
-- MIGRATION: 00001_initial_schema.sql
-- ==========================================

-- THE CAR CLUB — DATABASE SCHEMA FOUNDATION
-- Migration: 00001_initial_schema.sql
-- Description: Core extensions and foundational database configuration.

-- Enable required extensions for cryptographic functions and UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";


-- ==========================================
-- MIGRATION: 00002_create_enums.sql
-- ==========================================

-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00002_create_enums.sql
-- Description: Create PostgreSQL enums for automotive attributes, lifecycle states, enquiries, and roles.

-- 1. VEHICLE FUEL TYPE
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'vehicle_fuel_type') THEN
    CREATE TYPE public.vehicle_fuel_type AS ENUM (
      'PETROL',
      'DIESEL',
      'CNG',
      'ELECTRIC',
      'HYBRID',
      'OTHER'
    );
  END IF;
END $$;

-- 2. VEHICLE TRANSMISSION
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'vehicle_transmission') THEN
    CREATE TYPE public.vehicle_transmission AS ENUM (
      'MANUAL',
      'AUTOMATIC',
      'AMT',
      'CVT',
      'DCT',
      'IMT',
      'OTHER'
    );
  END IF;
END $$;

-- 3. VEHICLE CONDITION
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'vehicle_condition') THEN
    CREATE TYPE public.vehicle_condition AS ENUM (
      'EXCELLENT',
      'GOOD',
      'FAIR'
    );
  END IF;
END $$;

-- 4. SERVICE HISTORY STATUS
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'service_history_status') THEN
    CREATE TYPE public.service_history_status AS ENUM (
      'FULL',
      'PARTIAL',
      'NOT_AVAILABLE',
      'UNKNOWN'
    );
  END IF;
END $$;

-- 5. REGISTRATION CERTIFICATE (RC) STATUS
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'rc_status') THEN
    CREATE TYPE public.rc_status AS ENUM (
      'AVAILABLE',
      'TRANSFER_PENDING',
      'TRANSFERRED',
      'NOT_AVAILABLE',
      'OTHER'
    );
  END IF;
END $$;

-- 6. VEHICLE STATUS
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'vehicle_status') THEN
    CREATE TYPE public.vehicle_status AS ENUM (
      'DRAFT',
      'AVAILABLE',
      'RESERVED',
      'SOLD',
      'ARCHIVED'
    );
  END IF;
END $$;

-- 7. VEHICLE MEDIA TYPE
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'vehicle_media_type') THEN
    CREATE TYPE public.vehicle_media_type AS ENUM (
      'IMAGE',
      'VIDEO'
    );
  END IF;
END $$;

-- 8. VEHICLE EVENT TYPE
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'vehicle_event_type') THEN
    CREATE TYPE public.vehicle_event_type AS ENUM (
      'ACQUIRED',
      'INSPECTION',
      'PRICING_UPDATED',
      'PUBLISHED',
      'UNPUBLISHED',
      'RESERVED',
      'RESERVATION_CANCELLED',
      'SOLD',
      'ARCHIVED',
      'NOTE'
    );
  END IF;
END $$;

-- 9. ENQUIRY TYPE
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'enquiry_type') THEN
    CREATE TYPE public.enquiry_type AS ENUM (
      'VEHICLE',
      'TEST_DRIVE',
      'CALLBACK',
      'OFFER',
      'GENERAL'
    );
  END IF;
END $$;

-- 10. ENQUIRY STATUS
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'enquiry_status') THEN
    CREATE TYPE public.enquiry_status AS ENUM (
      'NEW',
      'CONTACTED',
      'FOLLOW_UP',
      'CONVERTED',
      'CLOSED'
    );
  END IF;
END $$;

-- 11. ENQUIRY SOURCE
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'enquiry_source') THEN
    CREATE TYPE public.enquiry_source AS ENUM (
      'WEBSITE',
      'WHATSAPP',
      'PHONE',
      'INSTAGRAM',
      'FACEBOOK',
      'GOOGLE',
      'OTHER'
    );
  END IF;
END $$;

-- 12. PROFILE ROLE
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'profile_role') THEN
    CREATE TYPE public.profile_role AS ENUM (
      'ADMIN'
    );
  END IF;
END $$;


-- ==========================================
-- MIGRATION: 00003_create_profiles.sql
-- ==========================================

-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00003_create_profiles.sql
-- Description: Create profiles table linked to auth.users and updated_at automation.

-- Universal updated_at timestamp trigger function
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = ''
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- PROFILES TABLE
-- Stores staff profile metadata. Note: No auto-assignment trigger is created to prevent unauthorized administrator creation.
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  role public.profile_role NOT NULL DEFAULT 'ADMIN',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- updated_at trigger for profiles
DROP TRIGGER IF EXISTS set_profiles_updated_at ON public.profiles;
CREATE TRIGGER set_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();


-- ==========================================
-- MIGRATION: 00004_create_settings.sql
-- ==========================================

-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00004_create_settings.sql
-- Description: Create singleton settings table for platform metadata, concierge contacts, and operating hours.

CREATE TABLE IF NOT EXISTS public.settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  is_singleton BOOLEAN NOT NULL DEFAULT true CHECK (is_singleton = true) UNIQUE,
  dealership_name TEXT NOT NULL,
  phone TEXT,
  whatsapp_number TEXT,
  email TEXT,
  address TEXT,
  city TEXT,
  district TEXT,
  state TEXT,
  pincode TEXT,
  opening_hours TEXT,
  google_maps_url TEXT,
  instagram_url TEXT,
  facebook_url TEXT,
  youtube_url TEXT,
  logo_url TEXT,
  favicon_url TEXT,
  site_title TEXT,
  meta_description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- updated_at trigger for settings
DROP TRIGGER IF EXISTS set_settings_updated_at ON public.settings;
CREATE TRIGGER set_settings_updated_at
  BEFORE UPDATE ON public.settings
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- Insert initial baseline singleton configuration record
INSERT INTO public.settings (
  is_singleton,
  dealership_name,
  site_title,
  meta_description
)
VALUES (
  true,
  'The Car Club',
  'The Car Club',
  'A modern, minimal, premium automotive platform for curated vehicle presentation and customer enquiries.'
)
ON CONFLICT (is_singleton) DO NOTHING;


-- ==========================================
-- MIGRATION: 00005_create_vehicles.sql
-- ==========================================

-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00005_create_vehicles.sql
-- Description: Create vehicles table with concurrency-safe stock ID sequence and constraints.

-- 1. CONCURRENCY-SAFE STOCK ID SEQUENCE
CREATE SEQUENCE IF NOT EXISTS public.vehicle_stock_id_seq
  START WITH 1
  INCREMENT BY 1
  MINVALUE 1;

-- 2. STOCK ID AUTO-GENERATION FUNCTION
CREATE OR REPLACE FUNCTION public.generate_vehicle_stock_id()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.stock_id IS NULL OR trim(NEW.stock_id) = '' THEN
    NEW.stock_id := 'TCC-' || lpad(nextval('public.vehicle_stock_id_seq')::text, 5, '0');
  END IF;
  RETURN NEW;
END;
$$;

-- 3. VEHICLES TABLE
CREATE TABLE IF NOT EXISTS public.vehicles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stock_id TEXT NOT NULL UNIQUE,
  registration_number TEXT,
  make TEXT NOT NULL,
  model TEXT NOT NULL,
  variant TEXT,
  slug TEXT NOT NULL UNIQUE,
  manufacturing_year INTEGER NOT NULL,
  registration_year INTEGER,
  fuel_type public.vehicle_fuel_type NOT NULL,
  transmission public.vehicle_transmission NOT NULL,
  kilometers INTEGER NOT NULL,
  owners INTEGER NOT NULL,
  color TEXT,
  asking_price NUMERIC(12, 2) NOT NULL,
  purchase_price NUMERIC(12, 2),
  condition public.vehicle_condition,
  condition_notes TEXT,
  service_history public.service_history_status,
  service_history_notes TEXT,
  inspection_notes TEXT,
  features JSONB NOT NULL DEFAULT '[]'::jsonb,
  accessories JSONB NOT NULL DEFAULT '[]'::jsonb,
  short_description TEXT,
  description TEXT,
  status public.vehicle_status NOT NULL DEFAULT 'DRAFT',
  is_published BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Integrity Constraints
  CONSTRAINT vehicles_manufacturing_year_check
    CHECK (manufacturing_year >= 1900 AND manufacturing_year <= 2100),
  CONSTRAINT vehicles_registration_year_check
    CHECK (registration_year IS NULL OR (registration_year >= manufacturing_year AND registration_year <= 2100)),
  CONSTRAINT vehicles_kilometers_check
    CHECK (kilometers >= 0),
  CONSTRAINT vehicles_owners_check
    CHECK (owners >= 0),
  CONSTRAINT vehicles_asking_price_check
    CHECK (asking_price > 0),
  CONSTRAINT vehicles_purchase_price_check
    CHECK (purchase_price IS NULL OR purchase_price >= 0),
  CONSTRAINT vehicles_features_array_check
    CHECK (jsonb_typeof(features) = 'array'),
  CONSTRAINT vehicles_accessories_array_check
    CHECK (jsonb_typeof(accessories) = 'array')
);

-- Trigger: Concurrency-safe Stock ID generation
DROP TRIGGER IF EXISTS trigger_generate_vehicle_stock_id ON public.vehicles;
CREATE TRIGGER trigger_generate_vehicle_stock_id
  BEFORE INSERT ON public.vehicles
  FOR EACH ROW
  EXECUTE FUNCTION public.generate_vehicle_stock_id();

-- Trigger: updated_at timestamp
DROP TRIGGER IF EXISTS set_vehicles_updated_at ON public.vehicles;
CREATE TRIGGER set_vehicles_updated_at
  BEFORE UPDATE ON public.vehicles
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();


-- ==========================================
-- MIGRATION: 00006_create_vehicle_media.sql
-- ==========================================

-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00006_create_vehicle_media.sql
-- Description: Create vehicle_media table with cover image constraints and publishing integrity trigger.

CREATE TABLE IF NOT EXISTS public.vehicle_media (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID NOT NULL REFERENCES public.vehicles(id) ON DELETE CASCADE,
  media_type public.vehicle_media_type NOT NULL,
  storage_path TEXT NOT NULL UNIQUE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_cover BOOLEAN NOT NULL DEFAULT false,
  alt_text TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Constraints
  CONSTRAINT vehicle_media_sort_order_check
    CHECK (sort_order >= 0),
  CONSTRAINT vehicle_media_cover_image_only
    CHECK (NOT (is_cover = true AND media_type = 'VIDEO'))
);

-- Partial unique index: Exactly one cover media per vehicle
CREATE UNIQUE INDEX IF NOT EXISTS vehicle_media_single_cover_idx
  ON public.vehicle_media (vehicle_id)
  WHERE (is_cover = true);

-- Indexes for vehicle media lookup and ordering
CREATE INDEX IF NOT EXISTS idx_vehicle_media_vehicle_id
  ON public.vehicle_media (vehicle_id);

CREATE INDEX IF NOT EXISTS idx_vehicle_media_sort_order
  ON public.vehicle_media (vehicle_id, sort_order ASC);

-- PUBLISHING INTEGRITY TRIGGER
-- Enforces that a vehicle can only be marked is_published = true when it has complete attributes and >= 1 IMAGE
CREATE OR REPLACE FUNCTION public.check_vehicle_publishing_requirements()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.is_published = true THEN
    IF NEW.make IS NULL OR trim(NEW.make) = '' OR
       NEW.model IS NULL OR trim(NEW.model) = '' OR
       NEW.manufacturing_year IS NULL OR
       NEW.fuel_type IS NULL OR
       NEW.transmission IS NULL OR
       NEW.kilometers IS NULL OR
       NEW.asking_price IS NULL OR NEW.asking_price <= 0 THEN
      RAISE EXCEPTION 'Vehicle cannot be published: Missing mandatory specifications (make, model, year, fuel_type, transmission, kilometers, asking_price).';
    END IF;

    -- Enforce at least one image in vehicle_media
    IF NOT EXISTS (
      SELECT 1 FROM public.vehicle_media
      WHERE vehicle_id = NEW.id AND media_type = 'IMAGE'
    ) THEN
      RAISE EXCEPTION 'Vehicle cannot be published: Must have at least one media record of type IMAGE.';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_check_vehicle_publishing ON public.vehicles;
CREATE TRIGGER trigger_check_vehicle_publishing
  BEFORE UPDATE OF is_published, status ON public.vehicles
  FOR EACH ROW
  EXECUTE FUNCTION public.check_vehicle_publishing_requirements();


-- ==========================================
-- MIGRATION: 00007_create_vehicle_events.sql
-- ==========================================

-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00007_create_vehicle_events.sql
-- Description: Create vehicle_events table for private internal timeline and provenance logging.

CREATE TABLE IF NOT EXISTS public.vehicle_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID NOT NULL REFERENCES public.vehicles(id) ON DELETE CASCADE,
  event_type public.vehicle_event_type NOT NULL,
  notes TEXT,
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Indexes for event inspection and chronology
CREATE INDEX IF NOT EXISTS idx_vehicle_events_vehicle_id
  ON public.vehicle_events (vehicle_id);

CREATE INDEX IF NOT EXISTS idx_vehicle_events_created_at
  ON public.vehicle_events (created_at DESC);


-- ==========================================
-- MIGRATION: 00008_create_enquiries.sql
-- ==========================================

-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00008_create_enquiries.sql
-- Description: Create enquiries table for inbound buyer correspondence and test drive / offer requests.

CREATE TABLE IF NOT EXISTS public.enquiries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID REFERENCES public.vehicles(id) ON DELETE SET NULL,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  enquiry_type public.enquiry_type NOT NULL,
  preferred_date DATE,
  preferred_time TIME,
  offer_amount NUMERIC(12, 2),
  message TEXT,
  status public.enquiry_status NOT NULL DEFAULT 'NEW',
  source public.enquiry_source NOT NULL DEFAULT 'WEBSITE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Constraints
  CONSTRAINT enquiries_offer_amount_check
    CHECK (offer_amount IS NULL OR offer_amount > 0)
);

-- Trigger: updated_at timestamp
DROP TRIGGER IF EXISTS set_enquiries_updated_at ON public.enquiries;
CREATE TRIGGER set_enquiries_updated_at
  BEFORE UPDATE ON public.enquiries
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();


-- ==========================================
-- MIGRATION: 00009_add_indexes_and_constraints.sql
-- ==========================================

-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00009_add_indexes_and_constraints.sql
-- Description: Create targeted performance indexes for inventory filtering and enquiry queues, plus secure public view.

-- 1. VEHICLES INDEXES
CREATE INDEX IF NOT EXISTS idx_vehicles_make
  ON public.vehicles (make);

CREATE INDEX IF NOT EXISTS idx_vehicles_model
  ON public.vehicles (model);

CREATE INDEX IF NOT EXISTS idx_vehicles_asking_price
  ON public.vehicles (asking_price);

CREATE INDEX IF NOT EXISTS idx_vehicles_manufacturing_year
  ON public.vehicles (manufacturing_year DESC);

CREATE INDEX IF NOT EXISTS idx_vehicles_fuel_type
  ON public.vehicles (fuel_type);

CREATE INDEX IF NOT EXISTS idx_vehicles_transmission
  ON public.vehicles (transmission);

CREATE INDEX IF NOT EXISTS idx_vehicles_status
  ON public.vehicles (status);

CREATE INDEX IF NOT EXISTS idx_vehicles_is_published
  ON public.vehicles (is_published);

CREATE INDEX IF NOT EXISTS idx_vehicles_created_at
  ON public.vehicles (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_vehicles_updated_at
  ON public.vehicles (updated_at DESC);

-- Composite index for fast public catalog queries (AVAILABLE + is_published)
CREATE INDEX IF NOT EXISTS idx_vehicles_public_inventory
  ON public.vehicles (status, is_published)
  WHERE (status = 'AVAILABLE' AND is_published = true);

-- 2. ENQUIRIES INDEXES
CREATE INDEX IF NOT EXISTS idx_enquiries_status
  ON public.enquiries (status);

CREATE INDEX IF NOT EXISTS idx_enquiries_created_at
  ON public.enquiries (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_enquiries_vehicle_id
  ON public.enquiries (vehicle_id);

CREATE INDEX IF NOT EXISTS idx_enquiries_phone
  ON public.enquiries (phone);

CREATE INDEX IF NOT EXISTS idx_enquiries_enquiry_type
  ON public.enquiries (enquiry_type);

CREATE INDEX IF NOT EXISTS idx_enquiries_source
  ON public.enquiries (source);

-- 3. SECURE PUBLIC VEHICLES VIEW
-- Provides clean column-level isolation by excluding private acquisition costs (purchase_price).
-- Configured WITH (security_invoker = true) so it respects all underlying RLS policies and never bypasses security.
CREATE OR REPLACE VIEW public.public_vehicles
WITH (security_invoker = true)
AS
SELECT
  id,
  stock_id,
  registration_number,
  make,
  model,
  variant,
  slug,
  manufacturing_year,
  registration_year,
  fuel_type,
  transmission,
  kilometers,
  owners,
  color,
  asking_price,
  condition,
  condition_notes,
  service_history,
  service_history_notes,
  inspection_notes,
  features,
  accessories,
  short_description,
  description,
  status,
  is_published,
  created_at,
  updated_at
FROM public.vehicles
WHERE is_published = true AND status IN ('AVAILABLE', 'RESERVED');


-- ==========================================
-- MIGRATION: 00010_enable_rls_and_grants.sql
-- ==========================================

-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00010_enable_rls_and_grants.sql
-- Description: Implement Row Level Security (RLS) policies, secure is_admin helper, and explicit PostgreSQL grants.

-- 1. REUSABLE SECURITY DEFINER ADMIN HELPER
-- Securely verifies administrator role using auth.uid() without recursive RLS or search_path vulnerabilities.
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN false;
  END IF;

  RETURN EXISTS (
    SELECT 1
    FROM public.profiles
    WHERE id = auth.uid()
      AND role = 'ADMIN'::public.profile_role
  );
END;
$$;

-- 2. PROFILE ROLE MODIFICATION PROTECTION TRIGGER
CREATE OR REPLACE FUNCTION public.protect_profile_role()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  IF NEW.role <> OLD.role AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: Role modification is strictly restricted to existing administrators.';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_protect_profile_role ON public.profiles;
CREATE TRIGGER trigger_protect_profile_role
  BEFORE UPDATE OF role ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.protect_profile_role();

-- 3. ENABLE ROW LEVEL SECURITY ON ALL DOMAIN TABLES
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicle_media ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicle_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.enquiries ENABLE ROW LEVEL SECURITY;

-- 4. ROW LEVEL SECURITY POLICIES

-- PROFILES POLICIES
DROP POLICY IF EXISTS "Users can read own profile or admin reads all" ON public.profiles;
CREATE POLICY "Users can read own profile or admin reads all"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (id = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS "Admins can update profiles" ON public.profiles;
CREATE POLICY "Admins can update profiles"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- SETTINGS POLICIES
DROP POLICY IF EXISTS "Public can view settings" ON public.settings;
CREATE POLICY "Public can view settings"
  ON public.settings FOR SELECT
  TO anon, authenticated
  USING (true);

DROP POLICY IF EXISTS "Admins can update settings" ON public.settings;
CREATE POLICY "Admins can update settings"
  ON public.settings FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "Admins can insert settings" ON public.settings;
CREATE POLICY "Admins can insert settings"
  ON public.settings FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

-- VEHICLES POLICIES
DROP POLICY IF EXISTS "Anonymous can read published vehicles" ON public.vehicles;
CREATE POLICY "Anonymous can read published vehicles"
  ON public.vehicles FOR SELECT
  TO anon
  USING (is_published = true AND status IN ('AVAILABLE', 'RESERVED'));

DROP POLICY IF EXISTS "Admins have full access to vehicles" ON public.vehicles;
CREATE POLICY "Admins have full access to vehicles"
  ON public.vehicles FOR ALL
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- VEHICLE MEDIA POLICIES
DROP POLICY IF EXISTS "Anonymous can read published vehicle media" ON public.vehicle_media;
CREATE POLICY "Anonymous can read published vehicle media"
  ON public.vehicle_media FOR SELECT
  TO anon
  USING (
    EXISTS (
      SELECT 1 FROM public.vehicles v
      WHERE v.id = vehicle_media.vehicle_id
        AND v.is_published = true
        AND v.status IN ('AVAILABLE', 'RESERVED')
    )
  );

DROP POLICY IF EXISTS "Admins have full access to vehicle media" ON public.vehicle_media;
CREATE POLICY "Admins have full access to vehicle media"
  ON public.vehicle_media FOR ALL
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- VEHICLE EVENTS POLICIES (Strictly internal - no public visibility)
DROP POLICY IF EXISTS "Admins can view vehicle events" ON public.vehicle_events;
CREATE POLICY "Admins can view vehicle events"
  ON public.vehicle_events FOR SELECT
  TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS "Admins can insert vehicle events" ON public.vehicle_events;
CREATE POLICY "Admins can insert vehicle events"
  ON public.vehicle_events FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

-- ENQUIRIES POLICIES
DROP POLICY IF EXISTS "Public can insert enquiries" ON public.enquiries;
CREATE POLICY "Public can insert enquiries"
  ON public.enquiries FOR INSERT
  TO anon, authenticated
  WITH CHECK (status = 'NEW');

DROP POLICY IF EXISTS "Admins can view enquiries" ON public.enquiries;
CREATE POLICY "Admins can view enquiries"
  ON public.enquiries FOR SELECT
  TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS "Admins can update enquiries" ON public.enquiries;
CREATE POLICY "Admins can update enquiries"
  ON public.enquiries FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- 5. EXPLICIT POSTGRESQL TABLE GRANTS
-- In accordance with Supabase security recommendations, grants and RLS are configured in tandem.

-- Revoke blanket table access from public / anon
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM anon;

-- Grant minimal necessary read-only columns on vehicles to anonymous users (excluding purchase_price)
GRANT SELECT (
  id, stock_id, registration_number, make, model, variant, slug,
  manufacturing_year, registration_year, fuel_type, transmission,
  kilometers, owners, color, asking_price, condition, condition_notes,
  service_history, service_history_notes, inspection_notes,
  features, accessories, short_description, description,
  status, is_published, created_at, updated_at
) ON public.vehicles TO anon;

GRANT SELECT ON public.public_vehicles TO anon;
GRANT SELECT ON public.vehicle_media TO anon;
GRANT SELECT ON public.settings TO anon;

-- Grant selective enquiry insertion to anon (without status manipulation)
GRANT INSERT (
  vehicle_id, customer_name, phone, email, enquiry_type,
  preferred_date, preferred_time, offer_amount, message, source
) ON public.enquiries TO anon;

-- Authenticated permissions (gated by RLS policies)
GRANT SELECT, UPDATE ON public.profiles TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vehicles TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vehicle_media TO authenticated;
GRANT SELECT, INSERT ON public.vehicle_events TO authenticated;
GRANT SELECT, UPDATE ON public.enquiries TO authenticated;
GRANT SELECT, UPDATE ON public.settings TO authenticated;
GRANT SELECT ON public.public_vehicles TO authenticated;
GRANT USAGE, SELECT ON SEQUENCE public.vehicle_stock_id_seq TO authenticated;

-- Service Role Full Permissions
GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO service_role;
GRANT ALL ON ALL ROUTINES IN SCHEMA public TO service_role;


-- ==========================================
-- MIGRATION: 00011_create_storage_policies.sql
-- ==========================================

-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00011_create_storage_policies.sql
-- Description: Provision public storage buckets and configure path-restricted admin RLS storage policies.
-- Note: Do NOT alter storage.objects table directly (e.g. ENABLE RLS or CHANGE OWNER) as it is Supabase-managed.
-- Buckets are public, so public reads do not require SELECT policies on storage.objects.

-- 1. PROVISION STORAGE BUCKETS
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES
  (
    'vehicle-images',
    'vehicle-images',
    true,
    10485760, -- 10MB per image
    ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/avif']
  ),
  (
    'vehicle-videos',
    'vehicle-videos',
    true,
    52428800, -- 50MB per video
    ARRAY['video/mp4', 'video/webm', 'video/quicktime']
  )
ON CONFLICT (id) DO UPDATE SET
  public = EXCLUDED.public,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

-- 2. ADMIN STORAGE MUTATION POLICIES (Gated by public.is_admin())
-- NOTE: In Supabase, if the SQL migration runner role lacks permission to create policies directly on storage.objects,
-- these policies can be created/verified via Supabase Dashboard → Storage → Policies.
DO $$
BEGIN
  -- Admin upload policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Admins can upload vehicle media'
  ) THEN
    CREATE POLICY "Admins can upload vehicle media"
      ON storage.objects FOR INSERT
      TO authenticated
      WITH CHECK (
        bucket_id IN ('vehicle-images', 'vehicle-videos')
        AND public.is_admin()
      );
  END IF;

  -- Admin update policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Admins can update vehicle media'
  ) THEN
    CREATE POLICY "Admins can update vehicle media"
      ON storage.objects FOR UPDATE
      TO authenticated
      USING (
        bucket_id IN ('vehicle-images', 'vehicle-videos')
        AND public.is_admin()
      )
      WITH CHECK (
        bucket_id IN ('vehicle-images', 'vehicle-videos')
        AND public.is_admin()
      );
  END IF;

  -- Admin delete policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Admins can delete vehicle media'
  ) THEN
    CREATE POLICY "Admins can delete vehicle media"
      ON storage.objects FOR DELETE
      TO authenticated
      USING (
        bucket_id IN ('vehicle-images', 'vehicle-videos')
        AND public.is_admin()
      );
  END IF;
EXCEPTION
  WHEN insufficient_privilege THEN
    RAISE NOTICE 'Skipping direct policy creation on storage.objects due to table ownership. Configure admin mutation policies via Supabase Dashboard → Storage → Policies.';
END $$;



-- ==========================================
-- MIGRATION: 00012_first_admin_setup.sql
-- ==========================================

-- THE CAR CLUB — PHASE 13: SUPABASE AUTHENTICATION & ADMIN ACCESS
-- Migration: 00012_first_admin_setup.sql
-- Description: Implement secure first-admin initialization function, admin count helper, and first-user trigger.

-- 1. HELPER TO CHECK EXISTING ADMIN COUNT
-- Allows checking if initial dealership administrator provisioning is required.
CREATE OR REPLACE FUNCTION public.count_admin_profiles()
RETURNS INTEGER
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT count(*)::INTEGER FROM public.profiles WHERE role = 'ADMIN'::public.profile_role;
$$;

REVOKE ALL ON FUNCTION public.count_admin_profiles() FROM public;
GRANT EXECUTE ON FUNCTION public.count_admin_profiles() TO anon, authenticated, service_role;

-- 2. SECURE FIRST-ADMIN INITIALIZATION RPC
-- Allows the first authenticated user to claim the ADMIN profile ONLY when zero administrators currently exist.
-- Once any administrator exists, this function strictly rejects all further invocations.
CREATE OR REPLACE FUNCTION public.initialize_first_admin(admin_full_name TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  existing_count INTEGER;
  target_user_id UUID;
BEGIN
  target_user_id := auth.uid();
  
  IF target_user_id IS NULL THEN
    RAISE EXCEPTION 'Authentication required: User must be signed in to initialize administrator profile.';
  END IF;

  -- Lock and verify current admin count
  SELECT count(*) INTO existing_count FROM public.profiles WHERE role = 'ADMIN'::public.profile_role;

  IF existing_count > 0 THEN
    RAISE EXCEPTION 'Unauthorized: First-admin setup has already been completed. Contact an existing administrator.';
  END IF;

  -- Insert the authoritative first admin profile
  INSERT INTO public.profiles (id, full_name, role)
  VALUES (
    target_user_id,
    COALESCE(NULLIF(TRIM(admin_full_name), ''), 'Primary Administrator'),
    'ADMIN'::public.profile_role
  )
  ON CONFLICT (id) DO UPDATE SET
    role = 'ADMIN'::public.profile_role,
    full_name = COALESCE(NULLIF(TRIM(admin_full_name), ''), public.profiles.full_name);

  RETURN true;
END;
$$;

REVOKE ALL ON FUNCTION public.initialize_first_admin(TEXT) FROM public;
GRANT EXECUTE ON FUNCTION public.initialize_first_admin(TEXT) TO authenticated, service_role;

-- 3. AUTOMATIC FIRST-USER TRIGGER ON AUTH.USERS
-- If a user is registered via Supabase Auth and exactly zero administrators exist,
-- automatically provision them as the first administrator.
CREATE OR REPLACE FUNCTION public.handle_first_user_as_admin()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  existing_count INTEGER;
  assigned_name TEXT;
BEGIN
  SELECT count(*) INTO existing_count FROM public.profiles WHERE role = 'ADMIN'::public.profile_role;

  -- Only trigger for the very first administrator account
  IF existing_count = 0 THEN
    assigned_name := COALESCE(
      NEW.raw_user_meta_data->>'full_name',
      split_part(NEW.email, '@', 1),
      'Primary Administrator'
    );

    INSERT INTO public.profiles (id, full_name, role)
    VALUES (
      NEW.id,
      assigned_name,
      'ADMIN'::public.profile_role
    )
    ON CONFLICT (id) DO NOTHING;
  END IF;

  RETURN NEW;
END;
$$;

-- Drop trigger if already exists and re-attach
DROP TRIGGER IF EXISTS on_auth_user_created_first_admin ON auth.users;
CREATE TRIGGER on_auth_user_created_first_admin
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_first_user_as_admin();
