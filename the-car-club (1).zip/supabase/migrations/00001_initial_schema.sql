-- THE CAR CLUB — DATABASE SCHEMA FOUNDATION
-- Migration: 00001_initial_schema.sql
-- Description: Core extensions and foundational database configuration.

-- Enable required extensions for cryptographic functions and UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
