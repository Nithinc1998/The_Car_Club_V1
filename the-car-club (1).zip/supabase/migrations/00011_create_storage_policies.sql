-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00011_create_storage_policies.sql
-- Description: Provision public storage buckets and configure path-restricted admin RLS storage policies.
-- Note: Do NOT alter storage.objects table directly (e.g. ENABLE RLS or CHANGE OWNER) as it is Supabase-managed.
-- Buckets are public, so public reads do not require SELECT policies on storage.objects.

-- 1. PROVISION STORAGE BUCKETS
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES
  (
    'vehicle-images',
    'vehicle-images',
    true,
    10485760, -- 10MB per image
    ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/avif']
  ),
  (
    'vehicle-videos',
    'vehicle-videos',
    true,
    52428800, -- 50MB per video
    ARRAY['video/mp4', 'video/webm', 'video/quicktime']
  )
ON CONFLICT (id) DO UPDATE SET
  public = EXCLUDED.public,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

-- 2. ADMIN STORAGE MUTATION POLICIES (Gated by public.is_admin())
-- NOTE: In Supabase, if the SQL migration runner role lacks permission to create policies directly on storage.objects,
-- these policies can be created/verified via Supabase Dashboard → Storage → Policies.
DO $$
BEGIN
  -- Admin upload policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Admins can upload vehicle media'
  ) THEN
    CREATE POLICY "Admins can upload vehicle media"
      ON storage.objects FOR INSERT
      TO authenticated
      WITH CHECK (
        bucket_id IN ('vehicle-images', 'vehicle-videos')
        AND public.is_admin()
      );
  END IF;

  -- Admin update policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Admins can update vehicle media'
  ) THEN
    CREATE POLICY "Admins can update vehicle media"
      ON storage.objects FOR UPDATE
      TO authenticated
      USING (
        bucket_id IN ('vehicle-images', 'vehicle-videos')
        AND public.is_admin()
      )
      WITH CHECK (
        bucket_id IN ('vehicle-images', 'vehicle-videos')
        AND public.is_admin()
      );
  END IF;

  -- Admin delete policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Admins can delete vehicle media'
  ) THEN
    CREATE POLICY "Admins can delete vehicle media"
      ON storage.objects FOR DELETE
      TO authenticated
      USING (
        bucket_id IN ('vehicle-images', 'vehicle-videos')
        AND public.is_admin()
      );
  END IF;
EXCEPTION
  WHEN insufficient_privilege THEN
    RAISE NOTICE 'Skipping direct policy creation on storage.objects due to table ownership. Configure admin mutation policies via Supabase Dashboard → Storage → Policies.';
END $$;

