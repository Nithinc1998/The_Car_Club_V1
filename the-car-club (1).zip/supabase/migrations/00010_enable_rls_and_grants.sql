-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00010_enable_rls_and_grants.sql
-- Description: Implement Row Level Security (RLS) policies, secure is_admin helper, and explicit PostgreSQL grants.

-- 1. REUSABLE SECURITY DEFINER ADMIN HELPER
-- Securely verifies administrator role using auth.uid() without recursive RLS or search_path vulnerabilities.
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN false;
  END IF;

  RETURN EXISTS (
    SELECT 1
    FROM public.profiles
    WHERE id = auth.uid()
      AND role = 'ADMIN'::public.profile_role
  );
END;
$$;

-- 2. PROFILE ROLE MODIFICATION PROTECTION TRIGGER
CREATE OR REPLACE FUNCTION public.protect_profile_role()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  IF NEW.role <> OLD.role AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: Role modification is strictly restricted to existing administrators.';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_protect_profile_role ON public.profiles;
CREATE TRIGGER trigger_protect_profile_role
  BEFORE UPDATE OF role ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.protect_profile_role();

-- 3. ENABLE ROW LEVEL SECURITY ON ALL DOMAIN TABLES
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicle_media ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicle_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.enquiries ENABLE ROW LEVEL SECURITY;

-- 4. ROW LEVEL SECURITY POLICIES

-- PROFILES POLICIES
DROP POLICY IF EXISTS "Users can read own profile or admin reads all" ON public.profiles;
CREATE POLICY "Users can read own profile or admin reads all"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (id = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS "Admins can update profiles" ON public.profiles;
CREATE POLICY "Admins can update profiles"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- SETTINGS POLICIES
DROP POLICY IF EXISTS "Public can view settings" ON public.settings;
CREATE POLICY "Public can view settings"
  ON public.settings FOR SELECT
  TO anon, authenticated
  USING (true);

DROP POLICY IF EXISTS "Admins can update settings" ON public.settings;
CREATE POLICY "Admins can update settings"
  ON public.settings FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "Admins can insert settings" ON public.settings;
CREATE POLICY "Admins can insert settings"
  ON public.settings FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

-- VEHICLES POLICIES
DROP POLICY IF EXISTS "Anonymous can read published vehicles" ON public.vehicles;
CREATE POLICY "Anonymous can read published vehicles"
  ON public.vehicles FOR SELECT
  TO anon
  USING (is_published = true AND status IN ('AVAILABLE', 'RESERVED'));

DROP POLICY IF EXISTS "Admins have full access to vehicles" ON public.vehicles;
CREATE POLICY "Admins have full access to vehicles"
  ON public.vehicles FOR ALL
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- VEHICLE MEDIA POLICIES
DROP POLICY IF EXISTS "Anonymous can read published vehicle media" ON public.vehicle_media;
CREATE POLICY "Anonymous can read published vehicle media"
  ON public.vehicle_media FOR SELECT
  TO anon
  USING (
    EXISTS (
      SELECT 1 FROM public.vehicles v
      WHERE v.id = vehicle_media.vehicle_id
        AND v.is_published = true
        AND v.status IN ('AVAILABLE', 'RESERVED')
    )
  );

DROP POLICY IF EXISTS "Admins have full access to vehicle media" ON public.vehicle_media;
CREATE POLICY "Admins have full access to vehicle media"
  ON public.vehicle_media FOR ALL
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- VEHICLE EVENTS POLICIES (Strictly internal - no public visibility)
DROP POLICY IF EXISTS "Admins can view vehicle events" ON public.vehicle_events;
CREATE POLICY "Admins can view vehicle events"
  ON public.vehicle_events FOR SELECT
  TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS "Admins can insert vehicle events" ON public.vehicle_events;
CREATE POLICY "Admins can insert vehicle events"
  ON public.vehicle_events FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

-- ENQUIRIES POLICIES
DROP POLICY IF EXISTS "Public can insert enquiries" ON public.enquiries;
CREATE POLICY "Public can insert enquiries"
  ON public.enquiries FOR INSERT
  TO anon, authenticated
  WITH CHECK (status = 'NEW');

DROP POLICY IF EXISTS "Admins can view enquiries" ON public.enquiries;
CREATE POLICY "Admins can view enquiries"
  ON public.enquiries FOR SELECT
  TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS "Admins can update enquiries" ON public.enquiries;
CREATE POLICY "Admins can update enquiries"
  ON public.enquiries FOR UPDATE
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- 5. EXPLICIT POSTGRESQL TABLE GRANTS
-- In accordance with Supabase security recommendations, grants and RLS are configured in tandem.

-- Revoke blanket table access from public / anon
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM anon;

-- Grant minimal necessary read-only columns on vehicles to anonymous users (excluding purchase_price)
GRANT SELECT (
  id, stock_id, registration_number, make, model, variant, slug,
  manufacturing_year, registration_year, fuel_type, transmission,
  kilometers, owners, color, asking_price, condition, condition_notes,
  service_history, service_history_notes, inspection_notes,
  features, accessories, short_description, description,
  status, is_published, created_at, updated_at
) ON public.vehicles TO anon;

GRANT SELECT ON public.public_vehicles TO anon;
GRANT SELECT ON public.vehicle_media TO anon;
GRANT SELECT ON public.settings TO anon;

-- Grant selective enquiry insertion to anon (without status manipulation)
GRANT INSERT (
  vehicle_id, customer_name, phone, email, enquiry_type,
  preferred_date, preferred_time, offer_amount, message, source
) ON public.enquiries TO anon;

-- Authenticated permissions (gated by RLS policies)
GRANT SELECT, UPDATE ON public.profiles TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vehicles TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vehicle_media TO authenticated;
GRANT SELECT, INSERT ON public.vehicle_events TO authenticated;
GRANT SELECT, UPDATE ON public.enquiries TO authenticated;
GRANT SELECT, UPDATE ON public.settings TO authenticated;
GRANT SELECT ON public.public_vehicles TO authenticated;
GRANT USAGE, SELECT ON SEQUENCE public.vehicle_stock_id_seq TO authenticated;

-- Service Role Full Permissions
GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO service_role;
GRANT ALL ON ALL ROUTINES IN SCHEMA public TO service_role;
