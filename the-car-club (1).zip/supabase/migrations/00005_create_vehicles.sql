-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00005_create_vehicles.sql
-- Description: Create vehicles table with concurrency-safe stock ID sequence and constraints.

-- 1. CONCURRENCY-SAFE STOCK ID SEQUENCE
CREATE SEQUENCE IF NOT EXISTS public.vehicle_stock_id_seq
  START WITH 1
  INCREMENT BY 1
  MINVALUE 1;

-- 2. STOCK ID AUTO-GENERATION FUNCTION
CREATE OR REPLACE FUNCTION public.generate_vehicle_stock_id()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.stock_id IS NULL OR trim(NEW.stock_id) = '' THEN
    NEW.stock_id := 'TCC-' || lpad(nextval('public.vehicle_stock_id_seq')::text, 5, '0');
  END IF;
  RETURN NEW;
END;
$$;

-- 3. VEHICLES TABLE
CREATE TABLE IF NOT EXISTS public.vehicles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stock_id TEXT NOT NULL UNIQUE,
  registration_number TEXT,
  make TEXT NOT NULL,
  model TEXT NOT NULL,
  variant TEXT,
  slug TEXT NOT NULL UNIQUE,
  manufacturing_year INTEGER NOT NULL,
  registration_year INTEGER,
  fuel_type public.vehicle_fuel_type NOT NULL,
  transmission public.vehicle_transmission NOT NULL,
  kilometers INTEGER NOT NULL,
  owners INTEGER NOT NULL,
  color TEXT,
  asking_price NUMERIC(12, 2) NOT NULL,
  purchase_price NUMERIC(12, 2),
  condition public.vehicle_condition,
  condition_notes TEXT,
  service_history public.service_history_status,
  service_history_notes TEXT,
  inspection_notes TEXT,
  features JSONB NOT NULL DEFAULT '[]'::jsonb,
  accessories JSONB NOT NULL DEFAULT '[]'::jsonb,
  short_description TEXT,
  description TEXT,
  status public.vehicle_status NOT NULL DEFAULT 'DRAFT',
  is_published BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Integrity Constraints
  CONSTRAINT vehicles_manufacturing_year_check
    CHECK (manufacturing_year >= 1900 AND manufacturing_year <= 2100),
  CONSTRAINT vehicles_registration_year_check
    CHECK (registration_year IS NULL OR (registration_year >= manufacturing_year AND registration_year <= 2100)),
  CONSTRAINT vehicles_kilometers_check
    CHECK (kilometers >= 0),
  CONSTRAINT vehicles_owners_check
    CHECK (owners >= 0),
  CONSTRAINT vehicles_asking_price_check
    CHECK (asking_price > 0),
  CONSTRAINT vehicles_purchase_price_check
    CHECK (purchase_price IS NULL OR purchase_price >= 0),
  CONSTRAINT vehicles_features_array_check
    CHECK (jsonb_typeof(features) = 'array'),
  CONSTRAINT vehicles_accessories_array_check
    CHECK (jsonb_typeof(accessories) = 'array')
);

-- Trigger: Concurrency-safe Stock ID generation
DROP TRIGGER IF EXISTS trigger_generate_vehicle_stock_id ON public.vehicles;
CREATE TRIGGER trigger_generate_vehicle_stock_id
  BEFORE INSERT ON public.vehicles
  FOR EACH ROW
  EXECUTE FUNCTION public.generate_vehicle_stock_id();

-- Trigger: updated_at timestamp
DROP TRIGGER IF EXISTS set_vehicles_updated_at ON public.vehicles;
CREATE TRIGGER set_vehicles_updated_at
  BEFORE UPDATE ON public.vehicles
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();
