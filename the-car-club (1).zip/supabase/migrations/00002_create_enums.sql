-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00002_create_enums.sql
-- Description: Create PostgreSQL enums for automotive attributes, lifecycle states, enquiries, and roles.

-- 1. VEHICLE FUEL TYPE
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'vehicle_fuel_type') THEN
    CREATE TYPE public.vehicle_fuel_type AS ENUM (
      'PETROL',
      'DIESEL',
      'CNG',
      'ELECTRIC',
      'HYBRID',
      'OTHER'
    );
  END IF;
END $$;

-- 2. VEHICLE TRANSMISSION
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'vehicle_transmission') THEN
    CREATE TYPE public.vehicle_transmission AS ENUM (
      'MANUAL',
      'AUTOMATIC',
      'AMT',
      'CVT',
      'DCT',
      'IMT',
      'OTHER'
    );
  END IF;
END $$;

-- 3. VEHICLE CONDITION
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'vehicle_condition') THEN
    CREATE TYPE public.vehicle_condition AS ENUM (
      'EXCELLENT',
      'GOOD',
      'FAIR'
    );
  END IF;
END $$;

-- 4. SERVICE HISTORY STATUS
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'service_history_status') THEN
    CREATE TYPE public.service_history_status AS ENUM (
      'FULL',
      'PARTIAL',
      'NOT_AVAILABLE',
      'UNKNOWN'
    );
  END IF;
END $$;

-- 5. REGISTRATION CERTIFICATE (RC) STATUS
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'rc_status') THEN
    CREATE TYPE public.rc_status AS ENUM (
      'AVAILABLE',
      'TRANSFER_PENDING',
      'TRANSFERRED',
      'NOT_AVAILABLE',
      'OTHER'
    );
  END IF;
END $$;

-- 6. VEHICLE STATUS
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'vehicle_status') THEN
    CREATE TYPE public.vehicle_status AS ENUM (
      'DRAFT',
      'AVAILABLE',
      'RESERVED',
      'SOLD',
      'ARCHIVED'
    );
  END IF;
END $$;

-- 7. VEHICLE MEDIA TYPE
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'vehicle_media_type') THEN
    CREATE TYPE public.vehicle_media_type AS ENUM (
      'IMAGE',
      'VIDEO'
    );
  END IF;
END $$;

-- 8. VEHICLE EVENT TYPE
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'vehicle_event_type') THEN
    CREATE TYPE public.vehicle_event_type AS ENUM (
      'ACQUIRED',
      'INSPECTION',
      'PRICING_UPDATED',
      'PUBLISHED',
      'UNPUBLISHED',
      'RESERVED',
      'RESERVATION_CANCELLED',
      'SOLD',
      'ARCHIVED',
      'NOTE'
    );
  END IF;
END $$;

-- 9. ENQUIRY TYPE
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'enquiry_type') THEN
    CREATE TYPE public.enquiry_type AS ENUM (
      'VEHICLE',
      'TEST_DRIVE',
      'CALLBACK',
      'OFFER',
      'GENERAL'
    );
  END IF;
END $$;

-- 10. ENQUIRY STATUS
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'enquiry_status') THEN
    CREATE TYPE public.enquiry_status AS ENUM (
      'NEW',
      'CONTACTED',
      'FOLLOW_UP',
      'CONVERTED',
      'CLOSED'
    );
  END IF;
END $$;

-- 11. ENQUIRY SOURCE
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'enquiry_source') THEN
    CREATE TYPE public.enquiry_source AS ENUM (
      'WEBSITE',
      'WHATSAPP',
      'PHONE',
      'INSTAGRAM',
      'FACEBOOK',
      'GOOGLE',
      'OTHER'
    );
  END IF;
END $$;

-- 12. PROFILE ROLE
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'profile_role') THEN
    CREATE TYPE public.profile_role AS ENUM (
      'ADMIN'
    );
  END IF;
END $$;
