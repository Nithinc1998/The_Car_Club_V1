-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00008_create_enquiries.sql
-- Description: Create enquiries table for inbound buyer correspondence and test drive / offer requests.

CREATE TABLE IF NOT EXISTS public.enquiries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID REFERENCES public.vehicles(id) ON DELETE SET NULL,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  enquiry_type public.enquiry_type NOT NULL,
  preferred_date DATE,
  preferred_time TIME,
  offer_amount NUMERIC(12, 2),
  message TEXT,
  status public.enquiry_status NOT NULL DEFAULT 'NEW',
  source public.enquiry_source NOT NULL DEFAULT 'WEBSITE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Constraints
  CONSTRAINT enquiries_offer_amount_check
    CHECK (offer_amount IS NULL OR offer_amount > 0)
);

-- Trigger: updated_at timestamp
DROP TRIGGER IF EXISTS set_enquiries_updated_at ON public.enquiries;
CREATE TRIGGER set_enquiries_updated_at
  BEFORE UPDATE ON public.enquiries
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();
