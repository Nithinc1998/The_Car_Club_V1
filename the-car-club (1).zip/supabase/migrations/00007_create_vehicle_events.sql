-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00007_create_vehicle_events.sql
-- Description: Create vehicle_events table for private internal timeline and provenance logging.

CREATE TABLE IF NOT EXISTS public.vehicle_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID NOT NULL REFERENCES public.vehicles(id) ON DELETE CASCADE,
  event_type public.vehicle_event_type NOT NULL,
  notes TEXT,
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Indexes for event inspection and chronology
CREATE INDEX IF NOT EXISTS idx_vehicle_events_vehicle_id
  ON public.vehicle_events (vehicle_id);

CREATE INDEX IF NOT EXISTS idx_vehicle_events_created_at
  ON public.vehicle_events (created_at DESC);
