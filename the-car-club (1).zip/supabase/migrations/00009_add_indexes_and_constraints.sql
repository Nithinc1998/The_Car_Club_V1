-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00009_add_indexes_and_constraints.sql
-- Description: Create targeted performance indexes for inventory filtering and enquiry queues, plus secure public view.

-- 1. VEHICLES INDEXES
CREATE INDEX IF NOT EXISTS idx_vehicles_make
  ON public.vehicles (make);

CREATE INDEX IF NOT EXISTS idx_vehicles_model
  ON public.vehicles (model);

CREATE INDEX IF NOT EXISTS idx_vehicles_asking_price
  ON public.vehicles (asking_price);

CREATE INDEX IF NOT EXISTS idx_vehicles_manufacturing_year
  ON public.vehicles (manufacturing_year DESC);

CREATE INDEX IF NOT EXISTS idx_vehicles_fuel_type
  ON public.vehicles (fuel_type);

CREATE INDEX IF NOT EXISTS idx_vehicles_transmission
  ON public.vehicles (transmission);

CREATE INDEX IF NOT EXISTS idx_vehicles_status
  ON public.vehicles (status);

CREATE INDEX IF NOT EXISTS idx_vehicles_is_published
  ON public.vehicles (is_published);

CREATE INDEX IF NOT EXISTS idx_vehicles_created_at
  ON public.vehicles (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_vehicles_updated_at
  ON public.vehicles (updated_at DESC);

-- Composite index for fast public catalog queries (AVAILABLE + is_published)
CREATE INDEX IF NOT EXISTS idx_vehicles_public_inventory
  ON public.vehicles (status, is_published)
  WHERE (status = 'AVAILABLE' AND is_published = true);

-- 2. ENQUIRIES INDEXES
CREATE INDEX IF NOT EXISTS idx_enquiries_status
  ON public.enquiries (status);

CREATE INDEX IF NOT EXISTS idx_enquiries_created_at
  ON public.enquiries (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_enquiries_vehicle_id
  ON public.enquiries (vehicle_id);

CREATE INDEX IF NOT EXISTS idx_enquiries_phone
  ON public.enquiries (phone);

CREATE INDEX IF NOT EXISTS idx_enquiries_enquiry_type
  ON public.enquiries (enquiry_type);

CREATE INDEX IF NOT EXISTS idx_enquiries_source
  ON public.enquiries (source);

-- 3. SECURE PUBLIC VEHICLES VIEW
-- Provides clean column-level isolation by excluding private acquisition costs (purchase_price).
-- Configured WITH (security_invoker = true) so it respects all underlying RLS policies and never bypasses security.
CREATE OR REPLACE VIEW public.public_vehicles
WITH (security_invoker = true)
AS
SELECT
  id,
  stock_id,
  registration_number,
  make,
  model,
  variant,
  slug,
  manufacturing_year,
  registration_year,
  fuel_type,
  transmission,
  kilometers,
  owners,
  color,
  asking_price,
  condition,
  condition_notes,
  service_history,
  service_history_notes,
  inspection_notes,
  features,
  accessories,
  short_description,
  description,
  status,
  is_published,
  created_at,
  updated_at
FROM public.vehicles
WHERE is_published = true AND status IN ('AVAILABLE', 'RESERVED');
