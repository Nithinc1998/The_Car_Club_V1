-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00004_create_settings.sql
-- Description: Create singleton settings table for platform metadata, concierge contacts, and operating hours.

CREATE TABLE IF NOT EXISTS public.settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  is_singleton BOOLEAN NOT NULL DEFAULT true CHECK (is_singleton = true) UNIQUE,
  dealership_name TEXT NOT NULL,
  phone TEXT,
  whatsapp_number TEXT,
  email TEXT,
  address TEXT,
  city TEXT,
  district TEXT,
  state TEXT,
  pincode TEXT,
  opening_hours TEXT,
  google_maps_url TEXT,
  instagram_url TEXT,
  facebook_url TEXT,
  youtube_url TEXT,
  logo_url TEXT,
  favicon_url TEXT,
  site_title TEXT,
  meta_description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- updated_at trigger for settings
DROP TRIGGER IF EXISTS set_settings_updated_at ON public.settings;
CREATE TRIGGER set_settings_updated_at
  BEFORE UPDATE ON public.settings
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- Insert initial baseline singleton configuration record
INSERT INTO public.settings (
  is_singleton,
  dealership_name,
  site_title,
  meta_description
)
VALUES (
  true,
  'The Car Club',
  'The Car Club',
  'A modern, minimal, premium automotive platform for curated vehicle presentation and customer enquiries.'
)
ON CONFLICT (is_singleton) DO NOTHING;
