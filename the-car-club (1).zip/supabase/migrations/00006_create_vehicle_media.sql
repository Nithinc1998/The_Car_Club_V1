-- THE CAR CLUB — PHASE 12: DATABASE & SECURITY
-- Migration: 00006_create_vehicle_media.sql
-- Description: Create vehicle_media table with cover image constraints and publishing integrity trigger.

CREATE TABLE IF NOT EXISTS public.vehicle_media (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID NOT NULL REFERENCES public.vehicles(id) ON DELETE CASCADE,
  media_type public.vehicle_media_type NOT NULL,
  storage_path TEXT NOT NULL UNIQUE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_cover BOOLEAN NOT NULL DEFAULT false,
  alt_text TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Constraints
  CONSTRAINT vehicle_media_sort_order_check
    CHECK (sort_order >= 0),
  CONSTRAINT vehicle_media_cover_image_only
    CHECK (NOT (is_cover = true AND media_type = 'VIDEO'))
);

-- Partial unique index: Exactly one cover media per vehicle
CREATE UNIQUE INDEX IF NOT EXISTS vehicle_media_single_cover_idx
  ON public.vehicle_media (vehicle_id)
  WHERE (is_cover = true);

-- Indexes for vehicle media lookup and ordering
CREATE INDEX IF NOT EXISTS idx_vehicle_media_vehicle_id
  ON public.vehicle_media (vehicle_id);

CREATE INDEX IF NOT EXISTS idx_vehicle_media_sort_order
  ON public.vehicle_media (vehicle_id, sort_order ASC);

-- PUBLISHING INTEGRITY TRIGGER
-- Enforces that a vehicle can only be marked is_published = true when it has complete attributes and >= 1 IMAGE
CREATE OR REPLACE FUNCTION public.check_vehicle_publishing_requirements()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.is_published = true THEN
    IF NEW.make IS NULL OR trim(NEW.make) = '' OR
       NEW.model IS NULL OR trim(NEW.model) = '' OR
       NEW.manufacturing_year IS NULL OR
       NEW.fuel_type IS NULL OR
       NEW.transmission IS NULL OR
       NEW.kilometers IS NULL OR
       NEW.asking_price IS NULL OR NEW.asking_price <= 0 THEN
      RAISE EXCEPTION 'Vehicle cannot be published: Missing mandatory specifications (make, model, year, fuel_type, transmission, kilometers, asking_price).';
    END IF;

    -- Enforce at least one image in vehicle_media
    IF NOT EXISTS (
      SELECT 1 FROM public.vehicle_media
      WHERE vehicle_id = NEW.id AND media_type = 'IMAGE'
    ) THEN
      RAISE EXCEPTION 'Vehicle cannot be published: Must have at least one media record of type IMAGE.';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_check_vehicle_publishing ON public.vehicles;
CREATE TRIGGER trigger_check_vehicle_publishing
  BEFORE UPDATE OF is_published, status ON public.vehicles
  FOR EACH ROW
  EXECUTE FUNCTION public.check_vehicle_publishing_requirements();
