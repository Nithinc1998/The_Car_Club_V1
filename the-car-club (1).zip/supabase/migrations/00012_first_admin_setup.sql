-- THE CAR CLUB — PHASE 13: SUPABASE AUTHENTICATION & ADMIN ACCESS
-- Migration: 00012_first_admin_setup.sql
-- Description: Implement secure first-admin initialization function, admin count helper, and first-user trigger.

-- 1. HELPER TO CHECK EXISTING ADMIN COUNT
-- Allows checking if initial dealership administrator provisioning is required.
CREATE OR REPLACE FUNCTION public.count_admin_profiles()
RETURNS INTEGER
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT count(*)::INTEGER FROM public.profiles WHERE role = 'ADMIN'::public.profile_role;
$$;

REVOKE ALL ON FUNCTION public.count_admin_profiles() FROM public;
GRANT EXECUTE ON FUNCTION public.count_admin_profiles() TO anon, authenticated, service_role;

-- 2. SECURE FIRST-ADMIN INITIALIZATION RPC
-- Allows the first authenticated user to claim the ADMIN profile ONLY when zero administrators currently exist.
-- Once any administrator exists, this function strictly rejects all further invocations.
CREATE OR REPLACE FUNCTION public.initialize_first_admin(admin_full_name TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  existing_count INTEGER;
  target_user_id UUID;
BEGIN
  target_user_id := auth.uid();
  
  IF target_user_id IS NULL THEN
    RAISE EXCEPTION 'Authentication required: User must be signed in to initialize administrator profile.';
  END IF;

  -- Lock and verify current admin count
  SELECT count(*) INTO existing_count FROM public.profiles WHERE role = 'ADMIN'::public.profile_role;

  IF existing_count > 0 THEN
    RAISE EXCEPTION 'Unauthorized: First-admin setup has already been completed. Contact an existing administrator.';
  END IF;

  -- Insert the authoritative first admin profile
  INSERT INTO public.profiles (id, full_name, role)
  VALUES (
    target_user_id,
    COALESCE(NULLIF(TRIM(admin_full_name), ''), 'Primary Administrator'),
    'ADMIN'::public.profile_role
  )
  ON CONFLICT (id) DO UPDATE SET
    role = 'ADMIN'::public.profile_role,
    full_name = COALESCE(NULLIF(TRIM(admin_full_name), ''), public.profiles.full_name);

  RETURN true;
END;
$$;

REVOKE ALL ON FUNCTION public.initialize_first_admin(TEXT) FROM public;
GRANT EXECUTE ON FUNCTION public.initialize_first_admin(TEXT) TO authenticated, service_role;

-- 3. AUTOMATIC FIRST-USER TRIGGER ON AUTH.USERS
-- If a user is registered via Supabase Auth and exactly zero administrators exist,
-- automatically provision them as the first administrator.
CREATE OR REPLACE FUNCTION public.handle_first_user_as_admin()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  existing_count INTEGER;
  assigned_name TEXT;
BEGIN
  SELECT count(*) INTO existing_count FROM public.profiles WHERE role = 'ADMIN'::public.profile_role;

  -- Only trigger for the very first administrator account
  IF existing_count = 0 THEN
    assigned_name := COALESCE(
      NEW.raw_user_meta_data->>'full_name',
      split_part(NEW.email, '@', 1),
      'Primary Administrator'
    );

    INSERT INTO public.profiles (id, full_name, role)
    VALUES (
      NEW.id,
      assigned_name,
      'ADMIN'::public.profile_role
    )
    ON CONFLICT (id) DO NOTHING;
  END IF;

  RETURN NEW;
END;
$$;

-- Drop trigger if already exists and re-attach
DROP TRIGGER IF EXISTS on_auth_user_created_first_admin ON auth.users;
CREATE TRIGGER on_auth_user_created_first_admin
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_first_user_as_admin();
