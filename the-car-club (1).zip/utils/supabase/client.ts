import { getSupabaseBrowserClient } from '@/lib/supabase/client';

/**
 * Standard Supabase client accessor mapped to the verified Vite singleton client.
 */
export const createClient = () => {
  return getSupabaseBrowserClient();
};
