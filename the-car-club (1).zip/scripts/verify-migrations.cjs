const fs = require('fs');
const path = require('path');

const migrationsDir = path.join(__dirname, '..', 'supabase', 'migrations');
const testsDir = path.join(__dirname, '..', 'supabase', 'tests');

console.log('=== VERIFYING SUPABASE MIGRATIONS ===');

const files = fs.readdirSync(migrationsDir).sort();
console.log(`Found ${files.length} migration files:`);
files.forEach((f) => console.log(` - ${f}`));

// Verification checklist
const expectedTables = ['profiles', 'settings', 'vehicles', 'vehicle_media', 'vehicle_events', 'enquiries'];
const expectedEnums = [
  'vehicle_fuel_type',
  'vehicle_transmission',
  'vehicle_condition',
  'service_history_status',
  'rc_status',
  'vehicle_status',
  'vehicle_media_type',
  'vehicle_event_type',
  'enquiry_type',
  'enquiry_status',
  'enquiry_source',
  'profile_role',
];

let allSql = '';
files.forEach((file) => {
  const content = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
  allSql += '\n' + content;
});

console.log('\n=== CHECKING SCHEMA ARTIFACTS ===');
expectedEnums.forEach((enumName) => {
  const found = allSql.includes(`TYPE public.${enumName}`) || allSql.includes(`typname = '${enumName}'`);
  console.log(`Enum ${enumName.padEnd(25)}: ${found ? 'PASS' : 'FAIL'}`);
  if (!found) process.exit(1);
});

expectedTables.forEach((table) => {
  const found = allSql.includes(`TABLE IF NOT EXISTS public.${table}`) || allSql.includes(`TABLE public.${table}`);
  console.log(`Table ${table.padEnd(25)}: ${found ? 'PASS' : 'FAIL'}`);
  if (!found) process.exit(1);
});

// Check RLS
console.log('\n=== CHECKING RLS POLICIES & SECURITY ===');
expectedTables.forEach((table) => {
  const rlsFound = allSql.includes(`ALTER TABLE public.${table} ENABLE ROW LEVEL SECURITY`);
  console.log(`RLS on ${table.padEnd(23)}: ${rlsFound ? 'ENABLED' : 'FAIL'}`);
  if (!rlsFound) process.exit(1);
});

// Check helper
const helperFound = allSql.includes('FUNCTION public.is_admin');
console.log(`Helper is_admin(): ${helperFound ? 'PASS' : 'FAIL'}`);

// Check Phase 13 first admin setup
const firstAdminHelperFound = allSql.includes('FUNCTION public.initialize_first_admin');
console.log(`Helper initialize_first_admin(): ${firstAdminHelperFound ? 'PASS' : 'FAIL'}`);

// Check Buckets
const bucketsFound = allSql.includes('vehicle-images') && allSql.includes('vehicle-videos');
console.log(`Storage buckets: ${bucketsFound ? 'PASS' : 'FAIL'}`);

// Check Tests
console.log('\n=== CHECKING DATABASE TESTS ===');
const testFiles = fs.readdirSync(testsDir);
console.log(`Found ${testFiles.length} test files:`);
testFiles.forEach((f) => console.log(` - ${f}`));

console.log('\nALL STATIC VERIFICATION CHECKS PASSED SUCCESSFULLY!');
