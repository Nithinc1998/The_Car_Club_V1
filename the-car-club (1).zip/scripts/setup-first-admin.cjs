/**
 * THE CAR CLUB — PHASE 13: FIRST-ADMIN PROVISIONING SCRIPT
 *
 * This script documents and demonstrates how to provision the first administrator
 * using the Supabase Admin API / SQL RPC initialize_first_admin().
 *
 * Usage:
 *   node scripts/setup-first-admin.cjs <admin_email> <admin_password> <admin_full_name>
 */

const { createClient } = require('@supabase/supabase-js');
require('dotenv').config({ path: '.env.local' });

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

async function setupFirstAdmin() {
  const args = process.argv.slice(2);
  const email = args[0] || 'admin@thecarclub.example';
  const password = args[1] || 'CarClubAdmin2026!';
  const fullName = args[2] || 'Primary Administrator';

  console.log('=== THE CAR CLUB: FIRST-ADMIN PROVISIONING ===');
  console.log(`Target Email:     ${email}`);
  console.log(`Target Name:      ${fullName}`);

  if (!supabaseUrl || !serviceRoleKey) {
    console.log('\n[NOTICE] Supabase service environment variables are not set.');
    console.log('To run this script against a live Supabase instance:');
    console.log('  1. Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in .env.local');
    console.log('  2. Run: node scripts/setup-first-admin.cjs admin@thecarclub.example StrongPassword123! "Lead Admin"');
    console.log('\nAlternatively, execute migration 00012_first_admin_setup.sql in your Supabase SQL Editor:');
    console.log(`
  -- Direct SQL Bootstrap Example:
  -- 1. Create user in Supabase Auth Dashboard
  -- 2. Run in SQL Editor:
  -- INSERT INTO public.profiles (id, full_name, role)
  -- VALUES ('<USER_UUID>', '${fullName}', 'ADMIN')
  -- ON CONFLICT (id) DO NOTHING;
    `);
    process.exit(0);
  }

  const supabase = createClient(supabaseUrl, serviceRoleKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  try {
    // Check if any admin already exists
    const { count, error: countErr } = await supabase
      .from('profiles')
      .select('*', { count: 'exact', head: true })
      .eq('role', 'ADMIN');

    if (countErr) {
      console.error('Error querying profiles:', countErr.message);
      process.exit(1);
    }

    if (count && count > 0) {
      console.log(`[ABORTED] Database already has ${count} registered administrator(s).`);
      console.log('Per Phase 12 & Phase 13 security rules, first-admin setup can only run on a zero-admin instance.');
      process.exit(1);
    }

    console.log('No existing administrators found. Creating primary administrator user...');

    // Create user via Admin API
    const { data: userData, error: userErr } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name: fullName },
    });

    if (userErr) {
      console.error('Failed to create auth user:', userErr.message);
      process.exit(1);
    }

    console.log(`User created in auth.users: ${userData.user.id}`);

    // Create or verify profile
    const { error: profileErr } = await supabase.from('profiles').upsert({
      id: userData.user.id,
      full_name: fullName,
      role: 'ADMIN',
    });

    if (profileErr) {
      console.error('Failed to insert admin profile:', profileErr.message);
      process.exit(1);
    }

    console.log('\nSUCCESS! Primary administrator account provisioned.');
    console.log('Email:    ' + email);
    console.log('Role:     ADMIN (Authoritative in public.profiles)');
    console.log('Access:   /admin/login');
  } catch (err) {
    console.error('Unexpected error:', err);
    process.exit(1);
  }
}

setupFirstAdmin();
