import React from 'react';

interface PublicFooterProps {
  onNavigate: (path: string) => void;
}

export const PublicFooter: React.FC<PublicFooterProps> = ({ onNavigate }) => {
  return (
    <footer className="border-t border-[#E5E5E5] bg-[#FFFFFF] text-[#111111]">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Brand Col */}
          <div className="space-y-4 md:col-span-2">
            <span className="font-heading text-lg font-extrabold tracking-widest text-[#111111] uppercase block">
              THE CAR CLUB
            </span>
            <p className="text-sm text-[#6B6B6B] max-w-md leading-relaxed">
              Curated vehicle presentation, independent provenance review, and discrete automotive advisory services for discerning collectors and drivers.
            </p>
            <div className="text-xs text-[#6B6B6B]">
              Appointment only showroom viewings.
            </div>
          </div>

          {/* Navigation Links */}
          <div>
            <h4 className="font-heading text-xs font-bold tracking-wider uppercase text-[#111111] mb-4">
              Explore
            </h4>
            <ul className="space-y-2.5 text-sm text-[#6B6B6B]">
              <li>
                <button
                  onClick={() => onNavigate('/cars')}
                  className="hover:text-[#111111] transition-colors focus:outline-none focus:underline"
                >
                  Vehicle Inventory
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/about')}
                  className="hover:text-[#111111] transition-colors focus:outline-none focus:underline"
                >
                  Heritage & Standards
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/contact')}
                  className="hover:text-[#111111] transition-colors focus:outline-none focus:underline"
                >
                  Showroom & Concierge
                </button>
              </li>
            </ul>
          </div>

          {/* Management & Legal */}
          <div>
            <h4 className="font-heading text-xs font-bold tracking-wider uppercase text-[#111111] mb-4">
              Access
            </h4>
            <ul className="space-y-2.5 text-sm text-[#6B6B6B]">
              <li>
                <button
                  onClick={() => onNavigate('/admin')}
                  className="hover:text-[#111111] transition-colors focus:outline-none focus:underline"
                >
                  Dealership Portal
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/admin/login')}
                  className="hover:text-[#111111] transition-colors focus:outline-none focus:underline"
                >
                  Staff Authentication
                </button>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-[#E5E5E5] flex flex-col sm:flex-row items-center justify-between text-xs text-[#6B6B6B] gap-4">
          <p>© {new Date().getFullYear()} The Car Club. All rights reserved.</p>
          <div className="flex space-x-6">
            <span>Modern • Minimal • Automotive</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
