import React from 'react';
import { PublicHeader } from './header';
import { PublicFooter } from './footer';

interface PublicLayoutProps {
  children: React.ReactNode;
  currentPath: string;
  onNavigate: (path: string) => void;
}

export const PublicLayout: React.FC<PublicLayoutProps> = ({
  children,
  currentPath,
  onNavigate,
}) => {
  return (
    <div className="min-h-screen flex flex-col bg-[#F7F7F5] text-[#111111]">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:px-4 focus:py-2 focus:bg-[#173F35] focus:text-white focus:rounded focus:outline-none focus:ring-2 focus:ring-[#C5A880] focus:shadow-lg text-xs font-semibold"
      >
        Skip to main content
      </a>
      <PublicHeader currentPath={currentPath} onNavigate={onNavigate} />
      <main className="flex-1 w-full" id="main-content">
        {children}
      </main>
      <PublicFooter onNavigate={onNavigate} />
    </div>
  );
};
