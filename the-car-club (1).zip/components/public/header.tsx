import React, { useState } from 'react';
import { Menu, X, ArrowUpRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface PublicHeaderProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

export const PublicHeader: React.FC<PublicHeaderProps> = ({ currentPath, onNavigate }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Inventory', path: '/cars' },
    { label: 'About', path: '/about' },
    { label: 'Contact', path: '/contact' },
  ];

  const handleLinkClick = (path: string) => {
    onNavigate(path);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-[#E5E5E5] bg-white/95 backdrop-blur-sm">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Brand Identity */}
        <div className="flex items-center">
          <button
            onClick={() => handleLinkClick('/')}
            className="flex flex-col text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[#173F35] rounded-sm py-1"
          >
            <span className="font-heading text-lg font-extrabold tracking-widest text-[#111111] uppercase">
              THE CAR CLUB
            </span>
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#6B6B6B]">
              Curated Automobiles
            </span>
          </button>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8" aria-label="Main Navigation">
          {navLinks.map((link) => {
            const isActive = currentPath === link.path || (link.path !== '/' && currentPath.startsWith(link.path));
            return (
              <button
                key={link.path}
                onClick={() => handleLinkClick(link.path)}
                className={`text-sm font-medium transition-colors hover:text-[#111111] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#173F35] rounded px-1 py-1 ${
                  isActive ? 'text-[#111111] font-semibold' : 'text-[#6B6B6B]'
                }`}
              >
                {link.label}
              </button>
            );
          })}
        </nav>

        {/* Actions */}
        <div className="hidden md:flex items-center space-x-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleLinkClick('/admin')}
            className="text-xs"
          >
            Admin Portal
          </Button>
          <Button
            variant="accent"
            size="sm"
            onClick={() => handleLinkClick('/contact')}
          >
            Private Consultation
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <div className="flex md:hidden items-center space-x-2">
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="inline-flex items-center justify-center rounded-md p-2 text-[#111111] hover:bg-[#F0F0EE] focus:outline-none focus:ring-2 focus:ring-[#173F35]"
            aria-expanded={mobileMenuOpen}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-[#E5E5E5] bg-white px-4 pt-3 pb-6 space-y-4">
          <nav className="flex flex-col space-y-3" aria-label="Mobile Navigation">
            {navLinks.map((link) => {
              const isActive = currentPath === link.path;
              return (
                <button
                  key={link.path}
                  onClick={() => handleLinkClick(link.path)}
                  className={`text-left text-base font-medium py-2 px-2 rounded-md ${
                    isActive ? 'bg-[#F0F0EE] text-[#111111] font-semibold' : 'text-[#6B6B6B] hover:text-[#111111]'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>
          <div className="pt-2 border-t border-[#E5E5E5] flex flex-col space-y-2">
            <Button
              variant="accent"
              onClick={() => handleLinkClick('/contact')}
              className="w-full justify-center"
            >
              Private Consultation
            </Button>
            <Button
              variant="outline"
              onClick={() => handleLinkClick('/admin')}
              className="w-full justify-center text-xs"
            >
              Admin Portal
            </Button>
          </div>
        </div>
      )}
    </header>
  );
};
