import React from 'react';
import { Loader2 } from 'lucide-react';

interface LoadingStateProps {
  message?: string;
}

export const LoadingState: React.FC<LoadingStateProps> = ({ message = 'Synchronizing application state...' }) => {
  return (
    <div className="min-h-[50vh] flex flex-col items-center justify-center p-8 space-y-4 text-center">
      <div className="h-10 w-10 rounded-full bg-white border border-[#E5E5E5] flex items-center justify-center text-[#173F35] shadow-xs">
        <Loader2 className="h-5 w-5 animate-spin" />
      </div>
      <p className="text-xs font-medium text-[#6B6B6B] tracking-wide">
        {message}
      </p>
    </div>
  );
};
