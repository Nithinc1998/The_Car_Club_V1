import React from 'react';
import { ShieldCheck, Compass, CheckCircle2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface AboutRouteProps {
  onNavigate: (path: string) => void;
}

export const AboutRoute: React.FC<AboutRouteProps> = ({ onNavigate }) => {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-12">
      {/* Route Header */}
      <div className="max-w-3xl space-y-4 border-b border-[#E5E5E5] pb-6">
        <div className="flex items-center gap-2 text-xs text-[#6B6B6B]">
          <span>Route:</span>
          <code className="bg-[#F0F0EE] px-1.5 py-0.5 rounded text-[#111111] font-mono">/about</code>
        </div>
        <h1 className="font-heading text-3xl sm:text-4xl font-extrabold text-[#111111]">
          Heritage & Curation Philosophy
        </h1>
        <p className="text-base text-[#6B6B6B] leading-relaxed">
          The Car Club was established as an independent automotive platform dedicated to transparent vehicle representation, technical verification, and thoughtful collector advisory.
        </p>
      </div>

      {/* Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <div className="h-10 w-10 rounded-md bg-[#F7F7F5] flex items-center justify-center text-[#173F35] mb-2">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <CardTitle className="text-lg">Technical Verification</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-[#6B6B6B] leading-relaxed">
              Every motor vehicle presented in our catalog undergoes rigorous multi-point mechanical and provenance inspections prior to listing.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="h-10 w-10 rounded-md bg-[#F7F7F5] flex items-center justify-center text-[#173F35] mb-2">
              <Compass className="h-5 w-5" />
            </div>
            <CardTitle className="text-lg">Transparent Documentation</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-[#6B6B6B] leading-relaxed">
              Complete service records, ownership histories, and diagnostic readouts are archived directly for buyer inspection.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="h-10 w-10 rounded-md bg-[#F7F7F5] flex items-center justify-center text-[#173F35] mb-2">
              <CheckCircle2 className="h-5 w-5" />
            </div>
            <CardTitle className="text-lg">Private Concierge</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-[#6B6B6B] leading-relaxed">
              Consultations and showroom visits are arranged by appointment to ensure dedicated technical review without sales pressure.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Standards Summary */}
      <div className="rounded-lg border border-[#E5E5E5] bg-white p-6 sm:p-8 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-heading text-lg font-bold text-[#111111]">
            Operating Standards & Compliance
          </h3>
          <Badge variant="outline">Verified Platform</Badge>
        </div>
        <p className="text-xs text-[#6B6B6B] leading-relaxed max-w-3xl">
          We maintain strict adherence to automotive consumer protection guidelines and transparent pricing disclosures. All specifications, mileage readings, and condition reports are documented in full accordance with regulatory standards.
        </p>
      </div>
    </div>
  );
};
