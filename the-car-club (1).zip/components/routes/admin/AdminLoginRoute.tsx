import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Lock,
  Mail,
  ArrowLeft,
  Eye,
  EyeOff,
  Loader2,
  AlertCircle,
  UserPlus,
  KeyRound,
  CheckCircle2,
  Sparkles,
  Send,
  HelpCircle,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { loginSchema, firstAdminSetupSchema } from '@/lib/validations/auth';
import { useAuth } from '@/lib/auth';

interface AdminLoginRouteProps {
  onNavigate: (path: string) => void;
}

export const AdminLoginRoute: React.FC<AdminLoginRouteProps> = ({ onNavigate }) => {
  const {
    signIn,
    setupFirstAdmin,
    resendConfirmationEmail,
    isAdmin,
    isLoading: isAuthLoading,
    isConfigured,
    error: authContextError,
    clearError,
    enableDevBypass,
  } = useAuth();

  const [mode, setMode] = useState<'login' | 'first-admin'>('login');
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [setupData, setSetupData] = useState({ fullName: '', email: '', password: '' });
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isResending, setIsResending] = useState<boolean>(false);
  const [resendFeedback, setResendFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
  const [statusMessage, setStatusMessage] = useState<{ type: 'error' | 'success'; text: string } | null>(null);

  const handleResendConfirmation = async () => {
    const targetEmail = formData.email.trim() || setupData.email.trim();
    if (!targetEmail) {
      setResendFeedback({
        type: 'error',
        message: 'Please enter your administrative email address in the field above first.',
      });
      return;
    }

    setIsResending(true);
    setResendFeedback(null);
    try {
      const result = await resendConfirmationEmail(targetEmail);
      if (result.success) {
        setResendFeedback({
          type: 'success',
          message: `Confirmation email re-sent to ${targetEmail} with this live application's redirect link! Please check your inbox.`,
        });
      } else {
        setResendFeedback({
          type: 'error',
          message: result.error || 'Unable to resend confirmation email. Please check your Supabase dashboard.',
        });
      }
    } catch (err) {
      setResendFeedback({
        type: 'error',
        message: err instanceof Error ? err.message : 'Failed to trigger confirmation email.',
      });
    } finally {
      setIsResending(false);
    }
  };

  // Extract redirect query param from window location if available
  const getRedirectTarget = (): string => {
    if (typeof window !== 'undefined') {
      const searchParams = new URLSearchParams(window.location.search);
      const redirect = searchParams.get('redirect');
      if (redirect && redirect.startsWith('/admin') && redirect !== '/admin/login') {
        return redirect;
      }
    }
    return '/admin';
  };

  // If already authenticated as admin, automatically redirect to target
  useEffect(() => {
    if (!isAuthLoading && isAdmin) {
      onNavigate(getRedirectTarget());
    }
  }, [isAdmin, isAuthLoading, onNavigate]);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    setStatusMessage(null);

    const validation = loginSchema.safeParse(formData);
    if (!validation.success) {
      const errMap: { [key: string]: string } = {};
      validation.error.issues.forEach((err) => {
        if (err.path[0]) {
          errMap[err.path[0].toString()] = err.message;
        }
      });
      setFormErrors(errMap);
      return;
    }

    setFormErrors({});
    setIsSubmitting(true);

    try {
      const result = await signIn(formData.email, formData.password);
      if (result.success) {
        onNavigate(getRedirectTarget());
      } else {
        setStatusMessage({
          type: 'error',
          text: result.error || 'Authentication rejected. Access restricted to verified administrators.',
        });
      }
    } catch (err: unknown) {
      setStatusMessage({
        type: 'error',
        text: err instanceof Error ? err.message : 'Authentication service error occurred.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFirstAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    setStatusMessage(null);

    const validation = firstAdminSetupSchema.safeParse(setupData);
    if (!validation.success) {
      const errMap: { [key: string]: string } = {};
      validation.error.issues.forEach((err) => {
        if (err.path[0]) {
          errMap[err.path[0].toString()] = err.message;
        }
      });
      setFormErrors(errMap);
      return;
    }

    setFormErrors({});
    setIsSubmitting(true);

    try {
      const result = await setupFirstAdmin(
        setupData.fullName,
        setupData.email,
        setupData.password
      );

      if (result.success && !result.error) {
        setStatusMessage({
          type: 'success',
          text: 'Initial administrator profile registered successfully! Entering admin terminal...',
        });
        setTimeout(() => {
          onNavigate(getRedirectTarget());
        }, 800);
      } else if (result.success && result.error) {
        setStatusMessage({
          type: 'success',
          text: result.error,
        });
      } else {
        setStatusMessage({
          type: 'error',
          text: result.error || 'First-admin setup could not be completed.',
        });
      }
    } catch (err: unknown) {
      setStatusMessage({
        type: 'error',
        text: err instanceof Error ? err.message : 'Unexpected failure during administrator provisioning.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md space-y-6">
        {/* Return link */}
        <button
          onClick={() => onNavigate('/')}
          className="inline-flex items-center text-xs text-[#6B6B6B] hover:text-[#111111] transition-colors gap-1.5 cursor-pointer"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Return to Public Showroom</span>
        </button>

        {/* Configuration Notice if Supabase credentials are not yet supplied */}
        {!isConfigured && (
          <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-xs text-amber-900 space-y-2">
            <div className="flex items-center gap-2 font-semibold">
              <Sparkles className="h-4 w-4 text-amber-700 shrink-0" />
              <span>Supabase Environment Pending</span>
            </div>
            <p className="text-[11px] leading-relaxed text-amber-800">
              Provide <code className="font-mono font-medium">NEXT_PUBLIC_SUPABASE_URL</code> and{' '}
              <code className="font-mono font-medium">NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY</code> for live Supabase Auth.
            </p>
            <div className="pt-1">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  enableDevBypass();
                  onNavigate(getRedirectTarget());
                }}
                className="w-full text-xs border-amber-300 bg-white hover:bg-amber-100 text-amber-900"
              >
                Access Admin via Dev Preview Mode
              </Button>
            </div>
          </div>
        )}

        {/* Main Authentication Card */}
        <Card className="border-[#E5E5E5] bg-white shadow-sm">
          <CardHeader className="text-center space-y-2 pb-4">
            <div className="mx-auto h-12 w-12 rounded-full bg-[#111111] text-white flex items-center justify-center shadow-xs">
              <ShieldCheck className="h-6 w-6 text-white" />
            </div>
            <CardTitle className="text-xl font-bold tracking-tight text-[#111111]">
              The Car Club Portal
            </CardTitle>
            <CardDescription className="text-xs text-[#6B6B6B]">
              {mode === 'login'
                ? 'Authorized Dealership Staff & Inventory Console'
                : 'Initialize Primary Administrator Account'}
            </CardDescription>

            {/* Mode Switcher Tabs */}
            <div className="pt-2 flex rounded-md bg-[#F0F0EE] p-0.5 text-xs">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setFormErrors({});
                  setStatusMessage(null);
                  clearError();
                }}
                className={`flex-1 py-1.5 rounded-sm font-medium transition-all ${
                  mode === 'login'
                    ? 'bg-white text-[#111111] shadow-xs'
                    : 'text-[#6B6B6B] hover:text-[#111111]'
                }`}
              >
                Staff Login
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('first-admin');
                  setFormErrors({});
                  setStatusMessage(null);
                  clearError();
                }}
                className={`flex-1 py-1.5 rounded-sm font-medium transition-all ${
                  mode === 'first-admin'
                    ? 'bg-white text-[#111111] shadow-xs'
                    : 'text-[#6B6B6B] hover:text-[#111111]'
                }`}
              >
                First Admin Setup
              </button>
            </div>
          </CardHeader>

          <CardContent className="pt-2">
            {/* Status / Error Banner */}
            {(statusMessage || authContextError) && (() => {
              const errorText = statusMessage?.text || authContextError || '';
              const isEmailNotConfirmed = errorText.toLowerCase().includes('email not confirmed');
              const isRateLimit = errorText.toLowerCase().includes('rate limit');

              if (isRateLimit) {
                return (
                  <div className="mb-4 rounded-md border border-rose-300 bg-rose-50 p-3.5 text-xs text-rose-950 space-y-2.5">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="h-4 w-4 text-rose-700 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold text-rose-900">Email Rate Limit Exceeded</p>
                        <p className="text-[11px] text-rose-800 mt-0.5 leading-relaxed">
                          Supabase&apos;s free built-in SMTP has a strict limit of <strong>3-4 emails/hour</strong>. Because previous emails were attempted, Supabase is temporarily rejecting new email requests.
                        </p>
                      </div>
                    </div>

                    <div className="rounded bg-white/80 p-2.5 text-[11px] text-rose-950 space-y-2 border border-rose-200">
                      <p className="font-semibold text-rose-900 flex items-center gap-1.5">
                        <Sparkles className="h-3.5 w-3.5 text-rose-700" />
                        Instant Fix — Log in right now without waiting:
                      </p>
                      <ol className="list-decimal pl-4 space-y-1.5 text-rose-900 leading-relaxed">
                        <li>
                          Open your <strong>Supabase Dashboard</strong> → <strong>Authentication</strong> → <strong>Users</strong>.
                        </li>
                        <li>
                          Find your email ({formData.email.trim() || setupData.email.trim() || 'your email'}), click the <strong>&hellip;</strong> actions menu on the right, and select <strong>Confirm email</strong>.
                        </li>
                        <li>
                          <em>(Recommended)</em> In <strong>Authentication</strong> → <strong>Providers</strong> → <strong>Email</strong>, turn <strong>OFF &quot;Confirm email&quot;</strong> and save so this never blocks you again.
                        </li>
                        <li>
                          Switch to <strong>Staff Login</strong> below and enter your password. You will automatically enter the Admin Terminal!
                        </li>
                      </ol>
                    </div>

                    <Button
                      type="button"
                      size="sm"
                      onClick={() => {
                        setMode('login');
                        if (setupData.email && !formData.email) {
                          setFormData((prev) => ({ ...prev, email: setupData.email }));
                        }
                        setStatusMessage(null);
                        clearError();
                      }}
                      className="w-full text-xs bg-rose-800 hover:bg-rose-900 text-white font-medium cursor-pointer"
                    >
                      Switch to Staff Login
                    </Button>
                  </div>
                );
              }

              if (isEmailNotConfirmed) {
                return (
                  <div className="mb-4 rounded-md border border-amber-300 bg-amber-50 p-3.5 text-xs text-amber-950 space-y-2.5">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="h-4 w-4 text-amber-700 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold text-amber-900">Email Address Not Confirmed</p>
                        <p className="text-[11px] text-amber-800 mt-0.5 leading-relaxed">
                          The confirmation link you clicked redirected to <code className="font-mono bg-amber-100 px-1 py-0.5 rounded text-amber-900">localhost:3000</code> because Supabase defaults to localhost.
                        </p>
                      </div>
                    </div>

                    <div className="rounded bg-amber-100/70 p-2.5 text-[11px] text-amber-900 space-y-1.5 border border-amber-200">
                      <p className="font-semibold flex items-center gap-1.5">
                        <HelpCircle className="h-3.5 w-3.5 text-amber-700" />
                        Quick Solutions:
                      </p>
                      <ul className="list-disc pl-4 space-y-1 text-amber-900">
                        <li>
                          <strong>Fastest (1-Click in Supabase):</strong> In Supabase Dashboard → <strong>Authentication</strong> → <strong>Users</strong>, click <code className="font-mono">...</code> next to your email and select <strong>Confirm email</strong>.
                        </li>
                        <li>
                          <strong>Or Resend Email:</strong> Click the button below to send a fresh confirmation link pointing directly to this live domain (subject to Supabase hourly rate limit).
                        </li>
                      </ul>
                    </div>

                    {resendFeedback && (
                      <div
                        className={`rounded p-2 text-[11px] flex items-center gap-2 ${
                          resendFeedback.type === 'success'
                            ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                            : 'bg-red-100 text-red-900 border border-red-300'
                        }`}
                      >
                        {resendFeedback.type === 'success' ? (
                          <CheckCircle2 className="h-3.5 w-3.5 text-emerald-700 shrink-0" />
                        ) : (
                          <AlertCircle className="h-3.5 w-3.5 text-red-700 shrink-0" />
                        )}
                        <span>{resendFeedback.message}</span>
                      </div>
                    )}

                    <Button
                      type="button"
                      size="sm"
                      disabled={isResending}
                      onClick={handleResendConfirmation}
                      className="w-full text-xs bg-amber-800 hover:bg-amber-900 text-white font-medium cursor-pointer"
                    >
                      {isResending ? (
                        <span className="flex items-center justify-center gap-1.5">
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          Sending Live Confirmation Link...
                        </span>
                      ) : (
                        <span className="flex items-center justify-center gap-1.5">
                          <Send className="h-3.5 w-3.5" />
                          Resend Confirmation Email (Live URL)
                        </span>
                      )}
                    </Button>
                  </div>
                );
              }

              return (
                <div
                  className={`mb-4 rounded-md p-3 text-xs flex items-start gap-2.5 ${
                    statusMessage?.type === 'success'
                      ? 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                      : 'bg-red-50 text-red-900 border border-red-200'
                  }`}
                >
                  {statusMessage?.type === 'success' ? (
                    <CheckCircle2 className="h-4 w-4 text-emerald-700 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-red-700 shrink-0 mt-0.5" />
                  )}
                  <span className="leading-snug">{errorText}</span>
                </div>
              );
            })()}

            {mode === 'login' ? (
              /* LOGIN FORM */
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="admin-email" className="text-xs font-semibold text-[#111111]">
                    Administrative Email
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 h-4 w-4 text-[#6B6B6B]" />
                    <Input
                      id="admin-email"
                      type="email"
                      autoComplete="username"
                      disabled={isSubmitting}
                      placeholder="admin@thecarclub.example"
                      className={`pl-9 text-xs h-10 ${formErrors.email ? 'border-red-500' : ''}`}
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    />
                  </div>
                  {formErrors.email && (
                    <p className="text-[11px] text-red-600">{formErrors.email}</p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="admin-password" className="text-xs font-semibold text-[#111111]">
                      Staff Credential
                    </Label>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 h-4 w-4 text-[#6B6B6B]" />
                    <Input
                      id="admin-password"
                      type={showPassword ? 'text' : 'password'}
                      autoComplete="current-password"
                      disabled={isSubmitting}
                      placeholder="••••••••••••"
                      className={`pl-9 pr-9 text-xs h-10 ${formErrors.password ? 'border-red-500' : ''}`}
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    />
                    <button
                      type="button"
                      tabIndex={-1}
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-[#6B6B6B] hover:text-[#111111]"
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {formErrors.password && (
                    <p className="text-[11px] text-red-600">{formErrors.password}</p>
                  )}
                </div>

                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full text-xs h-10 font-semibold bg-[#111111] hover:bg-[#222222] text-white transition-all cursor-pointer"
                >
                  {isSubmitting ? (
                    <span className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Verifying Administrator Access...
                    </span>
                  ) : (
                    <span className="flex items-center justify-center gap-1.5">
                      <KeyRound className="h-3.5 w-3.5" />
                      Authenticate & Enter Console
                    </span>
                  )}
                </Button>
              </form>
            ) : (
              /* FIRST-TIME ADMIN SETUP FORM */
              <form onSubmit={handleFirstAdminSubmit} className="space-y-4">
                <div className="rounded bg-[#F7F7F5] p-3 text-[11px] text-[#6B6B6B] leading-relaxed border border-[#E5E5E5]">
                  <p className="font-semibold text-[#111111] mb-0.5">Initial Setup Requirement</p>
                  This form claims the primary <code className="font-mono text-[#173F35] font-bold">ADMIN</code> role.
                  Subsequent administrator creation requires invitation from an active administrator.
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="admin-name" className="text-xs font-semibold text-[#111111]">
                    Administrator Full Name
                  </Label>
                  <Input
                    id="admin-name"
                    type="text"
                    disabled={isSubmitting}
                    placeholder="e.g. Marcus Vance"
                    className={`text-xs h-10 ${formErrors.fullName ? 'border-red-500' : ''}`}
                    value={setupData.fullName}
                    onChange={(e) => setSetupData({ ...setupData, fullName: e.target.value })}
                  />
                  {formErrors.fullName && (
                    <p className="text-[11px] text-red-600">{formErrors.fullName}</p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="admin-setup-email" className="text-xs font-semibold text-[#111111]">
                    Dealership Email
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 h-4 w-4 text-[#6B6B6B]" />
                    <Input
                      id="admin-setup-email"
                      type="email"
                      disabled={isSubmitting}
                      placeholder="admin@thecarclub.example"
                      className={`pl-9 text-xs h-10 ${formErrors.email ? 'border-red-500' : ''}`}
                      value={setupData.email}
                      onChange={(e) => setSetupData({ ...setupData, email: e.target.value })}
                    />
                  </div>
                  {formErrors.email && (
                    <p className="text-[11px] text-red-600">{formErrors.email}</p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="admin-setup-password" className="text-xs font-semibold text-[#111111]">
                    Master Staff Credential
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 h-4 w-4 text-[#6B6B6B]" />
                    <Input
                      id="admin-setup-password"
                      type={showPassword ? 'text' : 'password'}
                      disabled={isSubmitting}
                      placeholder="Minimum 8 characters"
                      className={`pl-9 pr-9 text-xs h-10 ${formErrors.password ? 'border-red-500' : ''}`}
                      value={setupData.password}
                      onChange={(e) => setSetupData({ ...setupData, password: e.target.value })}
                    />
                    <button
                      type="button"
                      tabIndex={-1}
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-[#6B6B6B] hover:text-[#111111]"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {formErrors.password && (
                    <p className="text-[11px] text-red-600">{formErrors.password}</p>
                  )}
                </div>

                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full text-xs h-10 font-semibold bg-[#173F35] hover:bg-[#13322a] text-white transition-all cursor-pointer"
                >
                  {isSubmitting ? (
                    <span className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Provisioning First Administrator...
                    </span>
                  ) : (
                    <span className="flex items-center justify-center gap-1.5">
                      <UserPlus className="h-3.5 w-3.5" />
                      Provision & Initialize Admin Terminal
                    </span>
                  )}
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
