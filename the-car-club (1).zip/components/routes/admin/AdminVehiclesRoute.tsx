import React, { useState, useEffect, useMemo } from 'react';
import {
  PlusCircle,
  CarFront,
  Search,
  ExternalLink,
  Edit,
  Clock,
  CheckCircle2,
  AlertCircle,
  Eye,
  Filter,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  getAdminVehicles,
  VehicleWithMedia,
  VehicleStatus,
} from '@/lib/services/vehicle-service';

interface AdminVehiclesRouteProps {
  onNavigate: (path: string) => void;
}

export const AdminVehiclesRoute: React.FC<AdminVehiclesRouteProps> = ({ onNavigate }) => {
  const [vehicles, setVehicles] = useState<VehicleWithMedia[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<VehicleStatus | 'ALL'>('ALL');
  const [publicationFilter, setPublicationFilter] = useState<'ALL' | 'PUBLISHED' | 'UNPUBLISHED'>('ALL');

  const loadVehicles = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getAdminVehicles();
      if (res.error) {
        setError(res.error);
      } else {
        setVehicles(res.vehicles);
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to load vehicle inventory.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVehicles();
  }, []);

  // Compute live count stats
  const stats = useMemo(() => {
    return {
      all: vehicles.length,
      draft: vehicles.filter((v) => v.status === 'DRAFT').length,
      available: vehicles.filter((v) => v.status === 'AVAILABLE').length,
      reserved: vehicles.filter((v) => v.status === 'RESERVED').length,
      sold: vehicles.filter((v) => v.status === 'SOLD').length,
      archived: vehicles.filter((v) => v.status === 'ARCHIVED').length,
      published: vehicles.filter((v) => v.is_published).length,
      unpublished: vehicles.filter((v) => !v.is_published).length,
    };
  }, [vehicles]);

  // Apply in-memory search and filters for immediate responsiveness
  const filteredVehicles = useMemo(() => {
    return vehicles.filter((v) => {
      // Status filter
      if (statusFilter !== 'ALL' && v.status !== statusFilter) {
        return false;
      }
      // Publication filter
      if (publicationFilter === 'PUBLISHED' && !v.is_published) return false;
      if (publicationFilter === 'UNPUBLISHED' && v.is_published) return false;

      // Text search
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase().trim();
        const makeMatch = v.make.toLowerCase().includes(query);
        const modelMatch = v.model.toLowerCase().includes(query);
        const variantMatch = v.variant?.toLowerCase().includes(query);
        const stockMatch = v.stock_id.toLowerCase().includes(query);
        const regMatch = v.registration_number?.toLowerCase().includes(query);
        if (!makeMatch && !modelMatch && !variantMatch && !stockMatch && !regMatch) {
          return false;
        }
      }

      return true;
    });
  }, [vehicles, statusFilter, publicationFilter, searchQuery]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  const formatDate = (isoString: string) => {
    try {
      return new Date(isoString).toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      });
    } catch {
      return isoString;
    }
  };

  const getStatusBadge = (status: VehicleStatus) => {
    switch (status) {
      case 'AVAILABLE':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
            Available
          </span>
        );
      case 'RESERVED':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-100 text-amber-800 border border-amber-200">
            Reserved
          </span>
        );
      case 'SOLD':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-100 text-blue-800 border border-blue-200">
            Sold
          </span>
        );
      case 'ARCHIVED':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-zinc-100 text-zinc-600 border border-zinc-200">
            Archived
          </span>
        );
      case 'DRAFT':
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-zinc-200 text-zinc-800 border border-zinc-300">
            Draft
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Route Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5E5E5] pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-[#6B6B6B] mb-1">
            <span>Route:</span>
            <code className="bg-[#F0F0EE] px-1.5 py-0.5 rounded text-[#111111] font-mono">
              /admin/vehicles
            </code>
          </div>
          <h1 className="font-heading text-2xl sm:text-3xl font-bold text-[#111111]">
            Vehicle Inventory Management
          </h1>
          <p className="text-xs sm:text-sm text-[#6B6B6B] mt-1">
            Authoritative inventory register, lifecycle status control, media studio, and publishing integrity.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={loadVehicles}
            disabled={loading}
            className="text-xs gap-1.5 border-[#E5E5E5]"
            title="Refresh inventory"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Refresh</span>
          </Button>
          <Button
            variant="accent"
            size="sm"
            onClick={() => onNavigate('/admin/vehicles/new')}
            className="text-xs gap-1.5 shadow-sm"
          >
            <PlusCircle className="h-4 w-4" />
            <span>Intake Vehicle</span>
          </Button>
        </div>
      </div>

      {/* Error state if query fails */}
      {error && (
        <div className="p-4 rounded-lg bg-red-50 border border-red-200 flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-red-600 shrink-0 mt-0.5" />
          <div className="text-xs text-red-800 space-y-1">
            <p className="font-bold">Error Loading Vehicle Records</p>
            <p>{error}</p>
          </div>
        </div>
      )}

      {/* Metric Cards / Status Pills */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
        <button
          onClick={() => setStatusFilter('ALL')}
          className={`p-3 rounded-lg border text-left transition-all ${
            statusFilter === 'ALL'
              ? 'bg-[#111111] text-white border-[#111111] shadow-sm'
              : 'bg-white hover:bg-[#F7F7F5] border-[#E5E5E5] text-[#111111]'
          }`}
        >
          <div className="text-[10px] uppercase font-bold tracking-wider opacity-75">All Inventory</div>
          <div className="font-heading text-xl font-bold mt-0.5">{stats.all}</div>
        </button>

        <button
          onClick={() => setStatusFilter('AVAILABLE')}
          className={`p-3 rounded-lg border text-left transition-all ${
            statusFilter === 'AVAILABLE'
              ? 'bg-emerald-800 text-white border-emerald-800 shadow-sm'
              : 'bg-white hover:bg-emerald-50/50 border-[#E5E5E5] text-[#111111]'
          }`}
        >
          <div className="text-[10px] uppercase font-bold tracking-wider text-emerald-600">Available</div>
          <div className="font-heading text-xl font-bold mt-0.5 text-emerald-800">{stats.available}</div>
        </button>

        <button
          onClick={() => setStatusFilter('DRAFT')}
          className={`p-3 rounded-lg border text-left transition-all ${
            statusFilter === 'DRAFT'
              ? 'bg-zinc-800 text-white border-zinc-800 shadow-sm'
              : 'bg-white hover:bg-zinc-100 border-[#E5E5E5] text-[#111111]'
          }`}
        >
          <div className="text-[10px] uppercase font-bold tracking-wider text-[#6B6B6B]">Draft</div>
          <div className="font-heading text-xl font-bold mt-0.5 text-zinc-700">{stats.draft}</div>
        </button>

        <button
          onClick={() => setStatusFilter('RESERVED')}
          className={`p-3 rounded-lg border text-left transition-all ${
            statusFilter === 'RESERVED'
              ? 'bg-amber-800 text-white border-amber-800 shadow-sm'
              : 'bg-white hover:bg-amber-50/50 border-[#E5E5E5] text-[#111111]'
          }`}
        >
          <div className="text-[10px] uppercase font-bold tracking-wider text-amber-600">Reserved</div>
          <div className="font-heading text-xl font-bold mt-0.5 text-amber-800">{stats.reserved}</div>
        </button>

        <button
          onClick={() => setStatusFilter('SOLD')}
          className={`p-3 rounded-lg border text-left transition-all ${
            statusFilter === 'SOLD'
              ? 'bg-blue-800 text-white border-blue-800 shadow-sm'
              : 'bg-white hover:bg-blue-50/50 border-[#E5E5E5] text-[#111111]'
          }`}
        >
          <div className="text-[10px] uppercase font-bold tracking-wider text-blue-600">Sold</div>
          <div className="font-heading text-xl font-bold mt-0.5 text-blue-800">{stats.sold}</div>
        </button>

        <button
          onClick={() => setStatusFilter('ARCHIVED')}
          className={`p-3 rounded-lg border text-left transition-all ${
            statusFilter === 'ARCHIVED'
              ? 'bg-zinc-700 text-white border-zinc-700 shadow-sm'
              : 'bg-white hover:bg-zinc-100 border-[#E5E5E5] text-[#111111]'
          }`}
        >
          <div className="text-[10px] uppercase font-bold tracking-wider text-zinc-500">Archived</div>
          <div className="font-heading text-xl font-bold mt-0.5 text-zinc-600">{stats.archived}</div>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-lg border border-[#E5E5E5] bg-white flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-[#6B6B6B]" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search make, model, stock ID (e.g. TCC-00001), reg number..."
            className="pl-9 text-xs h-9"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <div className="flex items-center gap-1.5 text-[#6B6B6B] mr-1">
            <Filter className="h-3.5 w-3.5" />
            <span className="font-medium">Publication:</span>
          </div>

          <button
            onClick={() => setPublicationFilter('ALL')}
            className={`px-2.5 py-1 rounded text-xs transition-colors ${
              publicationFilter === 'ALL'
                ? 'bg-[#111111] text-white font-medium'
                : 'bg-[#F0F0EE] text-[#6B6B6B] hover:text-[#111111]'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setPublicationFilter('PUBLISHED')}
            className={`px-2.5 py-1 rounded text-xs flex items-center gap-1 transition-colors ${
              publicationFilter === 'PUBLISHED'
                ? 'bg-emerald-700 text-white font-medium'
                : 'bg-[#F0F0EE] text-[#6B6B6B] hover:text-[#111111]'
            }`}
          >
            <CheckCircle2 className="h-3 w-3" />
            <span>Published ({stats.published})</span>
          </button>
          <button
            onClick={() => setPublicationFilter('UNPUBLISHED')}
            className={`px-2.5 py-1 rounded text-xs transition-colors ${
              publicationFilter === 'UNPUBLISHED'
                ? 'bg-amber-700 text-white font-medium'
                : 'bg-[#F0F0EE] text-[#6B6B6B] hover:text-[#111111]'
            }`}
          >
            Unpublished ({stats.unpublished})
          </button>
        </div>
      </div>

      {/* Main Table / Grid Representation */}
      {loading ? (
        <Card className="border border-[#E5E5E5] bg-white">
          <CardContent className="py-16 text-center space-y-3">
            <RefreshCw className="h-8 w-8 text-[#173F35] animate-spin mx-auto" />
            <p className="text-xs text-[#6B6B6B] font-mono uppercase tracking-wider">
              Querying PostgreSQL vehicles registry...
            </p>
          </CardContent>
        </Card>
      ) : filteredVehicles.length === 0 ? (
        <Card className="border-dashed border-2 border-[#E5E5E5] bg-white text-center py-16">
          <CardContent className="space-y-4 max-w-md mx-auto">
            <div className="h-12 w-12 rounded-full bg-[#F7F7F5] flex items-center justify-center mx-auto text-[#173F35]">
              <CarFront className="h-6 w-6" />
            </div>
            <h3 className="font-heading text-base font-bold text-[#111111]">
              No Matching Vehicles Found
            </h3>
            <p className="text-xs text-[#6B6B6B] leading-relaxed">
              {searchQuery || statusFilter !== 'ALL' || publicationFilter !== 'ALL'
                ? 'No vehicle records matched the active search and filter criteria. Clear filters or add a new record.'
                : 'No vehicles are registered in the inventory ledger yet. Create your first vehicle record using the intake form.'}
            </p>

            <div className="pt-2 flex items-center justify-center gap-2">
              {(searchQuery || statusFilter !== 'ALL' || publicationFilter !== 'ALL') && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setSearchQuery('');
                    setStatusFilter('ALL');
                    setPublicationFilter('ALL');
                  }}
                  className="text-xs"
                >
                  Clear Filters
                </Button>
              )}
              <Button
                variant="accent"
                size="sm"
                onClick={() => onNavigate('/admin/vehicles/new')}
                className="text-xs gap-1.5"
              >
                <PlusCircle className="h-3.5 w-3.5" />
                <span>New Vehicle Intake</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="rounded-lg border border-[#E5E5E5] bg-white overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F7F7F5] border-b border-[#E5E5E5] text-[#6B6B6B] uppercase tracking-wider font-semibold text-[10px]">
                <tr>
                  <th className="py-3 px-4">Vehicle Identity</th>
                  <th className="py-3 px-4">Stock ID</th>
                  <th className="py-3 px-4">Specs</th>
                  <th className="py-3 px-4">Odometer</th>
                  <th className="py-3 px-4">Asking Price</th>
                  <th className="py-3 px-4">Lifecycle Status</th>
                  <th className="py-3 px-4">Public Showroom</th>
                  <th className="py-3 px-4">Last Updated</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E5E5E5]">
                {filteredVehicles.map((vehicle) => {
                  return (
                    <tr
                      key={vehicle.id}
                      className="hover:bg-[#F9F9F8] transition-colors group cursor-pointer"
                      onClick={() => onNavigate(`/admin/vehicles/${vehicle.id}`)}
                    >
                      {/* Identity & Cover Thumbnail */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="h-12 w-16 rounded overflow-hidden bg-[#F0F0EE] shrink-0 border border-[#E5E5E5] relative flex items-center justify-center">
                            {vehicle.cover_image_url ? (
                              <img
                                src={vehicle.cover_image_url}
                                alt={`${vehicle.make} ${vehicle.model}`}
                                className="h-full w-full object-cover"
                              />
                            ) : (
                              <CarFront className="h-5 w-5 text-[#6B6B6B]" />
                            )}
                          </div>
                          <div>
                            <div className="font-heading font-bold text-sm text-[#111111] group-hover:text-[#173F35] transition-colors">
                              {vehicle.manufacturing_year} {vehicle.make} {vehicle.model}
                            </div>
                            <div className="text-[11px] text-[#6B6B6B] flex items-center gap-2">
                              {vehicle.variant && <span>{vehicle.variant}</span>}
                              {vehicle.registration_number && (
                                <span className="font-mono bg-[#F0F0EE] px-1 py-0.2 rounded text-[10px] text-[#111111]">
                                  {vehicle.registration_number}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Stock ID */}
                      <td className="py-3.5 px-4">
                        <span className="font-mono text-xs font-semibold text-[#173F35] bg-[#E9EFEF] px-2 py-0.5 rounded">
                          {vehicle.stock_id}
                        </span>
                      </td>

                      {/* Specs */}
                      <td className="py-3.5 px-4 text-[#6B6B6B]">
                        <div className="flex flex-col gap-0.5 text-[11px]">
                          <span className="font-medium text-[#111111]">
                            {vehicle.fuel_type} • {vehicle.transmission}
                          </span>
                          <span>
                            {vehicle.owners === 1 ? 'Single Owner' : `${vehicle.owners} Owners`}
                            {vehicle.color && ` • ${vehicle.color}`}
                          </span>
                        </div>
                      </td>

                      {/* Odometer */}
                      <td className="py-3.5 px-4">
                        <span className="font-mono text-xs font-medium text-[#111111]">
                          {vehicle.kilometers.toLocaleString('en-IN')} km
                        </span>
                      </td>

                      {/* Asking Price */}
                      <td className="py-3.5 px-4">
                        <div className="font-heading font-bold text-xs text-[#111111]">
                          {formatPrice(vehicle.asking_price)}
                        </div>
                        {vehicle.purchase_price && (
                          <div className="text-[10px] text-[#6B6B6B] font-mono">
                            Cost: {formatPrice(vehicle.purchase_price)}
                          </div>
                        )}
                      </td>

                      {/* Lifecycle Status */}
                      <td className="py-3.5 px-4">
                        {getStatusBadge(vehicle.status)}
                      </td>

                      {/* Publication State */}
                      <td className="py-3.5 px-4">
                        {vehicle.is_published ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700">
                            <span className="h-1.5 w-1.5 rounded-full bg-emerald-600"></span>
                            Published
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] text-[#6B6B6B]">
                            <span className="h-1.5 w-1.5 rounded-full bg-zinc-400"></span>
                            Unpublished
                          </span>
                        )}
                      </td>

                      {/* Updated Date */}
                      <td className="py-3.5 px-4 text-[#6B6B6B] text-[11px]">
                        {formatDate(vehicle.updated_at)}
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1.5">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onNavigate(`/admin/vehicles/${vehicle.id}`)}
                            className="h-8 px-2.5 text-xs text-[#111111] hover:text-[#173F35] hover:bg-[#F0F0EE] gap-1"
                          >
                            <Edit className="h-3.5 w-3.5" />
                            <span>Manage</span>
                          </Button>

                          {vehicle.is_published && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onNavigate(`/cars/${vehicle.slug}`)}
                              className="h-8 w-8 p-0 text-[#6B6B6B] hover:text-[#111111]"
                              title="View on Public Showroom"
                            >
                              <ExternalLink className="h-3.5 w-3.5" />
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="p-3 bg-[#F7F7F5] border-t border-[#E5E5E5] flex items-center justify-between text-[11px] text-[#6B6B6B]">
            <span>
              Showing {filteredVehicles.length} of {vehicles.length} vehicle records
            </span>
            <div className="flex items-center gap-2">
              <span className="inline-block h-2 w-2 rounded-full bg-emerald-500"></span>
              <span>Publishing Integrity Trigger Active</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
