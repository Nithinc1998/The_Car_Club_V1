import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  CarFront,
  CheckCircle2,
  AlertCircle,
  Plus,
  X,
  ShieldAlert,
  Sparkles,
  HelpCircle,
  Save,
  Image as ImageIcon,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  vehicleSchema,
  VehicleFormValues,
  vehicleFuelTypes,
  vehicleTransmissions,
  vehicleConditions,
  serviceHistoryStatuses,
  vehicleStatuses,
  VehicleFuelType,
  VehicleTransmission,
  VehicleCondition,
  ServiceHistoryStatus,
  VehicleStatus,
} from '@/lib/validations/vehicle';
import { createVehicle } from '@/lib/services/vehicle-service';
import { useAuth } from '@/lib/auth';

interface AdminNewVehicleRouteProps {
  onNavigate: (path: string) => void;
}

// Popular luxury equipment presets for rapid dealer input
const POPULAR_FEATURES = [
  'Sport Chrono Package',
  'Front Axle Lift System',
  'PCCB Ceramic Composite Brakes',
  'Full Carbon Bucket Seats',
  'Matrix LED Headlights with PDLS+',
  'Burmester 3D High-End Surround',
  'BOSE Surround Sound',
  'Panoramic Glass Sunroof',
  'Adaptive Air Suspension',
  'Head-Up Display',
  'Apple CarPlay & Android Auto',
  '360-Degree Surround Camera',
  'Soft-Close Doors',
  'Ventilated & Heated Seats',
  'Active Exhaust System',
];

const POPULAR_ACCESSORIES = [
  'Factory Indoor Car Cover',
  'Battery Maintainer Charger',
  'Dual Master Key Fobs in Paint Match',
  'Rubber All-Weather Mats',
  'Spare Wheel Kit with Tool Roll',
  'OEM Display Key',
];

export const AdminNewVehicleRoute: React.FC<AdminNewVehicleRouteProps> = ({ onNavigate }) => {
  const { user } = useAuth();

  const [formData, setFormData] = useState<VehicleFormValues>({
    make: '',
    model: '',
    variant: '',
    slug: '',
    registration_number: '',
    manufacturing_year: new Date().getFullYear(),
    registration_year: new Date().getFullYear(),
    fuel_type: 'PETROL',
    transmission: 'AUTOMATIC',
    kilometers: 0,
    owners: 1,
    color: '',
    asking_price: 0,
    purchase_price: undefined,
    condition: 'EXCELLENT',
    condition_notes: '',
    service_history: 'FULL',
    service_history_notes: '',
    inspection_notes: '',
    features: ['Sport Chrono Package', 'BOSE Surround Sound'],
    accessories: ['Dual Master Key Fobs in Paint Match'],
    short_description: '',
    description: '',
    status: 'DRAFT',
    is_published: false,
  });

  const [customFeature, setCustomFeature] = useState('');
  const [customAccessory, setCustomAccessory] = useState('');
  const [manualSlug, setManualSlug] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [createdVehicleId, setCreatedVehicleId] = useState<string | null>(null);

  // Auto-generate slug when make, model, variant, or year change (unless manually edited)
  useEffect(() => {
    if (!manualSlug && (formData.make || formData.model)) {
      const parts = [
        formData.make,
        formData.model,
        formData.variant,
        formData.manufacturing_year,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)+/g, '');

      setFormData((prev) => ({ ...prev, slug: parts }));
    }
  }, [formData.make, formData.model, formData.variant, formData.manufacturing_year, manualSlug]);

  const handleAddFeature = (feat: string) => {
    const trimmed = feat.trim();
    if (!trimmed || formData.features.includes(trimmed)) return;
    setFormData((prev) => ({
      ...prev,
      features: [...prev.features, trimmed],
    }));
  };

  const handleRemoveFeature = (feat: string) => {
    setFormData((prev) => ({
      ...prev,
      features: prev.features.filter((f) => f !== feat),
    }));
  };

  const handleAddAccessory = (acc: string) => {
    const trimmed = acc.trim();
    if (!trimmed || formData.accessories.includes(trimmed)) return;
    setFormData((prev) => ({
      ...prev,
      accessories: [...prev.accessories, trimmed],
    }));
  };

  const handleRemoveAccessory = (acc: string) => {
    setFormData((prev) => ({
      ...prev,
      accessories: prev.accessories.filter((a) => a !== acc),
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);
    setErrors({});

    // Client-side schema check
    const validation = vehicleSchema.safeParse(formData);
    if (!validation.success) {
      const errMap: { [key: string]: string } = {};
      validation.error.issues.forEach((err) => {
        if (err.path[0]) {
          errMap[err.path[0].toString()] = err.message;
        }
      });
      setErrors(errMap);
      setSubmitError('Please address the highlighted validation issues before proceeding.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await createVehicle(validation.data, user?.id);
      if (res.error) {
        setSubmitError(res.error);
        setIsSubmitting(false);
        return;
      }

      if (res.vehicle) {
        setCreatedVehicleId(res.vehicle.id);
      }
    } catch (err: unknown) {
      setSubmitError(err instanceof Error ? err.message : 'Failed to create vehicle record.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (createdVehicleId) {
    return (
      <div className="max-w-2xl mx-auto py-12 space-y-6">
        <div className="p-8 rounded-xl bg-white border border-[#E5E5E5] shadow-sm text-center space-y-5">
          <div className="h-14 w-14 rounded-full bg-emerald-100 flex items-center justify-center mx-auto text-emerald-800">
            <CheckCircle2 className="h-8 w-8" />
          </div>

          <div>
            <h2 className="font-heading text-2xl font-bold text-[#111111]">
              Vehicle Intake Complete
            </h2>
            <p className="text-xs text-[#6B6B6B] mt-1 max-w-md mx-auto">
              The vehicle specification record has been validated and recorded in the database ledger with an initial provenance event.
            </p>
          </div>

          <div className="p-4 rounded-lg bg-[#F7F7F5] border border-[#E5E5E5] text-left text-xs space-y-1.5 font-mono">
            <div className="flex justify-between">
              <span className="text-[#6B6B6B]">Identity:</span>
              <span className="font-bold text-[#111111]">
                {formData.manufacturing_year} {formData.make} {formData.model}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#6B6B6B]">Initial Status:</span>
              <span className="font-bold text-zinc-700">{formData.status}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#6B6B6B]">Showroom State:</span>
              <span className="font-bold text-amber-700">Unpublished (Awaiting Media)</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <Button
              variant="accent"
              onClick={() => onNavigate(`/admin/vehicles/${createdVehicleId}`)}
              className="w-full sm:w-auto text-xs gap-2"
            >
              <ImageIcon className="h-4 w-4" />
              <span>Attach Media in Vehicle Studio →</span>
            </Button>

            <Button
              variant="outline"
              onClick={() => onNavigate('/admin/vehicles')}
              className="w-full sm:w-auto text-xs"
            >
              Back to Inventory Register
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Route Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5E5E5] pb-4">
        <button
          type="button"
          onClick={() => onNavigate('/admin/vehicles')}
          className="inline-flex items-center text-xs text-[#6B6B6B] hover:text-[#111111] transition-colors gap-1.5"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Back to Inventory Master</span>
        </button>

        <div className="flex items-center gap-2 text-xs text-[#6B6B6B]">
          <span>Route:</span>
          <code className="bg-[#F0F0EE] px-1.5 py-0.5 rounded text-[#111111] font-mono">
            /admin/vehicles/new
          </code>
        </div>
      </div>

      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="font-heading text-2xl sm:text-3xl font-bold text-[#111111]">
            New Vehicle Intake Specification
          </h1>
          <p className="text-xs sm:text-sm text-[#6B6B6B] mt-1">
            Capture authentic vehicle provenance, automotive specifications, dealer-private financial ledger details, and equipment.
          </p>
        </div>

        {submitError && (
          <div className="p-4 rounded-lg bg-red-50 border border-red-200 flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-red-600 shrink-0 mt-0.5" />
            <div className="text-xs text-red-800 space-y-1">
              <p className="font-bold">Cannot Complete Vehicle Intake</p>
              <p>{submitError}</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Section 1: Vehicle Identification */}
          <Card className="border border-[#E5E5E5]">
            <CardHeader className="border-b border-[#E5E5E5] pb-4">
              <CardTitle className="text-base flex items-center gap-2 text-[#111111]">
                <CarFront className="h-4 w-4 text-[#173F35]" />
                <span>1. Core Automotive Identification</span>
              </CardTitle>
              <CardDescription className="text-xs">
                Essential identification values registered in the inventory ledger.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="make" className="text-xs font-semibold text-[#111111]">
                    Make <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="make"
                    placeholder="e.g. Porsche, Mercedes-AMG"
                    value={formData.make}
                    onChange={(e) => setFormData({ ...formData, make: e.target.value })}
                    className={`text-xs ${errors.make ? 'border-red-500' : ''}`}
                  />
                  {errors.make && <p className="text-[11px] text-red-600">{errors.make}</p>}
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="model" className="text-xs font-semibold text-[#111111]">
                    Model <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="model"
                    placeholder="e.g. 911 GT3, G 63, M4"
                    value={formData.model}
                    onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                    className={`text-xs ${errors.model ? 'border-red-500' : ''}`}
                  />
                  {errors.model && <p className="text-[11px] text-red-600">{errors.model}</p>}
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="variant" className="text-xs font-semibold text-[#111111]">
                    Variant / Edition / Trim
                  </Label>
                  <Input
                    id="variant"
                    placeholder="e.g. Touring Package, Competition"
                    value={formData.variant || ''}
                    onChange={(e) => setFormData({ ...formData, variant: e.target.value })}
                    className="text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="slug" className="text-xs font-semibold text-[#111111]">
                      Showroom URL Slug <span className="text-red-500">*</span>
                    </Label>
                    <button
                      type="button"
                      onClick={() => setManualSlug(!manualSlug)}
                      className="text-[10px] text-[#173F35] hover:underline"
                    >
                      {manualSlug ? 'Auto-generate from name' : 'Customize URL slug'}
                    </button>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs text-[#6B6B6B] font-mono shrink-0">/cars/</span>
                    <Input
                      id="slug"
                      value={formData.slug}
                      readOnly={!manualSlug}
                      onChange={(e) => setFormData({ ...formData, slug: e.target.value.toLowerCase() })}
                      className={`text-xs font-mono ${errors.slug ? 'border-red-500' : ''} ${
                        !manualSlug ? 'bg-[#F7F7F5]' : ''
                      }`}
                    />
                  </div>
                  {errors.slug && <p className="text-[11px] text-red-600">{errors.slug}</p>}
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="registration_number" className="text-xs font-semibold text-[#111111]">
                    Registration Number (RC)
                  </Label>
                  <Input
                    id="registration_number"
                    placeholder="e.g. MH 02 EF 9110"
                    value={formData.registration_number || ''}
                    onChange={(e) => setFormData({ ...formData, registration_number: e.target.value.toUpperCase() })}
                    className="text-xs font-mono uppercase"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Section 2: Technical Specifications & Provenance */}
          <Card className="border border-[#E5E5E5]">
            <CardHeader className="border-b border-[#E5E5E5] pb-4">
              <CardTitle className="text-base text-[#111111]">
                2. Mechanical Specifications & Metrics
              </CardTitle>
              <CardDescription className="text-xs">
                Accurate powertrain and odometer parameters enforced by database constraints.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="manufacturing_year" className="text-xs font-semibold text-[#111111]">
                    Mfg Year <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="manufacturing_year"
                    type="number"
                    value={formData.manufacturing_year}
                    onChange={(e) =>
                      setFormData({ ...formData, manufacturing_year: parseInt(e.target.value) || 0 })
                    }
                    className={`text-xs ${errors.manufacturing_year ? 'border-red-500' : ''}`}
                  />
                  {errors.manufacturing_year && (
                    <p className="text-[11px] text-red-600">{errors.manufacturing_year}</p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="registration_year" className="text-xs font-semibold text-[#111111]">
                    Reg Year
                  </Label>
                  <Input
                    id="registration_year"
                    type="number"
                    value={formData.registration_year || ''}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        registration_year: e.target.value ? parseInt(e.target.value) : undefined,
                      })
                    }
                    className={`text-xs ${errors.registration_year ? 'border-red-500' : ''}`}
                  />
                  {errors.registration_year && (
                    <p className="text-[11px] text-red-600">{errors.registration_year}</p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="fuel_type" className="text-xs font-semibold text-[#111111]">
                    Fuel Type <span className="text-red-500">*</span>
                  </Label>
                  <select
                    id="fuel_type"
                    value={formData.fuel_type}
                    onChange={(e) => setFormData({ ...formData, fuel_type: e.target.value as VehicleFuelType })}
                    className="w-full h-9 rounded-md border border-[#E5E5E5] bg-white px-3 text-xs text-[#111111] focus:ring-1 focus:ring-[#173F35]"
                  >
                    {vehicleFuelTypes.map((ft) => (
                      <option key={ft} value={ft}>
                        {ft}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="transmission" className="text-xs font-semibold text-[#111111]">
                    Transmission <span className="text-red-500">*</span>
                  </Label>
                  <select
                    id="transmission"
                    value={formData.transmission}
                    onChange={(e) => setFormData({ ...formData, transmission: e.target.value as VehicleTransmission })}
                    className="w-full h-9 rounded-md border border-[#E5E5E5] bg-white px-3 text-xs text-[#111111] focus:ring-1 focus:ring-[#173F35]"
                  >
                    {vehicleTransmissions.map((tr) => (
                      <option key={tr} value={tr}>
                        {tr}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="kilometers" className="text-xs font-semibold text-[#111111]">
                    Kilometers (Odometer) <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="kilometers"
                    type="number"
                    value={formData.kilometers}
                    onChange={(e) =>
                      setFormData({ ...formData, kilometers: parseInt(e.target.value) || 0 })
                    }
                    className={`text-xs ${errors.kilometers ? 'border-red-500' : ''}`}
                  />
                  {errors.kilometers && (
                    <p className="text-[11px] text-red-600">{errors.kilometers}</p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="owners" className="text-xs font-semibold text-[#111111]">
                    Previous Owners <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="owners"
                    type="number"
                    value={formData.owners}
                    onChange={(e) => setFormData({ ...formData, owners: parseInt(e.target.value) || 0 })}
                    className={`text-xs ${errors.owners ? 'border-red-500' : ''}`}
                  />
                  {errors.owners && <p className="text-[11px] text-red-600">{errors.owners}</p>}
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="color" className="text-xs font-semibold text-[#111111]">
                    Exterior Paint Color
                  </Label>
                  <Input
                    id="color"
                    placeholder="e.g. GT Silver Metallic"
                    value={formData.color || ''}
                    onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                    className="text-xs"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Section 3: Commercial Ledger & Condition */}
          <Card className="border border-[#E5E5E5]">
            <CardHeader className="border-b border-[#E5E5E5] pb-4">
              <CardTitle className="text-base text-[#111111]">
                3. Financial Ledger & Condition Verification
              </CardTitle>
              <CardDescription className="text-xs">
                Asking price for the showroom and private purchase cost kept confidential.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="asking_price" className="text-xs font-semibold text-[#111111]">
                    Public Asking Price (₹ INR) <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="asking_price"
                    type="number"
                    value={formData.asking_price || ''}
                    placeholder="27500000"
                    onChange={(e) =>
                      setFormData({ ...formData, asking_price: parseFloat(e.target.value) || 0 })
                    }
                    className={`text-xs ${errors.asking_price ? 'border-red-500' : ''}`}
                  />
                  {errors.asking_price && (
                    <p className="text-[11px] text-red-600">{errors.asking_price}</p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="purchase_price" className="text-xs font-semibold text-[#111111]">
                      Purchase Cost (₹ INR)
                    </Label>
                    <span className="text-[10px] bg-zinc-100 text-zinc-600 px-1.5 py-0.5 rounded font-mono">
                      Confidential / Admin Only
                    </span>
                  </div>
                  <Input
                    id="purchase_price"
                    type="number"
                    value={formData.purchase_price || ''}
                    placeholder="24500000"
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        purchase_price: e.target.value ? parseFloat(e.target.value) : undefined,
                      })
                    }
                    className="text-xs bg-[#FCFCFA]"
                  />
                  <p className="text-[10px] text-[#6B6B6B]">
                    Purchase price is never exposed on public endpoints or customer views.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="space-y-1.5">
                  <Label htmlFor="condition" className="text-xs font-semibold text-[#111111]">
                    Condition Assessment
                  </Label>
                  <select
                    id="condition"
                    value={formData.condition || ''}
                    onChange={(e) => setFormData({ ...formData, condition: (e.target.value || null) as VehicleCondition | null })}
                    className="w-full h-9 rounded-md border border-[#E5E5E5] bg-white px-3 text-xs text-[#111111]"
                  >
                    {vehicleConditions.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="service_history" className="text-xs font-semibold text-[#111111]">
                    Service History Record
                  </Label>
                  <select
                    id="service_history"
                    value={formData.service_history || ''}
                    onChange={(e) =>
                      setFormData({ ...formData, service_history: (e.target.value || null) as ServiceHistoryStatus | null })
                    }
                    className="w-full h-9 rounded-md border border-[#E5E5E5] bg-white px-3 text-xs text-[#111111]"
                  >
                    {serviceHistoryStatuses.map((sh) => (
                      <option key={sh} value={sh}>
                        {sh}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="condition_notes" className="text-xs font-semibold text-[#111111]">
                    Condition & Paintwork Notes
                  </Label>
                  <textarea
                    id="condition_notes"
                    rows={2}
                    value={formData.condition_notes || ''}
                    onChange={(e) => setFormData({ ...formData, condition_notes: e.target.value })}
                    placeholder="e.g. Full PPF installed, flawless exterior paint, no repaints."
                    className="w-full rounded-md border border-[#E5E5E5] p-2 text-xs text-[#111111]"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="inspection_notes" className="text-xs font-semibold text-[#111111]">
                    Pre-Purchase Inspection Notes
                  </Label>
                  <textarea
                    id="inspection_notes"
                    rows={2}
                    value={formData.inspection_notes || ''}
                    onChange={(e) => setFormData({ ...formData, inspection_notes: e.target.value })}
                    placeholder="e.g. 111-point Porsche certification passed. Tyres at 85%."
                    className="w-full rounded-md border border-[#E5E5E5] p-2 text-xs text-[#111111]"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Section 4: Features & Accessories */}
          <Card className="border border-[#E5E5E5]">
            <CardHeader className="border-b border-[#E5E5E5] pb-4">
              <CardTitle className="text-base text-[#111111]">
                4. Equipment, Features & Factory Accessories
              </CardTitle>
              <CardDescription className="text-xs">
                Stored in Postgres as JSONB array primitives. Select presets or add custom equipment.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              {/* Features */}
              <div className="space-y-3">
                <Label className="text-xs font-semibold text-[#111111]">
                  Factory Equipment & Packages ({formData.features.length})
                </Label>

                {/* Selected tags */}
                <div className="flex flex-wrap gap-1.5 min-h-[36px] p-2 rounded-lg border border-[#E5E5E5] bg-[#F7F7F5]">
                  {formData.features.length === 0 ? (
                    <span className="text-xs text-[#6B6B6B] italic">No features selected yet.</span>
                  ) : (
                    formData.features.map((feat) => (
                      <span
                        key={feat}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-white border border-[#E5E5E5] text-xs text-[#111111]"
                      >
                        <span>{feat}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveFeature(feat)}
                          className="text-[#6B6B6B] hover:text-red-600"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </span>
                    ))
                  )}
                </div>

                {/* Quick Add popular features */}
                <div className="space-y-1.5">
                  <span className="text-[11px] text-[#6B6B6B]">Quick add standard specifications:</span>
                  <div className="flex flex-wrap gap-1">
                    {POPULAR_FEATURES.filter((f) => !formData.features.includes(f)).slice(0, 8).map((f) => (
                      <button
                        key={f}
                        type="button"
                        onClick={() => handleAddFeature(f)}
                        className="text-[11px] px-2 py-0.5 rounded border border-[#E5E5E5] bg-white hover:bg-[#F0F0EE] text-[#111111] transition-colors"
                      >
                        + {f}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Custom feature input */}
                <div className="flex items-center gap-2 max-w-md">
                  <Input
                    placeholder="Add bespoke equipment..."
                    value={customFeature}
                    onChange={(e) => setCustomFeature(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddFeature(customFeature);
                        setCustomFeature('');
                      }
                    }}
                    className="text-xs h-8"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      handleAddFeature(customFeature);
                      setCustomFeature('');
                    }}
                    className="text-xs h-8 shrink-0"
                  >
                    Add
                  </Button>
                </div>
              </div>

              {/* Accessories */}
              <div className="space-y-3 pt-4 border-t border-[#E5E5E5]">
                <Label className="text-xs font-semibold text-[#111111]">
                  Included Accessories ({formData.accessories.length})
                </Label>

                <div className="flex flex-wrap gap-1.5 min-h-[36px] p-2 rounded-lg border border-[#E5E5E5] bg-[#F7F7F5]">
                  {formData.accessories.length === 0 ? (
                    <span className="text-xs text-[#6B6B6B] italic">No accessories added.</span>
                  ) : (
                    formData.accessories.map((acc) => (
                      <span
                        key={acc}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-white border border-[#E5E5E5] text-xs text-[#111111]"
                      >
                        <span>{acc}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveAccessory(acc)}
                          className="text-[#6B6B6B] hover:text-red-600"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </span>
                    ))
                  )}
                </div>

                <div className="flex items-center gap-2 max-w-md">
                  <Input
                    placeholder="e.g. Original car cover, spare keys..."
                    value={customAccessory}
                    onChange={(e) => setCustomAccessory(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddAccessory(customAccessory);
                        setCustomAccessory('');
                      }
                    }}
                    className="text-xs h-8"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      handleAddAccessory(customAccessory);
                      setCustomAccessory('');
                    }}
                    className="text-xs h-8 shrink-0"
                  >
                    Add
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Section 5: Showroom Narrative */}
          <Card className="border border-[#E5E5E5]">
            <CardHeader className="border-b border-[#E5E5E5] pb-4">
              <CardTitle className="text-base text-[#111111]">
                5. Showroom Editorial Description
              </CardTitle>
              <CardDescription className="text-xs">
                Compelling vehicle provenance notes presented to connoisseurs.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="short_description" className="text-xs font-semibold text-[#111111]">
                  One-Line Showroom Summary
                </Label>
                <Input
                  id="short_description"
                  placeholder="e.g. Benchmark manual 992 GT3 Touring in GT Silver Metallic with carbon buckets."
                  value={formData.short_description || ''}
                  onChange={(e) => setFormData({ ...formData, short_description: e.target.value })}
                  className="text-xs"
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="description" className="text-xs font-semibold text-[#111111]">
                  Full Provenance & Specifications Narrative
                </Label>
                <textarea
                  id="description"
                  rows={4}
                  value={formData.description || ''}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Detail the acquisition story, ownership background, mechanical condition, and driving characteristics..."
                  className="w-full rounded-md border border-[#E5E5E5] p-3 text-xs text-[#111111] focus:ring-1 focus:ring-[#173F35]"
                />
              </div>
            </CardContent>
          </Card>

          {/* Section 6: Initial Lifecycle Status & Submission */}
          <Card className="border border-[#E5E5E5] bg-[#F7F7F5]">
            <CardContent className="pt-6 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h4 className="font-heading font-bold text-sm text-[#111111]">
                    Initial Status Configuration
                  </h4>
                  <p className="text-xs text-[#6B6B6B]">
                    New intakes enter as <code className="font-semibold text-[#111111]">DRAFT</code> by default. Media can be uploaded immediately after creation.
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="space-y-1">
                    <Label htmlFor="status" className="text-xs font-semibold text-[#111111]">
                      Status
                    </Label>
                    <select
                      id="status"
                      value={formData.status}
                      onChange={(e) => setFormData({ ...formData, status: e.target.value as VehicleStatus })}
                      className="h-9 rounded-md border border-[#E5E5E5] bg-white px-3 text-xs text-[#111111]"
                    >
                      {vehicleStatuses.map((st) => (
                        <option key={st} value={st}>
                          {st}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-[#E5E5E5] flex flex-col sm:flex-row items-center justify-end gap-3">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => onNavigate('/admin/vehicles')}
                  className="w-full sm:w-auto text-xs"
                >
                  Cancel
                </Button>

                <Button
                  type="submit"
                  variant="accent"
                  size="sm"
                  disabled={isSubmitting}
                  className="w-full sm:w-auto text-xs gap-1.5 shadow-sm"
                >
                  <Save className="h-4 w-4" />
                  <span>{isSubmitting ? 'Recording Intake...' : 'Create Vehicle Record'}</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </form>
      </div>
    </div>
  );
};
