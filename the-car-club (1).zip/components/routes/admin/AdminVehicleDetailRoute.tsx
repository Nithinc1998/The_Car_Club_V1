import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  CarFront,
  CheckCircle2,
  AlertCircle,
  Upload,
  Trash2,
  Star,
  ArrowUp,
  ArrowDown,
  Clock,
  ShieldCheck,
  ExternalLink,
  Save,
  Plus,
  X,
  FileText,
  Image as ImageIcon,
  Video,
  Eye,
  Archive,
  RefreshCw,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  getAdminVehicleById,
  updateVehicle,
  updateVehicleStatus,
  setVehiclePublished,
  addVehicleEventNote,
  deleteVehicle,
  VehicleDetailWithEvents,
  VehicleStatus,
} from '@/lib/services/vehicle-service';
import {
  uploadVehicleMedia,
  setCoverImage,
  reorderVehicleMedia,
  deleteVehicleMedia,
  VehicleMedia,
} from '@/lib/services/media-service';
import {
  vehicleSchema,
  VehicleFormValues,
  vehicleFuelTypes,
  vehicleTransmissions,
  vehicleConditions,
  serviceHistoryStatuses,
  vehicleStatuses,
  VehicleFuelType,
  VehicleTransmission,
  VehicleCondition,
  ServiceHistoryStatus,
} from '@/lib/validations/vehicle';
import { useAuth } from '@/lib/auth';

interface AdminVehicleDetailRouteProps {
  id: string;
  onNavigate: (path: string) => void;
}

export const AdminVehicleDetailRoute: React.FC<AdminVehicleDetailRouteProps> = ({
  id,
  onNavigate,
}) => {
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [vehicle, setVehicle] = useState<VehicleDetailWithEvents | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  // Active view tab
  const [activeTab, setActiveTab] = useState<'specs' | 'media' | 'events'>('specs');

  // Form State for editing specs
  const [formData, setFormData] = useState<VehicleFormValues | null>(null);
  const [savingSpecs, setSavingSpecs] = useState(false);
  const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});

  // Media upload state
  const [uploadMediaType, setUploadMediaType] = useState<'IMAGE' | 'VIDEO'>('IMAGE');
  const [uploadAltText, setUploadAltText] = useState('');
  const [uploadAsCover, setUploadAsCover] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [mediaActionId, setMediaActionId] = useState<string | null>(null);

  // Note event form
  const [newNote, setNewNote] = useState('');
  const [isAddingNote, setIsAddingNote] = useState(false);

  // Delete modal state
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isDeletingVehicle, setIsDeletingVehicle] = useState(false);

  // Load record
  const loadVehicle = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getAdminVehicleById(id);
      if (res.error || !res.vehicle) {
        setError(res.error || 'Vehicle record not found.');
      } else {
        setVehicle(res.vehicle);
        setFormData({
          make: res.vehicle.make,
          model: res.vehicle.model,
          variant: res.vehicle.variant || '',
          slug: res.vehicle.slug,
          registration_number: res.vehicle.registration_number || '',
          manufacturing_year: res.vehicle.manufacturing_year,
          registration_year: res.vehicle.registration_year || undefined,
          fuel_type: res.vehicle.fuel_type,
          transmission: res.vehicle.transmission,
          kilometers: res.vehicle.kilometers,
          owners: res.vehicle.owners,
          color: res.vehicle.color || '',
          asking_price: res.vehicle.asking_price,
          purchase_price: res.vehicle.purchase_price || undefined,
          condition: res.vehicle.condition || null,
          condition_notes: res.vehicle.condition_notes || '',
          service_history: res.vehicle.service_history || null,
          service_history_notes: res.vehicle.service_history_notes || '',
          inspection_notes: res.vehicle.inspection_notes || '',
          features: Array.isArray(res.vehicle.features) ? (res.vehicle.features as string[]) : [],
          accessories: Array.isArray(res.vehicle.accessories) ? (res.vehicle.accessories as string[]) : [],
          short_description: res.vehicle.short_description || '',
          description: res.vehicle.description || '',
          status: res.vehicle.status,
          is_published: res.vehicle.is_published,
        });
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to retrieve vehicle.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVehicle();
  }, [id]);

  const showNotification = (successMsg?: string, errorMsg?: string) => {
    if (successMsg) {
      setActionSuccess(successMsg);
      setActionError(null);
      setTimeout(() => setActionSuccess(null), 5000);
    }
    if (errorMsg) {
      setActionError(errorMsg);
      setActionSuccess(null);
      setTimeout(() => setActionError(null), 8000);
    }
  };

  // 1. Status Change Handler
  const handleStatusChange = async (newStatus: VehicleStatus) => {
    if (!vehicle) return;
    setActionError(null);
    const res = await updateVehicleStatus(vehicle.id, newStatus, user?.id);
    if (!res.success) {
      showNotification(undefined, res.error);
    } else {
      showNotification(`Vehicle lifecycle status successfully updated to ${newStatus}.`);
      loadVehicle();
    }
  };

  // 2. Publication Toggle Handler
  const handleTogglePublish = async () => {
    if (!vehicle) return;
    setActionError(null);
    const nextState = !vehicle.is_published;
    const res = await setVehiclePublished(vehicle.id, nextState, user?.id);
    if (!res.success) {
      showNotification(undefined, res.error);
    } else {
      showNotification(
        nextState
          ? 'Vehicle published successfully to the online showroom.'
          : 'Vehicle unpublished and withdrawn from public showroom.'
      );
      loadVehicle();
    }
  };

  // 3. Save Specifications
  const handleSaveSpecs = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!vehicle || !formData) return;

    setFormErrors({});
    setActionError(null);

    const validation = vehicleSchema.safeParse(formData);
    if (!validation.success) {
      const errMap: { [key: string]: string } = {};
      validation.error.issues.forEach((err) => {
        if (err.path[0]) {
          errMap[err.path[0].toString()] = err.message;
        }
      });
      setFormErrors(errMap);
      showNotification(undefined, 'Validation failed. Please review highlighted form fields.');
      return;
    }

    setSavingSpecs(true);
    try {
      const res = await updateVehicle(vehicle.id, validation.data, user?.id);
      if (res.error) {
        showNotification(undefined, res.error);
      } else {
        showNotification('Vehicle specifications updated successfully.');
        loadVehicle();
      }
    } catch (err: unknown) {
      showNotification(undefined, err instanceof Error ? err.message : 'Error updating specifications.');
    } finally {
      setSavingSpecs(false);
    }
  };

  // 4. File Upload Handler
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !vehicle) return;

    setIsUploading(true);
    setActionError(null);

    try {
      const res = await uploadVehicleMedia(
        vehicle.id,
        file,
        uploadMediaType,
        uploadAltText,
        uploadAsCover
      );

      if (res.error || !res.media) {
        showNotification(undefined, res.error || 'Failed to upload media.');
      } else {
        showNotification('Media asset uploaded and linked to vehicle successfully.');
        setUploadAltText('');
        setUploadAsCover(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
        loadVehicle();
      }
    } catch (err: unknown) {
      showNotification(undefined, err instanceof Error ? err.message : 'Media upload error.');
    } finally {
      setIsUploading(false);
    }
  };

  // 5. Set as Cover Image
  const handleSetCover = async (mediaId: string) => {
    if (!vehicle) return;
    setMediaActionId(mediaId);
    try {
      const res = await setCoverImage(mediaId, vehicle.id);
      if (!res.success) {
        showNotification(undefined, res.error);
      } else {
        showNotification('Cover photograph updated successfully.');
        loadVehicle();
      }
    } finally {
      setMediaActionId(null);
    }
  };

  // 6. Delete Media
  const handleDeleteMedia = async (mediaId: string) => {
    if (!vehicle) return;
    setMediaActionId(mediaId);
    try {
      const res = await deleteVehicleMedia(mediaId, vehicle.id);
      if (!res.success) {
        showNotification(undefined, res.error);
      } else {
        showNotification('Media asset removed successfully.');
        loadVehicle();
      }
    } finally {
      setMediaActionId(null);
    }
  };

  // 7. Move Media Sort Order
  const handleMoveMedia = async (mediaId: string, direction: 'UP' | 'DOWN') => {
    if (!vehicle || !vehicle.media) return;
    const mediaList = [...vehicle.media];
    const index = mediaList.findIndex((m) => m.id === mediaId);
    if (index === -1) return;

    if (direction === 'UP' && index > 0) {
      const temp = mediaList[index];
      mediaList[index] = mediaList[index - 1];
      mediaList[index - 1] = temp;
    } else if (direction === 'DOWN' && index < mediaList.length - 1) {
      const temp = mediaList[index];
      mediaList[index] = mediaList[index + 1];
      mediaList[index + 1] = temp;
    } else {
      return;
    }

    const orderedIds = mediaList.map((m) => m.id);
    const res = await reorderVehicleMedia(vehicle.id, orderedIds);
    if (!res.success) {
      showNotification(undefined, res.error);
    } else {
      loadVehicle();
    }
  };

  // 8. Add Internal Event Note
  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!vehicle || !newNote.trim()) return;

    setIsAddingNote(true);
    try {
      const res = await addVehicleEventNote(vehicle.id, newNote, user?.id);
      if (!res.success) {
        showNotification(undefined, res.error);
      } else {
        setNewNote('');
        showNotification('Administrative timeline note logged successfully.');
        loadVehicle();
      }
    } finally {
      setIsAddingNote(false);
    }
  };

  // 9. Delete Vehicle Entirely
  const handleDeleteVehicle = async () => {
    if (!vehicle) return;
    setIsDeletingVehicle(true);
    try {
      const res = await deleteVehicle(vehicle.id);
      if (!res.success) {
        showNotification(undefined, res.error);
        setIsDeletingVehicle(false);
        setShowDeleteModal(false);
      } else {
        onNavigate('/admin/vehicles');
      }
    } catch (err: unknown) {
      showNotification(undefined, err instanceof Error ? err.message : 'Failed to delete vehicle.');
      setIsDeletingVehicle(false);
      setShowDeleteModal(false);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  if (loading) {
    return (
      <div className="py-24 text-center space-y-3">
        <RefreshCw className="h-8 w-8 text-[#173F35] animate-spin mx-auto" />
        <p className="text-xs text-[#6B6B6B] font-mono">Loading vehicle record...</p>
      </div>
    );
  }

  if (error || !vehicle || !formData) {
    return (
      <div className="max-w-xl mx-auto py-16 space-y-4 text-center">
        <div className="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center mx-auto text-red-700">
          <AlertCircle className="h-6 w-6" />
        </div>
        <h2 className="font-heading text-xl font-bold text-[#111111]">
          Vehicle Record Not Found
        </h2>
        <p className="text-xs text-[#6B6B6B]">
          {error || `No record matching identifier "${id}" exists in the inventory ledger.`}
        </p>
        <Button
          variant="outline"
          size="sm"
          onClick={() => onNavigate('/admin/vehicles')}
          className="text-xs"
        >
          Return to Vehicles
        </Button>
      </div>
    );
  }

  const imageCount = (vehicle.media || []).filter((m) => m.media_type === 'IMAGE').length;
  const videoCount = (vehicle.media || []).filter((m) => m.media_type === 'VIDEO').length;

  return (
    <div className="space-y-6">
      {/* Route & Back Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5E5E5] pb-4">
        <button
          type="button"
          onClick={() => onNavigate('/admin/vehicles')}
          className="inline-flex items-center text-xs text-[#6B6B6B] hover:text-[#111111] transition-colors gap-1.5"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Back to Inventory Master</span>
        </button>

        <div className="flex items-center gap-2 text-xs text-[#6B6B6B]">
          <span>Record ID:</span>
          <code className="bg-[#F0F0EE] px-1.5 py-0.5 rounded text-[#111111] font-mono text-[11px]">
            {vehicle.id}
          </code>
        </div>
      </div>

      {/* Notifications */}
      {actionSuccess && (
        <div className="p-3.5 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center gap-2.5 text-xs text-emerald-900 animate-in fade-in">
          <CheckCircle2 className="h-4 w-4 text-emerald-700 shrink-0" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {actionError && (
        <div className="p-3.5 rounded-lg bg-red-50 border border-red-200 flex items-start gap-2.5 text-xs text-red-900 animate-in fade-in">
          <AlertCircle className="h-4 w-4 text-red-700 shrink-0 mt-0.5" />
          <span>{actionError}</span>
        </div>
      )}

      {/* Main Vehicle Header Bar */}
      <div className="p-6 rounded-xl border border-[#E5E5E5] bg-white space-y-4 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-xs font-bold text-[#173F35] bg-[#E9EFEF] px-2.5 py-0.5 rounded">
                {vehicle.stock_id}
              </span>
              {vehicle.registration_number && (
                <span className="font-mono text-xs font-semibold bg-[#F0F0EE] text-[#111111] px-2 py-0.5 rounded">
                  {vehicle.registration_number}
                </span>
              )}
              {vehicle.is_published ? (
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-600"></span>
                  Published to Showroom
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-xs text-[#6B6B6B] bg-[#F0F0EE] px-2 py-0.5 rounded">
                  <span className="h-1.5 w-1.5 rounded-full bg-zinc-400"></span>
                  Unpublished
                </span>
              )}
            </div>

            <h1 className="font-heading text-2xl sm:text-3xl font-extrabold text-[#111111]">
              {vehicle.manufacturing_year} {vehicle.make} {vehicle.model}{' '}
              {vehicle.variant && (
                <span className="font-normal text-[#6B6B6B] text-xl sm:text-2xl">
                  {vehicle.variant}
                </span>
              )}
            </h1>

            <p className="text-xs text-[#6B6B6B] flex items-center gap-2">
              <span>{formatPrice(vehicle.asking_price)}</span>
              <span>•</span>
              <span>{vehicle.kilometers.toLocaleString('en-IN')} km</span>
              <span>•</span>
              <span>{vehicle.fuel_type}</span>
              <span>•</span>
              <span>{vehicle.transmission}</span>
            </p>
          </div>

          {/* Quick Lifecycle & Publishing Controls */}
          <div className="flex flex-wrap items-center gap-2.5 pt-2 lg:pt-0">
            {/* Status Selector */}
            <div className="flex items-center gap-1.5 bg-[#F7F7F5] border border-[#E5E5E5] px-2.5 py-1 rounded-lg">
              <span className="text-[11px] font-semibold text-[#6B6B6B]">Status:</span>
              <select
                value={vehicle.status}
                onChange={(e) => handleStatusChange(e.target.value as VehicleStatus)}
                className="bg-transparent text-xs font-bold text-[#111111] focus:outline-none cursor-pointer"
              >
                {vehicleStatuses.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
            </div>

            {/* Explicit Publish / Unpublish Button */}
            <Button
              variant={vehicle.is_published ? 'outline' : 'accent'}
              size="sm"
              onClick={handleTogglePublish}
              className="text-xs gap-1.5 shadow-sm"
              title={
                vehicle.is_published
                  ? 'Withdraw vehicle from public showroom'
                  : 'Publish vehicle to public showroom (requires image)'
              }
            >
              {vehicle.is_published ? (
                <>
                  <Eye className="h-3.5 w-3.5 text-[#6B6B6B]" />
                  <span>Unpublish</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>Publish to Showroom</span>
                </>
              )}
            </Button>

            {/* Showroom Preview Link */}
            {vehicle.is_published && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onNavigate(`/cars/${vehicle.slug}`)}
                className="text-xs gap-1"
                title="View customer-facing showroom page"
              >
                <ExternalLink className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">View Public</span>
              </Button>
            )}

            {/* Archive Shortcut */}
            {vehicle.status !== 'ARCHIVED' && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleStatusChange('ARCHIVED')}
                className="text-xs text-[#6B6B6B] hover:text-zinc-900"
                title="Archive vehicle record"
              >
                <Archive className="h-3.5 w-3.5 mr-1" />
                <span>Archive</span>
              </Button>
            )}

            {/* Delete Trigger */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowDeleteModal(true)}
              className="text-xs text-red-600 hover:text-red-700 hover:bg-red-50"
              title="Delete record from database"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[#E5E5E5] pt-2">
          <button
            onClick={() => setActiveTab('specs')}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'specs'
                ? 'border-[#173F35] text-[#173F35]'
                : 'border-transparent text-[#6B6B6B] hover:text-[#111111]'
            }`}
          >
            <FileText className="h-3.5 w-3.5" />
            <span>Specifications & Details</span>
          </button>

          <button
            onClick={() => setActiveTab('media')}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'media'
                ? 'border-[#173F35] text-[#173F35]'
                : 'border-transparent text-[#6B6B6B] hover:text-[#111111]'
            }`}
          >
            <ImageIcon className="h-3.5 w-3.5" />
            <span>Media Studio ({vehicle.media?.length || 0})</span>
          </button>

          <button
            onClick={() => setActiveTab('events')}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'events'
                ? 'border-[#173F35] text-[#173F35]'
                : 'border-transparent text-[#6B6B6B] hover:text-[#111111]'
            }`}
          >
            <Clock className="h-3.5 w-3.5" />
            <span>Internal Audit Timeline ({vehicle.events?.length || 0})</span>
          </button>
        </div>
      </div>

      {/* TAB 1: SPECIFICATIONS FORM */}
      {activeTab === 'specs' && (
        <form onSubmit={handleSaveSpecs} className="space-y-6">
          <Card className="border border-[#E5E5E5]">
            <CardHeader className="border-b border-[#E5E5E5] pb-4">
              <CardTitle className="text-base text-[#111111]">
                Automotive Specifications & Details
              </CardTitle>
              <CardDescription className="text-xs">
                Edit vehicle attributes. Concurrency-safe triggers protect data integrity and stock ID.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="edit-make" className="text-xs font-semibold text-[#111111]">
                    Make <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="edit-make"
                    value={formData.make}
                    onChange={(e) => setFormData({ ...formData, make: e.target.value })}
                    className={`text-xs ${formErrors.make ? 'border-red-500' : ''}`}
                  />
                  {formErrors.make && <p className="text-[11px] text-red-600">{formErrors.make}</p>}
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="edit-model" className="text-xs font-semibold text-[#111111]">
                    Model <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="edit-model"
                    value={formData.model}
                    onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                    className={`text-xs ${formErrors.model ? 'border-red-500' : ''}`}
                  />
                  {formErrors.model && <p className="text-[11px] text-red-600">{formErrors.model}</p>}
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="edit-variant" className="text-xs font-semibold text-[#111111]">
                    Variant / Edition
                  </Label>
                  <Input
                    id="edit-variant"
                    value={formData.variant || ''}
                    onChange={(e) => setFormData({ ...formData, variant: e.target.value })}
                    className="text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="edit-slug" className="text-xs font-semibold text-[#111111]">
                    URL Slug <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="edit-slug"
                    value={formData.slug}
                    onChange={(e) => setFormData({ ...formData, slug: e.target.value.toLowerCase() })}
                    className={`text-xs font-mono ${formErrors.slug ? 'border-red-500' : ''}`}
                  />
                  {formErrors.slug && <p className="text-[11px] text-red-600">{formErrors.slug}</p>}
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="edit-reg" className="text-xs font-semibold text-[#111111]">
                    Registration Number
                  </Label>
                  <Input
                    id="edit-reg"
                    value={formData.registration_number || ''}
                    onChange={(e) => setFormData({ ...formData, registration_number: e.target.value.toUpperCase() })}
                    className="text-xs font-mono uppercase"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="edit-color" className="text-xs font-semibold text-[#111111]">
                    Exterior Paint
                  </Label>
                  <Input
                    id="edit-color"
                    value={formData.color || ''}
                    onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                    className="text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2">
                <div className="space-y-1.5">
                  <Label htmlFor="edit-mfg" className="text-xs font-semibold text-[#111111]">
                    Manufacturing Year <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="edit-mfg"
                    type="number"
                    value={formData.manufacturing_year}
                    onChange={(e) =>
                      setFormData({ ...formData, manufacturing_year: parseInt(e.target.value) || 0 })
                    }
                    className="text-xs"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="edit-regyear" className="text-xs font-semibold text-[#111111]">
                    Registration Year
                  </Label>
                  <Input
                    id="edit-regyear"
                    type="number"
                    value={formData.registration_year || ''}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        registration_year: e.target.value ? parseInt(e.target.value) : undefined,
                      })
                    }
                    className="text-xs"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="edit-fuel" className="text-xs font-semibold text-[#111111]">
                    Fuel Type <span className="text-red-500">*</span>
                  </Label>
                  <select
                    id="edit-fuel"
                    value={formData.fuel_type}
                    onChange={(e) => setFormData({ ...formData, fuel_type: e.target.value as VehicleFuelType })}
                    className="w-full h-9 rounded-md border border-[#E5E5E5] bg-white px-3 text-xs text-[#111111]"
                  >
                    {vehicleFuelTypes.map((f) => (
                      <option key={f} value={f}>
                        {f}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="edit-trans" className="text-xs font-semibold text-[#111111]">
                    Transmission <span className="text-red-500">*</span>
                  </Label>
                  <select
                    id="edit-trans"
                    value={formData.transmission}
                    onChange={(e) => setFormData({ ...formData, transmission: e.target.value as VehicleTransmission })}
                    className="w-full h-9 rounded-md border border-[#E5E5E5] bg-white px-3 text-xs text-[#111111]"
                  >
                    {vehicleTransmissions.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="edit-km" className="text-xs font-semibold text-[#111111]">
                    Kilometers <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="edit-km"
                    type="number"
                    value={formData.kilometers}
                    onChange={(e) =>
                      setFormData({ ...formData, kilometers: parseInt(e.target.value) || 0 })
                    }
                    className="text-xs"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="edit-owners" className="text-xs font-semibold text-[#111111]">
                    Owners <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="edit-owners"
                    type="number"
                    value={formData.owners}
                    onChange={(e) =>
                      setFormData({ ...formData, owners: parseInt(e.target.value) || 0 })
                    }
                    className="text-xs"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="edit-asking" className="text-xs font-semibold text-[#111111]">
                    Asking Price (₹) <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="edit-asking"
                    type="number"
                    value={formData.asking_price}
                    onChange={(e) =>
                      setFormData({ ...formData, asking_price: parseFloat(e.target.value) || 0 })
                    }
                    className="text-xs font-bold"
                  />
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="edit-purchase" className="text-xs font-semibold text-[#111111]">
                      Purchase Cost (₹)
                    </Label>
                    <span className="text-[9px] text-[#6B6B6B] font-mono">Confidential</span>
                  </div>
                  <Input
                    id="edit-purchase"
                    type="number"
                    value={formData.purchase_price || ''}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        purchase_price: e.target.value ? parseFloat(e.target.value) : undefined,
                      })
                    }
                    className="text-xs bg-[#FCFCFA]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="space-y-1.5">
                  <Label htmlFor="edit-cond" className="text-xs font-semibold text-[#111111]">
                    Condition Grade
                  </Label>
                  <select
                    id="edit-cond"
                    value={formData.condition || ''}
                    onChange={(e) => setFormData({ ...formData, condition: (e.target.value || null) as VehicleCondition | null })}
                    className="w-full h-9 rounded-md border border-[#E5E5E5] bg-white px-3 text-xs text-[#111111]"
                  >
                    {vehicleConditions.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="edit-service" className="text-xs font-semibold text-[#111111]">
                    Service History Record
                  </Label>
                  <select
                    id="edit-service"
                    value={formData.service_history || ''}
                    onChange={(e) =>
                      setFormData({ ...formData, service_history: (e.target.value || null) as ServiceHistoryStatus | null })
                    }
                    className="w-full h-9 rounded-md border border-[#E5E5E5] bg-white px-3 text-xs text-[#111111]"
                  >
                    {serviceHistoryStatuses.map((sh) => (
                      <option key={sh} value={sh}>
                        {sh}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1.5 pt-2">
                <Label htmlFor="edit-short" className="text-xs font-semibold text-[#111111]">
                  Short Summary
                </Label>
                <Input
                  id="edit-short"
                  value={formData.short_description || ''}
                  onChange={(e) => setFormData({ ...formData, short_description: e.target.value })}
                  className="text-xs"
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="edit-desc" className="text-xs font-semibold text-[#111111]">
                  Full Provenance & Specifications Narrative
                </Label>
                <textarea
                  id="edit-desc"
                  rows={4}
                  value={formData.description || ''}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full rounded-md border border-[#E5E5E5] p-3 text-xs text-[#111111]"
                />
              </div>

              <div className="pt-4 border-t border-[#E5E5E5] flex justify-end">
                <Button
                  type="submit"
                  variant="accent"
                  size="sm"
                  disabled={savingSpecs}
                  className="text-xs gap-1.5 shadow-sm"
                >
                  <Save className="h-3.5 w-3.5" />
                  <span>{savingSpecs ? 'Saving Changes...' : 'Save Specifications'}</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </form>
      )}

      {/* TAB 2: MEDIA MANAGEMENT STUDIO */}
      {activeTab === 'media' && (
        <div className="space-y-6">
          {/* Media Upload Card */}
          <Card className="border border-[#E5E5E5]">
            <CardHeader className="border-b border-[#E5E5E5] pb-4">
              <CardTitle className="text-base text-[#111111]">
                Vehicle Media Ingestion Studio
              </CardTitle>
              <CardDescription className="text-xs">
                Upload authentic photography and showcase videos to Supabase Storage buckets{' '}
                <code className="text-[10px] font-mono">vehicle-images</code> and{' '}
                <code className="text-[10px] font-mono">vehicle-videos</code>.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold text-[#111111]">Media Type</Label>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setUploadMediaType('IMAGE')}
                      className={`flex-1 py-1.5 rounded-md text-xs font-medium border flex items-center justify-center gap-1.5 transition-colors ${
                        uploadMediaType === 'IMAGE'
                          ? 'bg-[#111111] text-white border-[#111111]'
                          : 'bg-white text-[#6B6B6B] border-[#E5E5E5] hover:bg-[#F7F7F5]'
                      }`}
                    >
                      <ImageIcon className="h-3.5 w-3.5" />
                      <span>Image</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setUploadMediaType('VIDEO');
                        setUploadAsCover(false);
                      }}
                      className={`flex-1 py-1.5 rounded-md text-xs font-medium border flex items-center justify-center gap-1.5 transition-colors ${
                        uploadMediaType === 'VIDEO'
                          ? 'bg-[#111111] text-white border-[#111111]'
                          : 'bg-white text-[#6B6B6B] border-[#E5E5E5] hover:bg-[#F7F7F5]'
                      }`}
                    >
                      <Video className="h-3.5 w-3.5" />
                      <span>Video</span>
                    </button>
                  </div>
                </div>

                <div className="space-y-1.5 sm:col-span-2">
                  <Label htmlFor="alt-text" className="text-xs font-semibold text-[#111111]">
                    Alt Description / Angle
                  </Label>
                  <Input
                    id="alt-text"
                    placeholder="e.g. Front three-quarter dynamic studio angle with headlights on"
                    value={uploadAltText}
                    onChange={(e) => setUploadAltText(e.target.value)}
                    className="text-xs"
                  />
                </div>
              </div>

              {uploadMediaType === 'IMAGE' && (
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="set-cover"
                    checked={uploadAsCover}
                    onChange={(e) => setUploadAsCover(e.target.checked)}
                    className="rounded border-[#E5E5E5] text-[#173F35] focus:ring-[#173F35]"
                  />
                  <Label htmlFor="set-cover" className="text-xs text-[#111111] cursor-pointer">
                    Designate as the vehicle's primary cover photograph
                  </Label>
                </div>
              )}

              {/* File Dropzone Input */}
              <div className="mt-2 border-2 border-dashed border-[#E5E5E5] hover:border-[#173F35] rounded-xl p-8 text-center transition-colors bg-[#FCFCFA]">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept={
                    uploadMediaType === 'IMAGE'
                      ? 'image/jpeg,image/png,image/webp,image/avif'
                      : 'video/mp4,video/webm,video/quicktime'
                  }
                  onChange={handleFileUpload}
                  disabled={isUploading}
                  className="hidden"
                  id="media-file-input"
                />
                <label
                  htmlFor="media-file-input"
                  className="cursor-pointer block space-y-3"
                >
                  <div className="h-12 w-12 rounded-full bg-[#E9EFEF] flex items-center justify-center mx-auto text-[#173F35]">
                    <Upload className={`h-6 w-6 ${isUploading ? 'animate-bounce' : ''}`} />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-[#111111] hover:underline">
                      {isUploading ? 'Uploading and Optimizing...' : 'Click to select media file'}
                    </span>
                    <p className="text-[11px] text-[#6B6B6B] mt-1">
                      {uploadMediaType === 'IMAGE'
                        ? 'High-resolution JPG, PNG, WEBP (Max 15MB)'
                        : 'MP4, WEBM video walkaround (Max 60MB)'}
                    </p>
                  </div>
                </label>
              </div>
            </CardContent>
          </Card>

          {/* Media Items List / Grid */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-heading font-bold text-base text-[#111111]">
                Attached Media Assets ({vehicle.media?.length || 0})
              </h3>
              <div className="text-xs text-[#6B6B6B] flex items-center gap-3">
                <span>{imageCount} Images</span>
                <span>•</span>
                <span>{videoCount} Videos</span>
              </div>
            </div>

            {(!vehicle.media || vehicle.media.length === 0) ? (
              <Card className="border-dashed border-2 border-[#E5E5E5] bg-white text-center py-12">
                <CardContent className="space-y-3 max-w-sm mx-auto">
                  <div className="h-10 w-10 rounded-full bg-[#F7F7F5] flex items-center justify-center mx-auto text-[#6B6B6B]">
                    <ImageIcon className="h-5 w-5" />
                  </div>
                  <h4 className="font-heading text-sm font-bold text-[#111111]">
                    No Media Uploaded
                  </h4>
                  <p className="text-xs text-[#6B6B6B]">
                    Vehicles must have at least one image before they can be published to the online showroom.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {vehicle.media.map((media, idx) => (
                  <Card
                    key={media.id}
                    className={`overflow-hidden border transition-all ${
                      media.is_cover
                        ? 'border-[#173F35] ring-2 ring-[#173F35]/15 shadow-sm'
                        : 'border-[#E5E5E5] hover:border-[#CCCCCC]'
                    }`}
                  >
                    <div className="relative aspect-video bg-[#111111] overflow-hidden flex items-center justify-center group">
                      {media.media_type === 'IMAGE' ? (
                        <img
                          src={media.publicUrl || media.storage_path}
                          alt={media.alt_text || 'Vehicle photograph'}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="h-full w-full flex flex-col items-center justify-center bg-zinc-900 text-white p-4 text-center">
                          <Video className="h-8 w-8 text-emerald-400 mb-2" />
                          <span className="text-xs font-mono">Video Asset</span>
                          <span className="text-[10px] text-zinc-400 truncate max-w-full px-2">
                            {media.storage_path.split('/').pop()}
                          </span>
                        </div>
                      )}

                      {/* Badges Overlay */}
                      <div className="absolute top-2 left-2 flex items-center gap-1.5">
                        {media.is_cover && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-[#173F35] text-white shadow-xs">
                            <Star className="h-3 w-3 fill-current" />
                            <span>COVER</span>
                          </span>
                        )}
                        <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-mono bg-black/60 text-white backdrop-blur-xs">
                          {media.media_type}
                        </span>
                      </div>

                      {/* Order Index */}
                      <div className="absolute top-2 right-2 font-mono text-[10px] bg-black/60 text-white px-1.5 py-0.5 rounded backdrop-blur-xs">
                        #{idx + 1}
                      </div>
                    </div>

                    <CardContent className="p-3.5 space-y-3">
                      <p className="text-xs text-[#6B6B6B] truncate" title={media.alt_text || 'No description'}>
                        {media.alt_text || <span className="italic">No description provided</span>}
                      </p>

                      <div className="flex items-center justify-between pt-1 border-t border-[#E5E5E5] text-xs">
                        {/* Sort Order Controls */}
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            disabled={idx === 0}
                            onClick={() => handleMoveMedia(media.id, 'UP')}
                            className="h-7 w-7 p-0 text-[#6B6B6B] hover:text-[#111111]"
                            title="Move earlier"
                          >
                            <ArrowUp className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            disabled={idx === (vehicle.media?.length || 0) - 1}
                            onClick={() => handleMoveMedia(media.id, 'DOWN')}
                            className="h-7 w-7 p-0 text-[#6B6B6B] hover:text-[#111111]"
                            title="Move later"
                          >
                            <ArrowDown className="h-3.5 w-3.5" />
                          </Button>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-1.5">
                          {media.media_type === 'IMAGE' && !media.is_cover && (
                            <Button
                              variant="outline"
                              size="sm"
                              disabled={mediaActionId === media.id}
                              onClick={() => handleSetCover(media.id)}
                              className="h-7 px-2 text-[11px] gap-1"
                            >
                              <Star className="h-3 w-3" />
                              <span>Make Cover</span>
                            </Button>
                          )}

                          <Button
                            variant="ghost"
                            size="sm"
                            disabled={mediaActionId === media.id}
                            onClick={() => handleDeleteMedia(media.id)}
                            className="h-7 w-7 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                            title="Delete media"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: INTERNAL AUDIT TIMELINE */}
      {activeTab === 'events' && (
        <div className="space-y-6">
          {/* Add Note Card */}
          <Card className="border border-[#E5E5E5]">
            <CardHeader className="border-b border-[#E5E5E5] pb-4">
              <CardTitle className="text-base text-[#111111]">
                Append Internal Administrative Note
              </CardTitle>
              <CardDescription className="text-xs">
                Private immutable log record visible only to authenticated dealership administrators.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <form onSubmit={handleAddNote} className="space-y-3">
                <textarea
                  rows={2}
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder="Record an inspection outcome, physical key handover, servicing invoice note, or client discussion..."
                  className="w-full rounded-md border border-[#E5E5E5] p-3 text-xs text-[#111111] focus:ring-1 focus:ring-[#173F35]"
                />
                <div className="flex justify-end">
                  <Button
                    type="submit"
                    variant="accent"
                    size="sm"
                    disabled={isAddingNote || !newNote.trim()}
                    className="text-xs gap-1.5"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>{isAddingNote ? 'Recording...' : 'Log Internal Event Note'}</span>
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Timeline List */}
          <div className="space-y-3">
            <h3 className="font-heading font-bold text-base text-[#111111]">
              Vehicle Event Log ({vehicle.events?.length || 0})
            </h3>

            {(!vehicle.events || vehicle.events.length === 0) ? (
              <p className="text-xs text-[#6B6B6B] italic">No events recorded yet.</p>
            ) : (
              <div className="relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#E5E5E5]">
                {vehicle.events.map((evt) => (
                  <div key={evt.id} className="relative group">
                    {/* Timeline bullet */}
                    <div className="absolute -left-6 top-1 h-4 w-4 rounded-full border-2 border-white bg-[#173F35] shadow-xs"></div>

                    <div className="p-4 rounded-lg border border-[#E5E5E5] bg-white space-y-1.5 shadow-2xs">
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-xs font-bold text-[#173F35] bg-[#E9EFEF] px-2 py-0.5 rounded">
                          {evt.event_type}
                        </span>
                        <span className="text-[11px] text-[#6B6B6B] font-mono">
                          {new Date(evt.created_at).toLocaleString('en-GB', {
                            day: '2-digit',
                            month: 'short',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>

                      {evt.notes && (
                        <p className="text-xs text-[#111111] leading-relaxed whitespace-pre-wrap">
                          {evt.notes}
                        </p>
                      )}

                      <div className="text-[10px] text-[#6B6B6B] pt-1">
                        Recorded by: <span className="font-medium text-[#111111]">{evt.author_name}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Delete Vehicle Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="bg-white rounded-xl border border-[#E5E5E5] p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center text-red-700">
              <AlertCircle className="h-6 w-6" />
            </div>

            <div>
              <h3 className="font-heading text-lg font-bold text-[#111111]">
                Delete Vehicle Record Permanently?
              </h3>
              <p className="text-xs text-[#6B6B6B] mt-1 leading-relaxed">
                This will delete <span className="font-bold text-[#111111]">{vehicle.stock_id} ({vehicle.make} {vehicle.model})</span>, along with all associated media assets and timeline logs. This action cannot be reversed.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowDeleteModal(false)}
                disabled={isDeletingVehicle}
                className="text-xs"
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                size="sm"
                onClick={handleDeleteVehicle}
                disabled={isDeletingVehicle}
                className="text-xs gap-1.5"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>{isDeletingVehicle ? 'Deleting...' : 'Confirm Deletion'}</span>
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
