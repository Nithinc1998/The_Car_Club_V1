import React, { useState, useEffect, useMemo } from 'react';
import {
  Inbox,
  Search,
  Filter,
  RefreshCw,
  Eye,
  Phone,
  Mail,
  Calendar,
  CarFront,
  Tag,
  Clock,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  getAdminEnquiries,
  EnquiryWithVehicle,
} from '@/lib/services/enquiry-service';
import { EnquiryStatus, EnquiryType } from '@/lib/validations/enquiry';

interface AdminEnquiriesRouteProps {
  onNavigate: (path: string) => void;
}

export const AdminEnquiriesRoute: React.FC<AdminEnquiriesRouteProps> = ({ onNavigate }) => {
  const [enquiries, setEnquiries] = useState<EnquiryWithVehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [statusFilter, setStatusFilter] = useState<EnquiryStatus | 'ALL'>('ALL');
  const [typeFilter, setTypeFilter] = useState<EnquiryType | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const loadEnquiries = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getAdminEnquiries();
      if (res.error) {
        setError(res.error);
      } else {
        setEnquiries(res.enquiries);
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to retrieve enquiries queue.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEnquiries();
  }, []);

  // Compute live stats
  const stats = useMemo(() => {
    return {
      all: enquiries.length,
      new: enquiries.filter((e) => e.status === 'NEW').length,
      contacted: enquiries.filter((e) => e.status === 'CONTACTED').length,
      follow_up: enquiries.filter((e) => e.status === 'FOLLOW_UP').length,
      converted: enquiries.filter((e) => e.status === 'CONVERTED').length,
      closed: enquiries.filter((e) => e.status === 'CLOSED').length,
    };
  }, [enquiries]);

  // Filter in-memory for instant responsiveness
  const filteredEnquiries = useMemo(() => {
    return enquiries.filter((item) => {
      if (statusFilter !== 'ALL' && item.status !== statusFilter) return false;
      if (typeFilter !== 'ALL' && item.enquiry_type !== typeFilter) return false;

      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase().trim();
        const matchName = item.customer_name.toLowerCase().includes(q);
        const matchPhone = item.phone.toLowerCase().includes(q);
        const matchEmail = item.email?.toLowerCase().includes(q);
        const matchVehicle =
          item.vehicle &&
          (item.vehicle.make.toLowerCase().includes(q) ||
            item.vehicle.model.toLowerCase().includes(q) ||
            item.vehicle.stock_id.toLowerCase().includes(q));

        if (!matchName && !matchPhone && !matchEmail && !matchVehicle) {
          return false;
        }
      }

      return true;
    });
  }, [enquiries, statusFilter, typeFilter, searchQuery]);

  const getTypeBadge = (type: EnquiryType) => {
    switch (type) {
      case 'TEST_DRIVE':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
            Test Drive
          </span>
        );
      case 'OFFER':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-purple-100 text-purple-800 border border-purple-200">
            Offer Proposal
          </span>
        );
      case 'CALLBACK':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-100 text-blue-800 border border-blue-200">
            Callback
          </span>
        );
      case 'VEHICLE':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-100 text-amber-800 border border-amber-200">
            Vehicle Specific
          </span>
        );
      case 'GENERAL':
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-zinc-100 text-zinc-800 border border-zinc-200">
            General Showroom
          </span>
        );
    }
  };

  const getStatusBadge = (status: EnquiryStatus) => {
    switch (status) {
      case 'NEW':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-700 text-white shadow-xs">
            <span className="h-1.5 w-1.5 rounded-full bg-white animate-pulse"></span>
            NEW
          </span>
        );
      case 'CONTACTED':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded text-[11px] font-semibold bg-blue-50 text-blue-800 border border-blue-200">
            Contacted
          </span>
        );
      case 'FOLLOW_UP':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
            Follow-Up
          </span>
        );
      case 'CONVERTED':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded text-[11px] font-semibold bg-purple-50 text-purple-800 border border-purple-200">
            Converted / Acquired
          </span>
        );
      case 'CLOSED':
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded text-[11px] font-semibold bg-zinc-100 text-zinc-600 border border-zinc-200">
            Closed
          </span>
        );
    }
  };

  const formatOffer = (amt: number | null) => {
    if (!amt) return null;
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amt);
  };

  return (
    <div className="space-y-6">
      {/* Route Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5E5E5] pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-[#6B6B6B] mb-1">
            <span>Route:</span>
            <code className="bg-[#F0F0EE] px-1.5 py-0.5 rounded text-[#111111] font-mono">
              /admin/enquiries
            </code>
          </div>
          <h1 className="font-heading text-2xl sm:text-3xl font-bold text-[#111111]">
            Customer Enquiries Queue
          </h1>
          <p className="text-xs sm:text-sm text-[#6B6B6B] mt-1">
            Inbound acquisition inquiries, test drive requests, proposals, and concierge correspondence.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={loadEnquiries}
          disabled={loading}
          className="text-xs gap-1.5 border-[#E5E5E5] self-start sm:self-auto"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Queue</span>
        </Button>
      </div>

      {error && (
        <div className="p-4 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800">
          <p className="font-bold">Error Loading Enquiries</p>
          <p>{error}</p>
        </div>
      )}

      {/* Metric Cards / Status Pills */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <button
          onClick={() => setStatusFilter('ALL')}
          className={`p-3 rounded-lg border text-left transition-all ${
            statusFilter === 'ALL'
              ? 'bg-[#111111] text-white border-[#111111] shadow-sm'
              : 'bg-white hover:bg-[#F7F7F5] border-[#E5E5E5] text-[#111111]'
          }`}
        >
          <div className="text-[10px] uppercase font-bold tracking-wider opacity-75">All Inquiries</div>
          <div className="font-heading text-xl font-bold mt-0.5">{stats.all}</div>
        </button>

        <button
          onClick={() => setStatusFilter('NEW')}
          className={`p-3 rounded-lg border text-left transition-all ${
            statusFilter === 'NEW'
              ? 'bg-emerald-800 text-white border-emerald-800 shadow-sm'
              : 'bg-white hover:bg-emerald-50/50 border-[#E5E5E5] text-[#111111]'
          }`}
        >
          <div className="text-[10px] uppercase font-bold tracking-wider text-emerald-600">New / Unread</div>
          <div className="font-heading text-xl font-bold mt-0.5 text-emerald-800">{stats.new}</div>
        </button>

        <button
          onClick={() => setStatusFilter('CONTACTED')}
          className={`p-3 rounded-lg border text-left transition-all ${
            statusFilter === 'CONTACTED'
              ? 'bg-blue-800 text-white border-blue-800 shadow-sm'
              : 'bg-white hover:bg-blue-50/50 border-[#E5E5E5] text-[#111111]'
          }`}
        >
          <div className="text-[10px] uppercase font-bold tracking-wider text-blue-600">Contacted</div>
          <div className="font-heading text-xl font-bold mt-0.5 text-blue-800">{stats.contacted}</div>
        </button>

        <button
          onClick={() => setStatusFilter('FOLLOW_UP')}
          className={`p-3 rounded-lg border text-left transition-all ${
            statusFilter === 'FOLLOW_UP'
              ? 'bg-amber-800 text-white border-amber-800 shadow-sm'
              : 'bg-white hover:bg-amber-50/50 border-[#E5E5E5] text-[#111111]'
          }`}
        >
          <div className="text-[10px] uppercase font-bold tracking-wider text-amber-600">Follow-Up</div>
          <div className="font-heading text-xl font-bold mt-0.5 text-amber-800">{stats.follow_up}</div>
        </button>

        <button
          onClick={() => setStatusFilter('CONVERTED')}
          className={`p-3 rounded-lg border text-left transition-all ${
            statusFilter === 'CONVERTED'
              ? 'bg-purple-800 text-white border-purple-800 shadow-sm'
              : 'bg-white hover:bg-purple-50/50 border-[#E5E5E5] text-[#111111]'
          }`}
        >
          <div className="text-[10px] uppercase font-bold tracking-wider text-purple-600">Converted</div>
          <div className="font-heading text-xl font-bold mt-0.5 text-purple-800">{stats.converted}</div>
        </button>

        <button
          onClick={() => setStatusFilter('CLOSED')}
          className={`p-3 rounded-lg border text-left transition-all ${
            statusFilter === 'CLOSED'
              ? 'bg-zinc-700 text-white border-zinc-700 shadow-sm'
              : 'bg-white hover:bg-zinc-100 border-[#E5E5E5] text-[#111111]'
          }`}
        >
          <div className="text-[10px] uppercase font-bold tracking-wider text-zinc-500">Closed</div>
          <div className="font-heading text-xl font-bold mt-0.5 text-zinc-600">{stats.closed}</div>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-lg border border-[#E5E5E5] bg-white flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-[#6B6B6B]" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search client name, phone, email, or vehicle..."
            className="pl-9 text-xs h-9"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-[#6B6B6B] font-medium mr-1">Type:</span>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value as EnquiryType | 'ALL')}
            className="h-9 rounded-md border border-[#E5E5E5] bg-white px-2.5 text-xs text-[#111111]"
          >
            <option value="ALL">All Inquiry Types</option>
            <option value="VEHICLE">Vehicle Acquisition</option>
            <option value="TEST_DRIVE">Test Drive</option>
            <option value="OFFER">Purchase Offer</option>
            <option value="CALLBACK">Callback Request</option>
            <option value="GENERAL">General Showroom</option>
          </select>
        </div>
      </div>

      {/* Main Enquiries Table */}
      {loading ? (
        <Card className="border border-[#E5E5E5] bg-white">
          <CardContent className="py-16 text-center space-y-3">
            <RefreshCw className="h-8 w-8 text-[#173F35] animate-spin mx-auto" />
            <p className="text-xs text-[#6B6B6B] font-mono uppercase tracking-wider">
              Querying enquiries queue...
            </p>
          </CardContent>
        </Card>
      ) : filteredEnquiries.length === 0 ? (
        <Card className="border-dashed border-2 border-[#E5E5E5] bg-white text-center py-16">
          <CardContent className="space-y-4 max-w-md mx-auto">
            <div className="h-12 w-12 rounded-full bg-[#F7F7F5] flex items-center justify-center mx-auto text-[#173F35]">
              <Inbox className="h-6 w-6" />
            </div>
            <h3 className="font-heading text-base font-bold text-[#111111]">
              No Matching Inquiries Found
            </h3>
            <p className="text-xs text-[#6B6B6B] leading-relaxed">
              {searchQuery || statusFilter !== 'ALL' || typeFilter !== 'ALL'
                ? 'No inquiry records match the active criteria. Clear filters to view the full queue.'
                : 'No customer inquiries have been submitted yet. Inquiries will populate in real time as clients submit requests from the public showroom.'}
            </p>

            {(searchQuery || statusFilter !== 'ALL' || typeFilter !== 'ALL') && (
              <div className="pt-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setSearchQuery('');
                    setStatusFilter('ALL');
                    setTypeFilter('ALL');
                  }}
                  className="text-xs"
                >
                  Clear Active Filters
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="rounded-lg border border-[#E5E5E5] bg-white overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F7F7F5] border-b border-[#E5E5E5] text-[#6B6B6B] uppercase tracking-wider font-semibold text-[10px]">
                <tr>
                  <th className="py-3 px-4">Customer Prospect</th>
                  <th className="py-3 px-4">Inquiry Type</th>
                  <th className="py-3 px-4">Vehicle Context</th>
                  <th className="py-3 px-4">Proposal / Scheduling</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Source</th>
                  <th className="py-3 px-4">Received</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E5E5E5]">
                {filteredEnquiries.map((enquiry) => (
                  <tr
                    key={enquiry.id}
                    className="hover:bg-[#F9F9F8] transition-colors group cursor-pointer"
                    onClick={() => onNavigate(`/admin/enquiries/${enquiry.id}`)}
                  >
                    {/* Customer */}
                    <td className="py-3.5 px-4">
                      <div className="font-heading font-bold text-xs text-[#111111] group-hover:text-[#173F35] transition-colors">
                        {enquiry.customer_name}
                      </div>
                      <div className="text-[11px] text-[#6B6B6B] flex items-center gap-2 font-mono mt-0.5">
                        <span>{enquiry.phone}</span>
                        {enquiry.email && <span className="truncate max-w-[150px]">{enquiry.email}</span>}
                      </div>
                    </td>

                    {/* Type */}
                    <td className="py-3.5 px-4">
                      {getTypeBadge(enquiry.enquiry_type)}
                    </td>

                    {/* Vehicle */}
                    <td className="py-3.5 px-4">
                      {enquiry.vehicle ? (
                        <div>
                          <span className="font-mono text-[10px] font-bold text-[#173F35] bg-[#E9EFEF] px-1.5 py-0.2 rounded mr-1.5">
                            {enquiry.vehicle.stock_id}
                          </span>
                          <span className="font-medium text-[#111111]">
                            {enquiry.vehicle.manufacturing_year} {enquiry.vehicle.make} {enquiry.vehicle.model}
                          </span>
                        </div>
                      ) : (
                        <span className="text-[#6B6B6B] italic text-[11px]">
                          General Showroom
                        </span>
                      )}
                    </td>

                    {/* Proposal / Scheduling Details */}
                    <td className="py-3.5 px-4 text-[#6B6B6B]">
                      {enquiry.enquiry_type === 'OFFER' && enquiry.offer_amount ? (
                        <span className="font-heading font-bold text-purple-900 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                          {formatOffer(enquiry.offer_amount)}
                        </span>
                      ) : enquiry.enquiry_type === 'TEST_DRIVE' && enquiry.preferred_date ? (
                        <span className="flex items-center gap-1 font-mono text-[11px] text-[#111111]">
                          <Calendar className="h-3 w-3 text-[#173F35]" />
                          <span>{enquiry.preferred_date}</span>
                          {enquiry.preferred_time && <span>@ {enquiry.preferred_time}</span>}
                        </span>
                      ) : enquiry.message ? (
                        <span className="truncate max-w-[180px] inline-block text-[11px]">
                          {enquiry.message}
                        </span>
                      ) : (
                        <span className="text-[11px] text-zinc-400">—</span>
                      )}
                    </td>

                    {/* Status */}
                    <td className="py-3.5 px-4">
                      {getStatusBadge(enquiry.status)}
                    </td>

                    {/* Source */}
                    <td className="py-3.5 px-4">
                      <span className="font-mono text-[10px] uppercase text-[#6B6B6B] bg-[#F0F0EE] px-1.5 py-0.5 rounded">
                        {enquiry.source}
                      </span>
                    </td>

                    {/* Received Date */}
                    <td className="py-3.5 px-4 text-[11px] text-[#6B6B6B] font-mono">
                      {new Date(enquiry.created_at).toLocaleDateString('en-GB', {
                        day: '2-digit',
                        month: 'short',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onNavigate(`/admin/enquiries/${enquiry.id}`)}
                        className="h-8 px-2.5 text-xs text-[#111111] hover:text-[#173F35] hover:bg-[#F0F0EE] gap-1"
                      >
                        <Eye className="h-3.5 w-3.5" />
                        <span>Inspect</span>
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-3 bg-[#F7F7F5] border-t border-[#E5E5E5] flex items-center justify-between text-[11px] text-[#6B6B6B]">
            <span>
              Showing {filteredEnquiries.length} of {enquiries.length} inquiries
            </span>
            <span className="flex items-center gap-1 font-medium text-[#173F35]">
              <Sparkles className="h-3 w-3" />
              Authenticated Admin Triage Active
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
