import React, { useState, useEffect, useMemo } from 'react';
import {
  CarFront,
  Inbox,
  PlusCircle,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  Clock,
  Eye,
  Archive,
  CheckCircle,
  HelpCircle,
  Sparkles,
  Phone,
  Mail,
  Calendar,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/lib/auth';
import { getAdminVehicles, VehicleWithMedia } from '@/lib/services/vehicle-service';
import { getAdminEnquiries, EnquiryWithVehicle } from '@/lib/services/enquiry-service';
import { EnquiryStatus, EnquiryType } from '@/lib/validations/enquiry';
import { VehicleStatus } from '@/lib/validations/vehicle';

interface AdminDashboardRouteProps {
  onNavigate: (path: string) => void;
}

export const AdminDashboardRoute: React.FC<AdminDashboardRouteProps> = ({ onNavigate }) => {
  const { profile, user, isConfigured } = useAuth();
  const [vehicles, setVehicles] = useState<VehicleWithMedia[]>([]);
  const [enquiries, setEnquiries] = useState<EnquiryWithVehicle[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const adminName = profile?.full_name || user?.email?.split('@')[0] || 'Administrator';

  // Fetch operational dataset from authoritative services
  const loadDashboardData = async (isManualRefresh = false) => {
    if (isManualRefresh) {
      setRefreshing(true);
    } else {
      setLoading(true);
    }
    setError(null);

    try {
      // Parallel fetch for authoritative inventory and enquiries
      const [vehiclesRes, enquiriesRes] = await Promise.all([
        getAdminVehicles(),
        getAdminEnquiries(),
      ]);

      if (vehiclesRes.error && enquiriesRes.error) {
        throw new Error(vehiclesRes.error || enquiriesRes.error || 'Failed to load operational data.');
      }

      setVehicles(vehiclesRes.vehicles || []);
      setEnquiries(enquiriesRes.enquiries || []);
    } catch (err: unknown) {
      console.error('Error loading admin dashboard metrics:', err);
      setError(err instanceof Error ? err.message : 'Unable to synchronize operational telemetry. Please check connectivity.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
  }, []);

  // Compute authoritative Inventory Summary metrics strictly from vehicles.status and vehicles.is_published
  const inventoryStats = useMemo(() => {
    const total = vehicles.length;
    const available = vehicles.filter((v) => v.status === 'AVAILABLE').length;
    const reserved = vehicles.filter((v) => v.status === 'RESERVED').length;
    const sold = vehicles.filter((v) => v.status === 'SOLD').length;
    const archived = vehicles.filter((v) => v.status === 'ARCHIVED').length;
    const published = vehicles.filter((v) => v.is_published).length;
    const draft = vehicles.filter((v) => v.status === 'DRAFT').length;

    return {
      total,
      available,
      reserved,
      sold,
      archived,
      published,
      draft,
    };
  }, [vehicles]);

  // Compute authoritative Enquiry Summary metrics strictly from enquiries.status
  const enquiryStats = useMemo(() => {
    const total = enquiries.length;
    const newEnquiries = enquiries.filter((e) => e.status === 'NEW').length;
    const contacted = enquiries.filter((e) => e.status === 'CONTACTED').length;
    const followUp = enquiries.filter((e) => e.status === 'FOLLOW_UP').length;
    const converted = enquiries.filter((e) => e.status === 'CONVERTED').length;
    const closed = enquiries.filter((e) => e.status === 'CLOSED').length;

    return {
      total,
      new: newEnquiries,
      contacted,
      followUp,
      converted,
      closed,
    };
  }, [enquiries]);

  // Recent enquiries slice (bounded dataset of top 6 items)
  const recentEnquiries = useMemo(() => {
    return enquiries.slice(0, 6);
  }, [enquiries]);

  // Helper for formatting date/time
  const formatDateTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      const now = new Date();
      const isToday =
        date.getDate() === now.getDate() &&
        date.getMonth() === now.getMonth() &&
        date.getFullYear() === now.getFullYear();

      const timeStr = date.toLocaleTimeString('en-GB', {
        hour: '2-digit',
        minute: '2-digit',
      });

      if (isToday) {
        return `Today, ${timeStr}`;
      }

      const dateStr = date.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
      });

      return `${dateStr} • ${timeStr}`;
    } catch {
      return isoString;
    }
  };

  const getEnquiryTypeBadge = (type: EnquiryType) => {
    switch (type) {
      case 'TEST_DRIVE':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
            Test Drive
          </span>
        );
      case 'OFFER':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-purple-50 text-purple-800 border border-purple-200">
            Offer
          </span>
        );
      case 'CALLBACK':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-50 text-blue-800 border border-blue-200">
            Callback
          </span>
        );
      case 'VEHICLE':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
            Vehicle Specific
          </span>
        );
      case 'GENERAL':
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-zinc-100 text-zinc-700 border border-zinc-200">
            General
          </span>
        );
    }
  };

  const getEnquiryStatusBadge = (status: EnquiryStatus) => {
    switch (status) {
      case 'NEW':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-700 text-white shadow-xs">
            <span className="h-1.5 w-1.5 rounded-full bg-white animate-pulse" />
            NEW
          </span>
        );
      case 'CONTACTED':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-50 text-blue-800 border border-blue-200">
            Contacted
          </span>
        );
      case 'FOLLOW_UP':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
            Follow-Up
          </span>
        );
      case 'CONVERTED':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-purple-50 text-purple-800 border border-purple-200">
            Converted
          </span>
        );
      case 'CLOSED':
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-zinc-100 text-zinc-600 border border-zinc-200">
            Closed
          </span>
        );
    }
  };

  return (
    <div className="space-y-8">
      {/* Route Metadata & Executive Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5E5E5] pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-[#6B6B6B] mb-1">
            <span>Route:</span>
            <code className="bg-[#F0F0EE] px-1.5 py-0.5 rounded text-[#111111] font-mono">
              /admin
            </code>
            <span className="text-[#6B6B6B]">•</span>
            <span className="flex items-center gap-1 text-emerald-700 font-medium">
              <ShieldCheck className="h-3.5 w-3.5" />
              Verified Administrator
            </span>
          </div>
          <h1 className="font-heading text-2xl sm:text-3xl font-bold text-[#111111]">
            Dealership Operations Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-[#6B6B6B] mt-1">
            Real-time overview of vehicle inventory, customer consultations, and recent enquiries for {adminName}.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => loadDashboardData(true)}
            disabled={loading || refreshing}
            className="text-xs gap-1.5 h-9"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            <span>{refreshing ? 'Syncing...' : 'Refresh'}</span>
          </Button>
          <Button
            variant="accent"
            size="sm"
            onClick={() => onNavigate('/admin/vehicles/new')}
            className="text-xs gap-1.5 h-9"
          >
            <PlusCircle className="h-3.5 w-3.5" />
            <span>Add Vehicle</span>
          </Button>
        </div>
      </div>

      {/* Error state if data load fails */}
      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 flex items-start justify-between gap-3 text-red-900">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-red-600 mt-0.5 shrink-0" />
            <div>
              <p className="text-sm font-semibold">Telemetry Synchronization Error</p>
              <p className="text-xs text-red-700 mt-0.5">{error}</p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => loadDashboardData(false)}
            className="text-xs bg-white text-red-900 hover:bg-red-100 shrink-0"
          >
            Retry
          </Button>
        </div>
      )}

      {/* Loading Skeleton */}
      {loading ? (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-28 bg-white border border-[#E5E5E5] rounded-xl animate-pulse" />
            ))}
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="h-64 bg-white border border-[#E5E5E5] rounded-xl animate-pulse" />
            <div className="h-64 bg-white border border-[#E5E5E5] rounded-xl animate-pulse" />
          </div>
          <div className="h-72 bg-white border border-[#E5E5E5] rounded-xl animate-pulse" />
        </div>
      ) : (
        <>
          {/* Quick Actions Bar */}
          <div className="bg-white border border-[#E5E5E5] rounded-xl p-4 sm:p-5 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-heading text-sm font-bold text-[#111111] flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-[#173F35]" />
                  Quick Actions
                </h3>
                <p className="text-xs text-[#6B6B6B] mt-0.5">
                  Direct entry points to primary administrative workflows.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => onNavigate('/admin/vehicles/new')}
                  className="text-xs gap-1.5 h-8.5 bg-[#173F35] hover:bg-[#123129] text-white"
                >
                  <PlusCircle className="h-3.5 w-3.5" />
                  <span>Add Vehicle</span>
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onNavigate('/admin/vehicles')}
                  className="text-xs gap-1.5 h-8.5 border-[#E5E5E5] hover:border-[#111111]"
                >
                  <CarFront className="h-3.5 w-3.5 text-[#173F35]" />
                  <span>Manage Vehicles</span>
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onNavigate('/admin/enquiries')}
                  className="text-xs gap-1.5 h-8.5 border-[#E5E5E5] hover:border-[#111111]"
                >
                  <Inbox className="h-3.5 w-3.5 text-[#173F35]" />
                  <span>View Enquiries</span>
                  {enquiryStats.new > 0 && (
                    <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-emerald-700 text-white">
                      {enquiryStats.new} new
                    </span>
                  )}
                </Button>
              </div>
            </div>
          </div>

          {/* Summaries Grid: Inventory Summary & Enquiry Summary */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Inventory Summary Card */}
            <Card className="border-[#E5E5E5] bg-white rounded-xl shadow-xs">
              <CardHeader className="pb-3 border-b border-[#F0F0EE]">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="h-9 w-9 rounded-lg bg-emerald-50 text-[#173F35] flex items-center justify-center">
                      <CarFront className="h-4.5 w-4.5" />
                    </div>
                    <div>
                      <CardTitle className="text-base font-bold text-[#111111]">
                        Inventory Summary
                      </CardTitle>
                      <CardDescription className="text-xs text-[#6B6B6B]">
                        Live vehicle count by lifecycle status and showroom publication.
                      </CardDescription>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onNavigate('/admin/vehicles')}
                    className="text-xs text-[#173F35] hover:text-[#123129] p-1.5 h-auto gap-1"
                  >
                    <span>Inventory</span>
                    <ArrowRight className="h-3 w-3" />
                  </Button>
                </div>
              </CardHeader>

              <CardContent className="pt-4 space-y-4">
                {/* Total and Published Key Metrics */}
                <div className="grid grid-cols-2 gap-3">
                  <div
                    onClick={() => onNavigate('/admin/vehicles')}
                    className="p-3.5 rounded-lg bg-[#F7F7F5] border border-[#E5E5E5] hover:border-[#173F35]/40 transition-colors cursor-pointer"
                  >
                    <div className="text-xs font-medium text-[#6B6B6B]">Total Vehicles</div>
                    <div className="text-2xl font-bold font-heading text-[#111111] mt-1">
                      {inventoryStats.total}
                    </div>
                    <div className="text-[11px] text-[#6B6B6B] mt-0.5">All stock records in database</div>
                  </div>

                  <div
                    onClick={() => onNavigate('/admin/vehicles')}
                    className="p-3.5 rounded-lg bg-emerald-50/70 border border-emerald-200/80 hover:border-emerald-300 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-emerald-900">Published Vehicles</span>
                      <Eye className="h-3.5 w-3.5 text-emerald-700" />
                    </div>
                    <div className="text-2xl font-bold font-heading text-emerald-950 mt-1">
                      {inventoryStats.published}
                    </div>
                    <div className="text-[11px] text-emerald-800/80 mt-0.5">
                      Live on public showroom portal
                    </div>
                  </div>
                </div>

                {/* Status Breakdown Counters */}
                <div className="pt-1">
                  <div className="text-xs font-semibold uppercase tracking-wider text-[#6B6B6B] mb-2.5">
                    Lifecycle Status Breakdown
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {/* Available */}
                    <div
                      onClick={() => onNavigate('/admin/vehicles')}
                      className="p-2.5 rounded-lg border border-[#E5E5E5] bg-white hover:border-[#111111] transition-colors cursor-pointer"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-medium text-[#6B6B6B]">Available</span>
                        <span className="h-2 w-2 rounded-full bg-emerald-500" />
                      </div>
                      <div className="text-lg font-bold text-[#111111] mt-1">
                        {inventoryStats.available}
                      </div>
                      <span className="inline-block text-[10px] text-emerald-700 font-medium mt-0.5">
                        Ready for acquisition
                      </span>
                    </div>

                    {/* Reserved */}
                    <div
                      onClick={() => onNavigate('/admin/vehicles')}
                      className="p-2.5 rounded-lg border border-[#E5E5E5] bg-white hover:border-[#111111] transition-colors cursor-pointer"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-medium text-[#6B6B6B]">Reserved</span>
                        <span className="h-2 w-2 rounded-full bg-amber-500" />
                      </div>
                      <div className="text-lg font-bold text-[#111111] mt-1">
                        {inventoryStats.reserved}
                      </div>
                      <span className="inline-block text-[10px] text-amber-700 font-medium mt-0.5">
                        Deposit pending
                      </span>
                    </div>

                    {/* Sold */}
                    <div
                      onClick={() => onNavigate('/admin/vehicles')}
                      className="p-2.5 rounded-lg border border-[#E5E5E5] bg-white hover:border-[#111111] transition-colors cursor-pointer"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-medium text-[#6B6B6B]">Sold</span>
                        <span className="h-2 w-2 rounded-full bg-blue-500" />
                      </div>
                      <div className="text-lg font-bold text-[#111111] mt-1">
                        {inventoryStats.sold}
                      </div>
                      <span className="inline-block text-[10px] text-blue-700 font-medium mt-0.5">
                        Transferred
                      </span>
                    </div>

                    {/* Archived */}
                    <div
                      onClick={() => onNavigate('/admin/vehicles')}
                      className="p-2.5 rounded-lg border border-[#E5E5E5] bg-white hover:border-[#111111] transition-colors cursor-pointer"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-medium text-[#6B6B6B]">Archived</span>
                        <Archive className="h-3 w-3 text-[#6B6B6B]" />
                      </div>
                      <div className="text-lg font-bold text-[#111111] mt-1">
                        {inventoryStats.archived}
                      </div>
                      <span className="inline-block text-[10px] text-zinc-500 font-medium mt-0.5">
                        Inactive history
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Enquiry Summary Card */}
            <Card className="border-[#E5E5E5] bg-white rounded-xl shadow-xs">
              <CardHeader className="pb-3 border-b border-[#F0F0EE]">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="h-9 w-9 rounded-lg bg-blue-50 text-blue-800 flex items-center justify-center">
                      <Inbox className="h-4.5 w-4.5" />
                    </div>
                    <div>
                      <CardTitle className="text-base font-bold text-[#111111]">
                        Enquiry Summary
                      </CardTitle>
                      <CardDescription className="text-xs text-[#6B6B6B]">
                        Status distribution of customer inquiries and appointment requests.
                      </CardDescription>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onNavigate('/admin/enquiries')}
                    className="text-xs text-[#173F35] hover:text-[#123129] p-1.5 h-auto gap-1"
                  >
                    <span>Enquiries</span>
                    <ArrowRight className="h-3 w-3" />
                  </Button>
                </div>
              </CardHeader>

              <CardContent className="pt-4 space-y-4">
                {/* Total Enquiries & Action Required */}
                <div className="grid grid-cols-2 gap-3">
                  <div
                    onClick={() => onNavigate('/admin/enquiries')}
                    className="p-3.5 rounded-lg bg-[#F7F7F5] border border-[#E5E5E5] hover:border-[#173F35]/40 transition-colors cursor-pointer"
                  >
                    <div className="text-xs font-medium text-[#6B6B6B]">Total Enquiries</div>
                    <div className="text-2xl font-bold font-heading text-[#111111] mt-1">
                      {enquiryStats.total}
                    </div>
                    <div className="text-[11px] text-[#6B6B6B] mt-0.5">All customer submissions</div>
                  </div>

                  <div
                    onClick={() => onNavigate('/admin/enquiries')}
                    className={`p-3.5 rounded-lg border transition-colors cursor-pointer ${
                      enquiryStats.new > 0
                        ? 'bg-emerald-50/70 border-emerald-300 hover:border-emerald-400'
                        : 'bg-[#F7F7F5] border-[#E5E5E5]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-emerald-900">New / Unopened</span>
                      {enquiryStats.new > 0 && (
                        <span className="flex h-2 w-2 relative">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-600" />
                        </span>
                      )}
                    </div>
                    <div className="text-2xl font-bold font-heading text-emerald-950 mt-1">
                      {enquiryStats.new}
                    </div>
                    <div className="text-[11px] text-emerald-800/80 mt-0.5">
                      {enquiryStats.new > 0 ? 'Requires prompt concierge contact' : 'All consultations initiated'}
                    </div>
                  </div>
                </div>

                {/* Enquiry Status Grid (Strictly: NEW, CONTACTED, FOLLOW_UP, CONVERTED, CLOSED) */}
                <div className="pt-1">
                  <div className="text-xs font-semibold uppercase tracking-wider text-[#6B6B6B] mb-2.5">
                    Pipeline Stages
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    {/* New */}
                    <div
                      onClick={() => onNavigate('/admin/enquiries')}
                      className="p-2.5 rounded-lg border border-emerald-200 bg-emerald-50/40 hover:border-emerald-400 transition-colors cursor-pointer text-center sm:text-left"
                    >
                      <span className="text-[10px] font-semibold text-emerald-900 block">New</span>
                      <div className="text-lg font-bold text-emerald-950 mt-0.5">
                        {enquiryStats.new}
                      </div>
                    </div>

                    {/* Contacted */}
                    <div
                      onClick={() => onNavigate('/admin/enquiries')}
                      className="p-2.5 rounded-lg border border-[#E5E5E5] bg-white hover:border-[#111111] transition-colors cursor-pointer text-center sm:text-left"
                    >
                      <span className="text-[10px] font-semibold text-blue-900 block">Contacted</span>
                      <div className="text-lg font-bold text-[#111111] mt-0.5">
                        {enquiryStats.contacted}
                      </div>
                    </div>

                    {/* Follow-up */}
                    <div
                      onClick={() => onNavigate('/admin/enquiries')}
                      className="p-2.5 rounded-lg border border-[#E5E5E5] bg-white hover:border-[#111111] transition-colors cursor-pointer text-center sm:text-left"
                    >
                      <span className="text-[10px] font-semibold text-amber-900 block">Follow-Up</span>
                      <div className="text-lg font-bold text-[#111111] mt-0.5">
                        {enquiryStats.followUp}
                      </div>
                    </div>

                    {/* Converted */}
                    <div
                      onClick={() => onNavigate('/admin/enquiries')}
                      className="p-2.5 rounded-lg border border-[#E5E5E5] bg-white hover:border-[#111111] transition-colors cursor-pointer text-center sm:text-left"
                    >
                      <span className="text-[10px] font-semibold text-purple-900 block">Converted</span>
                      <div className="text-lg font-bold text-[#111111] mt-0.5">
                        {enquiryStats.converted}
                      </div>
                    </div>

                    {/* Closed */}
                    <div
                      onClick={() => onNavigate('/admin/enquiries')}
                      className="p-2.5 rounded-lg border border-[#E5E5E5] bg-white hover:border-[#111111] transition-colors cursor-pointer text-center sm:text-left"
                    >
                      <span className="text-[10px] font-semibold text-zinc-600 block">Closed</span>
                      <div className="text-lg font-bold text-[#111111] mt-0.5">
                        {enquiryStats.closed}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Section: Recent Enquiries */}
          <Card className="border-[#E5E5E5] bg-white rounded-xl shadow-xs overflow-hidden">
            <CardHeader className="p-4 sm:p-5 border-b border-[#F0F0EE] flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <CardTitle className="text-base font-bold text-[#111111] flex items-center gap-2">
                  <Clock className="h-4 w-4 text-[#173F35]" />
                  Recent Inquiries Queue
                </CardTitle>
                <CardDescription className="text-xs text-[#6B6B6B] mt-0.5">
                  Latest customer consultations and test-drive requests awaiting dealer action.
                </CardDescription>
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={() => onNavigate('/admin/enquiries')}
                className="text-xs gap-1.5 h-8 border-[#E5E5E5] hover:border-[#111111] self-start sm:self-auto"
              >
                <span>View All Enquiries</span>
                <ArrowRight className="h-3 w-3" />
              </Button>
            </CardHeader>

            <CardContent className="p-0">
              {recentEnquiries.length === 0 ? (
                <div className="p-8 text-center space-y-3">
                  <div className="mx-auto h-12 w-12 rounded-full bg-[#F0F0EE] flex items-center justify-center text-[#6B6B6B]">
                    <Inbox className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-[#111111]">No Inquiries Logged Yet</h4>
                    <p className="text-xs text-[#6B6B6B] max-w-sm mx-auto mt-1">
                      Customer test-drive requests and vehicle consultations submitted through the showroom website will appear here in real time.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="divide-y divide-[#F0F0EE]">
                  {recentEnquiries.map((enquiry) => (
                    <div
                      key={enquiry.id}
                      onClick={() => onNavigate(`/admin/enquiries/${enquiry.id}`)}
                      className="p-4 sm:px-5 hover:bg-[#F7F7F5] transition-colors cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
                    >
                      {/* Left: Customer info & type */}
                      <div className="flex items-start sm:items-center gap-3 min-w-0">
                        <div className="h-9 w-9 rounded-full bg-[#173F35]/10 text-[#173F35] font-bold text-xs flex items-center justify-center shrink-0">
                          {enquiry.customer_name
                            .split(' ')
                            .map((p) => p[0])
                            .slice(0, 2)
                            .join('')
                            .toUpperCase()}
                        </div>

                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-heading font-bold text-sm text-[#111111] truncate group-hover:text-[#173F35] transition-colors">
                              {enquiry.customer_name}
                            </span>
                            {getEnquiryTypeBadge(enquiry.enquiry_type as EnquiryType)}
                            {getEnquiryStatusBadge(enquiry.status as EnquiryStatus)}
                          </div>

                          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[#6B6B6B] mt-0.5">
                            {/* Related Vehicle Summary */}
                            {enquiry.vehicle ? (
                              <span className="flex items-center gap-1 font-medium text-[#111111]">
                                <CarFront className="h-3 w-3 text-[#173F35]" />
                                {enquiry.vehicle.manufacturing_year} {enquiry.vehicle.make} {enquiry.vehicle.model}
                                <span className="text-[11px] font-mono text-[#6B6B6B]">
                                  ({enquiry.vehicle.stock_id})
                                </span>
                              </span>
                            ) : (
                              <span className="text-zinc-500 italic">General Showroom Consultation</span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Right: Date/Time and Action */}
                      <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#F0F0EE]">
                        <div className="text-right">
                          <span className="text-xs text-[#6B6B6B] block">
                            {formatDateTime(enquiry.created_at)}
                          </span>
                          <span className="text-[11px] text-zinc-500">
                            via {enquiry.source || 'WEBSITE'}
                          </span>
                        </div>

                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            onNavigate(`/admin/enquiries/${enquiry.id}`);
                          }}
                          className="h-8 px-2.5 text-xs text-[#173F35] hover:text-[#123129] hover:bg-[#173F35]/10 gap-1"
                        >
                          <span>Review</span>
                          <ArrowRight className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Operational Security & Integrity Verification Footer */}
          <div className="p-4 rounded-xl border border-[#E5E5E5] bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-[#6B6B6B]">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-emerald-700 shrink-0" />
              <span>
                <strong>System Security:</strong> Dashboard aggregates are strictly scoped to authenticated administrators with authoritative role verification.
              </span>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-[#6B6B6B] shrink-0">
              <span>Status: Active Session</span>
              <span>•</span>
              <span>RLS Enforced</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
