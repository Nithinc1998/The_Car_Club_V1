import React from 'react';
import { Settings, Save, MapPin, Mail, Phone, Clock, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface AdminSettingsRouteProps {
  onNavigate: (path: string) => void;
}

export const AdminSettingsRoute: React.FC<AdminSettingsRouteProps> = () => {
  return (
    <div className="space-y-6">
      {/* Route Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5E5E5] pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-[#6B6B6B] mb-1">
            <span>Route:</span>
            <code className="bg-[#F0F0EE] px-1.5 py-0.5 rounded text-[#111111] font-mono">
              /admin/settings
            </code>
          </div>
          <h2 className="font-heading text-2xl font-bold text-[#111111]">
            Dealership Configuration & Preferences
          </h2>
          <p className="text-xs text-[#6B6B6B] mt-0.5">
            Operational contact parameters and showroom viewing schedules.
          </p>
        </div>

        <Button variant="accent" size="sm" disabled className="text-xs gap-1.5">
          <Save className="h-3.5 w-3.5" />
          <span>Save Changes (Pending DB)</span>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Dealership Identity */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Settings className="h-4 w-4 text-[#173F35]" />
              <CardTitle className="text-base">Identity & Branding</CardTitle>
            </div>
            <CardDescription className="text-xs">
              Primary entity metadata presented across public headers and footers.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="brand-name">Platform Name</Label>
              <Input id="brand-name" defaultValue="The Car Club" disabled />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="brand-email">Concierge Dispatch Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-2.5 h-4 w-4 text-[#6B6B6B]" />
                <Input id="brand-email" defaultValue="concierge@thecarclub.example" className="pl-9 text-xs" disabled />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="brand-phone">Direct Line</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-2.5 h-4 w-4 text-[#6B6B6B]" />
                <Input id="brand-phone" defaultValue="+1 (555) 019-2834" className="pl-9 text-xs" disabled />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Physical Showroom & Hours */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-[#173F35]" />
              <CardTitle className="text-base">Showroom & Operating Hours</CardTitle>
            </div>
            <CardDescription className="text-xs">
              Physical address details and private consultation appointment windows.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="showroom-addr">Address</Label>
              <Input id="showroom-addr" defaultValue="100 Motorway Way, Suite 400" disabled />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="showroom-hours">Consultation Schedule</Label>
              <div className="relative">
                <Clock className="absolute left-3 top-2.5 h-4 w-4 text-[#6B6B6B]" />
                <Input id="showroom-hours" defaultValue="Mon-Fri: 09:00 - 18:00 (Sat by appt)" className="pl-9 text-xs" disabled />
              </div>
            </div>

            <div className="p-3 rounded-lg bg-[#F7F7F5] border border-[#E5E5E5] text-[11px] text-[#6B6B6B] flex items-start gap-2">
              <ShieldCheck className="h-4 w-4 text-[#173F35] shrink-0 mt-0.5" />
              <span>
                Settings entity mapped to <code className="font-mono text-[#111111]">settings</code> Supabase table in Milestone 2.
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
