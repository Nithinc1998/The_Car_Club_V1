import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Inbox,
  CheckCircle2,
  AlertCircle,
  Phone,
  Mail,
  Calendar,
  Clock,
  CarFront,
  ExternalLink,
  ShieldCheck,
  Send,
  Tag,
  RefreshCw,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import {
  getAdminEnquiryById,
  updateAdminEnquiryStatus,
  EnquiryWithVehicle,
} from '@/lib/services/enquiry-service';
import { EnquiryStatus, enquiryStatuses } from '@/lib/validations/enquiry';

interface AdminEnquiryDetailRouteProps {
  id: string;
  onNavigate: (path: string) => void;
}

export const AdminEnquiryDetailRoute: React.FC<AdminEnquiryDetailRouteProps> = ({
  id,
  onNavigate,
}) => {
  const [enquiry, setEnquiry] = useState<EnquiryWithVehicle | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  const loadEnquiry = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getAdminEnquiryById(id);
      if (res.error || !res.enquiry) {
        setError(res.error || 'Enquiry record not found.');
      } else {
        setEnquiry(res.enquiry);
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to retrieve enquiry.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEnquiry();
  }, [id]);

  const handleStatusChange = async (newStatus: EnquiryStatus) => {
    if (!enquiry) return;
    setIsUpdatingStatus(true);
    setActionSuccess(null);
    try {
      const res = await updateAdminEnquiryStatus(enquiry.id, newStatus);
      if (!res.success) {
        setError(res.error || 'Failed to update enquiry status.');
      } else {
        setActionSuccess(`Enquiry status updated to ${newStatus}.`);
        setEnquiry((prev) => (prev ? { ...prev, status: newStatus } : null));
        setTimeout(() => setActionSuccess(null), 4000);
      }
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const formatPrice = (price?: number | null) => {
    if (!price) return null;
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  if (loading) {
    return (
      <div className="py-24 text-center space-y-3">
        <RefreshCw className="h-8 w-8 text-[#173F35] animate-spin mx-auto" />
        <p className="text-xs text-[#6B6B6B] font-mono">Loading client enquiry record...</p>
      </div>
    );
  }

  if (error || !enquiry) {
    return (
      <div className="max-w-xl mx-auto py-16 space-y-4 text-center">
        <div className="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center mx-auto text-red-700">
          <AlertCircle className="h-6 w-6" />
        </div>
        <h2 className="font-heading text-xl font-bold text-[#111111]">
          Inquiry Record Not Found
        </h2>
        <p className="text-xs text-[#6B6B6B]">
          {error || `No enquiry record matching identifier "${id}" exists.`}
        </p>
        <Button
          variant="outline"
          size="sm"
          onClick={() => onNavigate('/admin/enquiries')}
          className="text-xs"
        >
          Return to Enquiries Queue
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Route & Back Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5E5E5] pb-4">
        <button
          type="button"
          onClick={() => onNavigate('/admin/enquiries')}
          className="inline-flex items-center text-xs text-[#6B6B6B] hover:text-[#111111] transition-colors gap-1.5"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Back to Inquiries Queue</span>
        </button>

        <div className="flex items-center gap-2 text-xs text-[#6B6B6B]">
          <span>Enquiry ID:</span>
          <code className="bg-[#F0F0EE] px-1.5 py-0.5 rounded text-[#111111] font-mono text-[11px]">
            {enquiry.id}
          </code>
        </div>
      </div>

      {actionSuccess && (
        <div className="p-3.5 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center gap-2 text-xs text-emerald-900 animate-in fade-in">
          <CheckCircle2 className="h-4 w-4 text-emerald-700 shrink-0" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {/* Main Header Card */}
      <div className="p-6 rounded-xl border border-[#E5E5E5] bg-white space-y-4 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <Badge variant="accent">{enquiry.enquiry_type}</Badge>
              <span className="font-mono text-[10px] text-[#6B6B6B] bg-[#F0F0EE] px-2 py-0.5 rounded">
                Source: {enquiry.source}
              </span>
              <span className="text-xs text-[#6B6B6B] font-mono">
                Received:{' '}
                {new Date(enquiry.created_at).toLocaleString('en-GB', {
                  day: '2-digit',
                  month: 'short',
                  year: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </span>
            </div>

            <h1 className="font-heading text-2xl sm:text-3xl font-extrabold text-[#111111]">
              {enquiry.customer_name}
            </h1>
          </div>

          {/* Quick Contact & Status Selector */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Click-to-call action */}
            <a
              href={`tel:${enquiry.phone.replace(/[^0-9+]/g, '')}`}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#111111] text-white hover:bg-[#222222] text-xs font-semibold shadow-xs transition-colors"
            >
              <Phone className="h-3.5 w-3.5" />
              <span>Call Client</span>
            </a>

            {/* Click-to-email action */}
            {enquiry.email && (
              <a
                href={`mailto:${enquiry.email}?subject=The%20Car%20Club%20-%20Inquiry%20Regarding%20${encodeURIComponent(
                  enquiry.vehicle ? `${enquiry.vehicle.make} ${enquiry.vehicle.model}` : 'Showroom Consultation'
                )}`}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#E5E5E5] bg-white hover:bg-[#F7F7F5] text-xs font-semibold text-[#111111] shadow-xs transition-colors"
              >
                <Mail className="h-3.5 w-3.5" />
                <span>Send Email</span>
              </a>
            )}

            {/* Status Change Selector */}
            <div className="flex items-center gap-1.5 bg-[#F7F7F5] border border-[#E5E5E5] px-2.5 py-1 rounded-lg">
              <span className="text-[11px] font-semibold text-[#6B6B6B]">Status:</span>
              <select
                value={enquiry.status}
                disabled={isUpdatingStatus}
                onChange={(e) => handleStatusChange(e.target.value as EnquiryStatus)}
                className="bg-transparent text-xs font-bold text-[#111111] focus:outline-none cursor-pointer"
              >
                {enquiryStatuses.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Detail Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Customer Prospect Details */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="border border-[#E5E5E5]">
            <CardHeader className="border-b border-[#E5E5E5] pb-4">
              <CardTitle className="text-base text-[#111111]">
                Customer & Inquiry Specifics
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="p-3 rounded-lg bg-[#F7F7F5] space-y-1">
                  <span className="text-[11px] text-[#6B6B6B] font-medium">Contact Phone</span>
                  <div className="font-mono font-bold text-sm text-[#111111]">{enquiry.phone}</div>
                </div>

                <div className="p-3 rounded-lg bg-[#F7F7F5] space-y-1">
                  <span className="text-[11px] text-[#6B6B6B] font-medium">Email Address</span>
                  <div className="font-mono text-xs text-[#111111] truncate">
                    {enquiry.email || <span className="italic text-zinc-400">Not provided</span>}
                  </div>
                </div>
              </div>

              {/* Specific Proposal or Scheduling Blocks */}
              {enquiry.enquiry_type === 'TEST_DRIVE' && (
                <div className="p-4 rounded-lg bg-emerald-50 border border-emerald-200 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-950">
                    <Calendar className="h-4 w-4 text-emerald-800" />
                    <span>Requested Test-Drive Schedule</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-emerald-800 text-[11px]">Requested Date:</span>
                      <p className="font-bold text-emerald-950 font-mono">
                        {enquiry.preferred_date || 'Flexible'}
                      </p>
                    </div>
                    <div>
                      <span className="text-emerald-800 text-[11px]">Preferred Time:</span>
                      <p className="font-bold text-emerald-950 font-mono">
                        {enquiry.preferred_time || 'Showroom Hours'}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {enquiry.enquiry_type === 'OFFER' && (
                <div className="p-4 rounded-lg bg-purple-50 border border-purple-200 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-purple-950">
                    <Tag className="h-4 w-4 text-purple-800" />
                    <span>Purchase Offer Proposal</span>
                  </div>
                  <div className="font-heading text-2xl font-extrabold text-purple-950">
                    {formatPrice(enquiry.offer_amount)}
                  </div>
                  {enquiry.vehicle && (
                    <p className="text-[11px] text-purple-900">
                      Vehicle Asking Price: {formatPrice(enquiry.vehicle.asking_price)} (Difference:{' '}
                      {formatPrice((enquiry.offer_amount || 0) - enquiry.vehicle.asking_price)})
                    </p>
                  )}
                </div>
              )}

              {/* Message / Conversation Notes */}
              <div className="space-y-2">
                <Label className="text-xs font-semibold text-[#111111]">
                  Customer Message / Inbound Remarks
                </Label>
                <div className="p-4 rounded-lg border border-[#E5E5E5] bg-[#F7F7F5] text-xs text-[#111111] leading-relaxed whitespace-pre-wrap">
                  {enquiry.message || (
                    <span className="italic text-[#6B6B6B]">
                      No additional message provided. Prospect requested direct contact for {enquiry.enquiry_type}.
                    </span>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Vehicle Relationship */}
        <div className="space-y-6">
          <Card className="border border-[#E5E5E5]">
            <CardHeader className="border-b border-[#E5E5E5] pb-4">
              <CardTitle className="text-base text-[#111111]">Associated Vehicle Record</CardTitle>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              {enquiry.vehicle ? (
                <div className="space-y-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-[#173F35] bg-[#E9EFEF] px-2 py-0.5 rounded">
                        {enquiry.vehicle.stock_id}
                      </span>
                      <Badge variant="outline">{enquiry.vehicle.status}</Badge>
                    </div>

                    <h4 className="font-heading text-base font-bold text-[#111111] pt-1">
                      {enquiry.vehicle.manufacturing_year} {enquiry.vehicle.make}{' '}
                      {enquiry.vehicle.model}
                    </h4>
                    {enquiry.vehicle.variant && (
                      <p className="text-xs text-[#6B6B6B]">{enquiry.vehicle.variant}</p>
                    )}
                    <p className="font-heading font-extrabold text-sm text-[#111111] pt-1">
                      {formatPrice(enquiry.vehicle.asking_price)}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-[#E5E5E5] space-y-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onNavigate(`/admin/vehicles/${enquiry.vehicle?.id}`)}
                      className="w-full text-xs gap-1.5"
                    >
                      <CarFront className="h-3.5 w-3.5 text-[#173F35]" />
                      <span>Open Vehicle Record in Admin</span>
                    </Button>

                    {enquiry.vehicle.is_published && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onNavigate(`/cars/${enquiry.vehicle?.slug}`)}
                        className="w-full text-xs gap-1.5 text-[#6B6B6B]"
                      >
                        <ExternalLink className="h-3.5 w-3.5" />
                        <span>View on Public Showroom</span>
                      </Button>
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-center py-6 space-y-2">
                  <div className="h-10 w-10 rounded-full bg-[#F7F7F5] flex items-center justify-center mx-auto text-[#6B6B6B]">
                    <Inbox className="h-5 w-5" />
                  </div>
                  <h4 className="font-heading text-sm font-bold text-[#111111]">
                    General Showroom Inquiry
                  </h4>
                  <p className="text-xs text-[#6B6B6B]">
                    This inquiry was submitted from the general contact channel without referencing a specific stock inventory unit.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Compliance & Privacy Card */}
          <Card className="border border-[#E5E5E5] bg-[#F7F7F5]">
            <CardContent className="p-4 space-y-2 text-xs text-[#6B6B6B]">
              <div className="flex items-center gap-1.5 font-bold text-[#111111]">
                <ShieldCheck className="h-4 w-4 text-[#173F35]" />
                <span>Customer Data Privacy</span>
              </div>
              <p className="text-[11px] leading-relaxed">
                Client correspondence and proposal figures remain strictly confidential. Access is logged and restricted to authorized dealership administrators.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
