import React from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface ErrorStateProps {
  error?: Error | string | null;
  onRetry?: () => void;
}

export const ErrorState: React.FC<ErrorStateProps> = ({
  error = 'An unexpected runtime condition occurred.',
  onRetry,
}) => {
  const errorMessage = typeof error === 'string' ? error : error?.message || 'Unexpected application error';

  return (
    <div className="min-h-[50vh] flex items-center justify-center p-6">
      <Card className="max-w-md w-full border-[#E5E5E5] bg-white p-6 text-center shadow-sm">
        <CardContent className="space-y-4 pt-4">
          <div className="h-12 w-12 rounded-full bg-red-50 text-red-700 flex items-center justify-center mx-auto">
            <AlertTriangle className="h-6 w-6" />
          </div>

          <div className="space-y-1">
            <h3 className="font-heading text-lg font-bold text-[#111111]">
              Application Runtime Notice
            </h3>
            <p className="text-xs text-[#6B6B6B] leading-relaxed">
              {errorMessage}
            </p>
          </div>

          {onRetry && (
            <div className="pt-2">
              <Button
                variant="outline"
                size="sm"
                onClick={onRetry}
                className="gap-2 text-xs"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Retry Operation</span>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
