import React from 'react';
import { Compass, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface NotFoundRouteProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

export const NotFoundRoute: React.FC<NotFoundRouteProps> = ({ currentPath, onNavigate }) => {
  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-16">
      <Card className="max-w-md w-full border-[#E5E5E5] bg-white text-center p-6 shadow-sm">
        <CardContent className="space-y-6 pt-4">
          <div className="h-14 w-14 rounded-full bg-[#F7F7F5] flex items-center justify-center mx-auto text-[#173F35]">
            <Compass className="h-7 w-7" />
          </div>

          <div className="space-y-2">
            <span className="text-xs uppercase font-mono tracking-widest text-[#6B6B6B]">
              404 — Page Not Found
            </span>
            <h2 className="font-heading text-2xl font-bold text-[#111111]">
              Destination Not Located
            </h2>
            <p className="text-xs text-[#6B6B6B] leading-relaxed">
              The requested path <code className="font-mono bg-[#F0F0EE] px-1.5 py-0.5 rounded text-[#111111]">{currentPath}</code> does not match any route in the current release foundation.
            </p>
          </div>

          <div className="pt-2">
            <Button
              variant="default"
              onClick={() => onNavigate('/')}
              className="gap-2 text-xs"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              <span>Return to Public Showroom</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
