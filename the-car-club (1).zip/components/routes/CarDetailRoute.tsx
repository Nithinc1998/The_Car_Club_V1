import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  ShieldCheck,
  Mail,
  Calendar,
  Gauge,
  Cog,
  Fuel,
  CarFront,
  CheckCircle2,
  AlertCircle,
  Clock,
  Phone,
  Tag,
  Send,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  getPublicVehicleBySlug,
  PublicShowroomVehicle,
} from '@/lib/services/vehicle-service';
import {
  submitPublicEnquiry,
  publicEnquirySchema,
} from '@/lib/services/enquiry-service';
import { EnquiryType } from '@/lib/validations/enquiry';

interface CarDetailRouteProps {
  slug: string;
  onNavigate: (path: string) => void;
}

export const CarDetailRoute: React.FC<CarDetailRouteProps> = ({ slug, onNavigate }) => {
  const [vehicle, setVehicle] = useState<PublicShowroomVehicle | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  // Enquiry modal / inline form state
  const [enquiryType, setEnquiryType] = useState<EnquiryType>('VEHICLE');
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [preferredDate, setPreferredDate] = useState('');
  const [preferredTime, setPreferredTime] = useState('');
  const [offerAmount, setOfferAmount] = useState<string>('');
  const [message, setMessage] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
  const [submissionSuccess, setSubmissionSuccess] = useState<string | null>(null);
  const [submissionError, setSubmissionError] = useState<string | null>(null);

  useEffect(() => {
    const fetchVehicle = async () => {
      setLoading(true);
      try {
        const res = await getPublicVehicleBySlug(slug);
        setVehicle(res.vehicle);
      } catch {
        setVehicle(null);
      } finally {
        setLoading(false);
      }
    };

    fetchVehicle();
  }, [slug]);

  const handleEnquirySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!vehicle) return;

    setFormErrors({});
    setSubmissionError(null);

    const parsedOffer =
      enquiryType === 'OFFER' && offerAmount.trim() !== ''
        ? parseFloat(offerAmount)
        : undefined;

    const payload = {
      customer_name: customerName,
      phone,
      email: email.trim() || undefined,
      enquiry_type: enquiryType,
      vehicle_id: vehicle.id,
      preferred_date: preferredDate.trim() || undefined,
      preferred_time: preferredTime.trim() || undefined,
      offer_amount: parsedOffer,
      message: message.trim() || undefined,
    };

    // Client-side validation check
    const validation = publicEnquirySchema.safeParse(payload);
    if (!validation.success) {
      const errMap: { [key: string]: string } = {};
      validation.error.issues.forEach((err) => {
        if (err.path[0]) {
          errMap[err.path[0].toString()] = err.message;
        }
      });
      setFormErrors(errMap);
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await submitPublicEnquiry(validation.data);
      if (!res.success) {
        setSubmissionError(res.error || 'Failed to submit enquiry. Please try again.');
      } else {
        setSubmissionSuccess(
          enquiryType === 'TEST_DRIVE'
            ? `Your test-drive request for ${vehicle.make} ${vehicle.model} on ${preferredDate} has been received. Our concierge will review vehicle scheduling and contact you directly.`
            : enquiryType === 'OFFER'
            ? `Your acquisition proposal of ₹${parsedOffer?.toLocaleString('en-IN')} has been received and routed to our sales management.`
            : enquiryType === 'CALLBACK'
            ? `Your callback request has been logged. An advisor will contact you at ${phone}.`
            : `Your inquiry for the ${vehicle.make} ${vehicle.model} has been received. Our concierge will follow up promptly.`
        );
      }
    } catch (err: unknown) {
      setSubmissionError(err instanceof Error ? err.message : 'An error occurred during submission.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8 text-center space-y-3">
        <div className="h-8 w-8 rounded-full border-2 border-[#173F35] border-t-transparent animate-spin mx-auto"></div>
        <p className="text-xs text-[#6B6B6B] font-mono">Loading verified vehicle specifications...</p>
      </div>
    );
  }

  // If vehicle is not published or not available, show public boundary 404
  if (!vehicle) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8 space-y-6 text-center">
        <div className="h-14 w-14 rounded-full bg-[#F7F7F5] flex items-center justify-center mx-auto text-[#6B6B6B]">
          <CarFront className="h-7 w-7" />
        </div>
        <div>
          <h1 className="font-heading text-2xl font-bold text-[#111111]">
            Vehicle Record Not Available
          </h1>
          <p className="text-xs sm:text-sm text-[#6B6B6B] mt-1 max-w-md mx-auto">
            The requested vehicle URL <code className="font-mono text-[#111111]">/cars/{slug}</code> is not available in the public inventory catalog or has been reserved/sold.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={() => onNavigate('/cars')}
          className="text-xs"
        >
          Return to Showroom Catalog
        </Button>
      </div>
    );
  }

  const galleryImages = (vehicle.media || []).filter((m) => m.media_type === 'IMAGE');
  const activeImageUrl =
    galleryImages[activeImageIndex]?.publicUrl || vehicle.cover_image_url;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      {/* Back button & Breadcrumb */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => onNavigate('/cars')}
          className="inline-flex items-center text-xs font-medium text-[#6B6B6B] hover:text-[#111111] transition-colors gap-1.5 focus:outline-none"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Back to Inventory</span>
        </button>

        <div className="flex items-center gap-2 text-xs text-[#6B6B6B]">
          <span>Stock ID:</span>
          <code className="bg-[#E9EFEF] px-1.5 py-0.5 rounded text-[#173F35] font-mono font-bold">
            {vehicle.stock_id}
          </code>
        </div>
      </div>

      {/* Vehicle Header */}
      <div className="border-b border-[#E5E5E5] pb-6 space-y-2">
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="accent">Available for Acquisition</Badge>
          <span className="text-xs font-mono text-[#6B6B6B]">
            {vehicle.manufacturing_year} Model Year
          </span>
        </div>
        <h1 className="font-heading text-3xl sm:text-4xl font-extrabold text-[#111111]">
          {vehicle.make} {vehicle.model}
          {vehicle.variant && (
            <span className="font-normal text-[#6B6B6B] text-2xl sm:text-3xl ml-2">
              {vehicle.variant}
            </span>
          )}
        </h1>
        {vehicle.short_description && (
          <p className="text-sm text-[#6B6B6B] max-w-3xl">{vehicle.short_description}</p>
        )}
      </div>

      {/* Main Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Gallery & Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Main Photo Frame */}
          <div className="space-y-3">
            <div className="aspect-16/10 rounded-xl border border-[#E5E5E5] bg-[#111111] overflow-hidden flex items-center justify-center relative shadow-sm">
              {activeImageUrl ? (
                <img
                  src={activeImageUrl}
                  alt={`${vehicle.make} ${vehicle.model}`}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="text-center text-white/50 p-8 space-y-2">
                  <CarFront className="h-12 w-12 mx-auto" />
                  <p className="text-xs font-mono">Showroom Studio Photography</p>
                </div>
              )}
            </div>

            {/* Gallery Strip */}
            {galleryImages.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-1">
                {galleryImages.map((img, idx) => (
                  <button
                    key={img.id}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`h-16 w-24 rounded-lg overflow-hidden shrink-0 border-2 transition-all ${
                      activeImageIndex === idx
                        ? 'border-[#173F35] ring-2 ring-[#173F35]/20'
                        : 'border-[#E5E5E5] opacity-75 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={img.publicUrl}
                      alt={img.alt_text || 'Angle'}
                      loading="lazy"
                      className="h-full w-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Technical Specifications Grid */}
          <Card className="border border-[#E5E5E5]">
            <CardHeader className="border-b border-[#E5E5E5] pb-4">
              <CardTitle className="text-base text-[#111111]">
                Technical Specification Sheet
              </CardTitle>
              <CardDescription className="text-xs">
                Verified automotive parameters and documentation.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                <div className="p-3 rounded-lg bg-[#F7F7F5]">
                  <div className="flex items-center gap-1.5 text-[#6B6B6B] mb-1">
                    <Calendar className="h-3.5 w-3.5 text-[#173F35]" />
                    <span>Mfg Year</span>
                  </div>
                  <span className="font-semibold text-[#111111]">
                    {vehicle.manufacturing_year}
                  </span>
                </div>

                <div className="p-3 rounded-lg bg-[#F7F7F5]">
                  <div className="flex items-center gap-1.5 text-[#6B6B6B] mb-1">
                    <Gauge className="h-3.5 w-3.5 text-[#173F35]" />
                    <span>Odometer</span>
                  </div>
                  <span className="font-semibold text-[#111111]">
                    {vehicle.kilometers.toLocaleString('en-IN')} km
                  </span>
                </div>

                <div className="p-3 rounded-lg bg-[#F7F7F5]">
                  <div className="flex items-center gap-1.5 text-[#6B6B6B] mb-1">
                    <Cog className="h-3.5 w-3.5 text-[#173F35]" />
                    <span>Gearbox</span>
                  </div>
                  <span className="font-semibold text-[#111111]">
                    {vehicle.transmission}
                  </span>
                </div>

                <div className="p-3 rounded-lg bg-[#F7F7F5]">
                  <div className="flex items-center gap-1.5 text-[#6B6B6B] mb-1">
                    <Fuel className="h-3.5 w-3.5 text-[#173F35]" />
                    <span>Fuel Type</span>
                  </div>
                  <span className="font-semibold text-[#111111]">
                    {vehicle.fuel_type}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs pt-4">
                <div className="space-y-0.5">
                  <span className="text-[#6B6B6B]">Previous Owners:</span>
                  <p className="font-semibold text-[#111111]">
                    {vehicle.owners === 1 ? 'Single Owner' : `${vehicle.owners} Owners`}
                  </p>
                </div>
                {vehicle.color && (
                  <div className="space-y-0.5">
                    <span className="text-[#6B6B6B]">Exterior Paint:</span>
                    <p className="font-semibold text-[#111111]">{vehicle.color}</p>
                  </div>
                )}
                {vehicle.condition && (
                  <div className="space-y-0.5">
                    <span className="text-[#6B6B6B]">Condition Grade:</span>
                    <p className="font-semibold text-[#111111]">{vehicle.condition}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Features & Equipment List */}
          {vehicle.features && vehicle.features.length > 0 && (
            <Card className="border border-[#E5E5E5]">
              <CardHeader className="border-b border-[#E5E5E5] pb-4">
                <CardTitle className="text-base text-[#111111]">
                  Notable Factory Equipment & Options
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {vehicle.features.map((feat, i) => (
                    <div key={i} className="flex items-center gap-2 p-2 rounded bg-[#F7F7F5]">
                      <CheckCircle2 className="h-3.5 w-3.5 text-[#173F35] shrink-0" />
                      <span className="text-[#111111] font-medium">{feat}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Full Narrative Description */}
          {vehicle.description && (
            <Card className="border border-[#E5E5E5]">
              <CardHeader className="border-b border-[#E5E5E5] pb-4">
                <CardTitle className="text-base text-[#111111]">
                  Automotive Provenance & Narrative
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <p className="text-xs sm:text-sm text-[#111111] leading-relaxed whitespace-pre-wrap">
                  {vehicle.description}
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Right Column: Pricing & Interactive Acquisition Concierge */}
        <div className="space-y-6">
          <Card className="border border-[#173F35]/30 shadow-md overflow-hidden">
            <CardHeader className="bg-[#173F35] text-white p-5">
              <div className="text-[10px] uppercase font-bold tracking-wider opacity-80">
                Showroom Asking Price
              </div>
              <div className="font-heading text-2xl sm:text-3xl font-extrabold mt-0.5">
                {formatPrice(vehicle.asking_price)}
              </div>
              <div className="flex items-center gap-2 pt-2 text-xs text-white/90">
                <ShieldCheck className="h-4 w-4 text-emerald-300 shrink-0" />
                <span>Verified Clean Title & History</span>
              </div>
            </CardHeader>

            <CardContent className="p-5 space-y-4 bg-white">
              {submissionSuccess ? (
                <div className="p-5 rounded-lg bg-emerald-50 border border-emerald-200 text-center space-y-3 animate-in fade-in">
                  <div className="h-10 w-10 rounded-full bg-emerald-100 flex items-center justify-center mx-auto text-emerald-800">
                    <CheckCircle2 className="h-6 w-6" />
                  </div>
                  <h4 className="font-heading text-sm font-bold text-emerald-950">
                    Enquiry Submitted Successfully
                  </h4>
                  <p className="text-xs text-emerald-800 leading-relaxed">
                    {submissionSuccess}
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSubmissionSuccess(null);
                      setMessage('');
                      setOfferAmount('');
                    }}
                    className="text-xs mt-2"
                  >
                    Submit Another Request
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleEnquirySubmit} className="space-y-4">
                  {/* Enquiry Type Selector Tabs */}
                  <div className="space-y-1.5">
                    <Label className="text-xs font-semibold text-[#111111]">
                      Inquiry Intent
                    </Label>
                    <div className="grid grid-cols-2 gap-1 bg-[#F7F7F5] p-1 rounded-lg border border-[#E5E5E5] text-xs">
                      <button
                        type="button"
                        onClick={() => {
                          setEnquiryType('VEHICLE');
                          setFormErrors({});
                        }}
                        className={`py-1.5 px-2 rounded font-medium transition-colors ${
                          enquiryType === 'VEHICLE'
                            ? 'bg-[#111111] text-white shadow-xs'
                            : 'text-[#6B6B6B] hover:text-[#111111]'
                        }`}
                      >
                        Inquire
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setEnquiryType('TEST_DRIVE');
                          setFormErrors({});
                        }}
                        className={`py-1.5 px-2 rounded font-medium transition-colors ${
                          enquiryType === 'TEST_DRIVE'
                            ? 'bg-[#111111] text-white shadow-xs'
                            : 'text-[#6B6B6B] hover:text-[#111111]'
                        }`}
                      >
                        Test Drive
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setEnquiryType('OFFER');
                          setFormErrors({});
                        }}
                        className={`py-1.5 px-2 rounded font-medium transition-colors ${
                          enquiryType === 'OFFER'
                            ? 'bg-[#111111] text-white shadow-xs'
                            : 'text-[#6B6B6B] hover:text-[#111111]'
                        }`}
                      >
                        Make Offer
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setEnquiryType('CALLBACK');
                          setFormErrors({});
                        }}
                        className={`py-1.5 px-2 rounded font-medium transition-colors ${
                          enquiryType === 'CALLBACK'
                            ? 'bg-[#111111] text-white shadow-xs'
                            : 'text-[#6B6B6B] hover:text-[#111111]'
                        }`}
                      >
                        Callback
                      </button>
                    </div>
                  </div>

                  {submissionError && (
                    <div className="p-3 rounded bg-red-50 border border-red-200 text-xs text-red-800 flex items-start gap-2">
                      <AlertCircle className="h-4 w-4 text-red-600 shrink-0 mt-0.5" />
                      <span>{submissionError}</span>
                    </div>
                  )}

                  {/* Customer Information */}
                  <div className="space-y-1.5">
                    <Label htmlFor="cust_name" className="text-xs font-semibold text-[#111111]">
                      Your Full Name <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="cust_name"
                      placeholder="e.g. Anand Mahindra"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className={`text-xs ${formErrors.customer_name ? 'border-red-500' : ''}`}
                    />
                    {formErrors.customer_name && (
                      <p className="text-[11px] text-red-600">{formErrors.customer_name}</p>
                    )}
                  </div>

                  <div className="space-y-1.5">
                    <Label htmlFor="cust_phone" className="text-xs font-semibold text-[#111111]">
                      Contact Phone <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="cust_phone"
                      placeholder="+91 98765 43210"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className={`text-xs ${formErrors.phone ? 'border-red-500' : ''}`}
                    />
                    {formErrors.phone && (
                      <p className="text-[11px] text-red-600">{formErrors.phone}</p>
                    )}
                  </div>

                  <div className="space-y-1.5">
                    <Label htmlFor="cust_email" className="text-xs font-semibold text-[#111111]">
                      Email Address <span className="text-[#6B6B6B] font-normal">(Optional)</span>
                    </Label>
                    <Input
                      id="cust_email"
                      type="email"
                      placeholder="anand@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className={`text-xs ${formErrors.email ? 'border-red-500' : ''}`}
                    />
                    {formErrors.email && (
                      <p className="text-[11px] text-red-600">{formErrors.email}</p>
                    )}
                  </div>

                  {/* Conditional: TEST_DRIVE preferred date/time */}
                  {enquiryType === 'TEST_DRIVE' && (
                    <div className="grid grid-cols-2 gap-2 p-3 rounded-lg bg-[#F7F7F5] border border-[#E5E5E5] text-xs">
                      <div className="space-y-1">
                        <Label htmlFor="pref_date" className="text-[11px] font-semibold text-[#111111]">
                          Preferred Date <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="pref_date"
                          type="date"
                          value={preferredDate}
                          onChange={(e) => setPreferredDate(e.target.value)}
                          className={`text-xs bg-white ${
                            formErrors.preferred_date ? 'border-red-500' : ''
                          }`}
                        />
                        {formErrors.preferred_date && (
                          <p className="text-[10px] text-red-600">{formErrors.preferred_date}</p>
                        )}
                      </div>

                      <div className="space-y-1">
                        <Label htmlFor="pref_time" className="text-[11px] font-semibold text-[#111111]">
                          Preferred Time
                        </Label>
                        <Input
                          id="pref_time"
                          type="time"
                          value={preferredTime}
                          onChange={(e) => setPreferredTime(e.target.value)}
                          className="text-xs bg-white"
                        />
                      </div>
                    </div>
                  )}

                  {/* Conditional: OFFER amount input */}
                  {enquiryType === 'OFFER' && (
                    <div className="p-3 rounded-lg bg-[#F7F7F5] border border-[#E5E5E5] space-y-1.5">
                      <Label htmlFor="offer_amt" className="text-xs font-semibold text-[#111111]">
                        Proposed Acquisition Offer (₹ INR) <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="offer_amt"
                        type="number"
                        placeholder="e.g. 26000000"
                        value={offerAmount}
                        onChange={(e) => setOfferAmount(e.target.value)}
                        className={`text-xs bg-white font-bold ${
                          formErrors.offer_amount ? 'border-red-500' : ''
                        }`}
                      />
                      {formErrors.offer_amount && (
                        <p className="text-[11px] text-red-600">{formErrors.offer_amount}</p>
                      )}
                      <p className="text-[10px] text-[#6B6B6B]">
                        Formal non-binding buyer proposal submitted directly to management.
                      </p>
                    </div>
                  )}

                  {/* Message textarea */}
                  <div className="space-y-1.5">
                    <Label htmlFor="cust_msg" className="text-xs font-semibold text-[#111111]">
                      Additional Notes / Preferences
                    </Label>
                    <textarea
                      id="cust_msg"
                      rows={2}
                      placeholder={
                        enquiryType === 'TEST_DRIVE'
                          ? 'Specific route preference, trade-in interest...'
                          : enquiryType === 'OFFER'
                          ? 'Settlement terms, financing readiness...'
                          : 'Any specific documentation or questions...'
                      }
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="w-full rounded-md border border-[#E5E5E5] p-2 text-xs text-[#111111] focus:ring-1 focus:ring-[#173F35]"
                    />
                  </div>

                  <Button
                    type="submit"
                    variant="accent"
                    disabled={isSubmitting}
                    className="w-full text-xs h-10 gap-2 shadow-sm font-semibold"
                  >
                    <Send className="h-3.5 w-3.5" />
                    <span>{isSubmitting ? 'Submitting Inquiry...' : 'Submit Inquiry'}</span>
                  </Button>

                  <p className="text-[10px] text-center text-[#6B6B6B] leading-tight">
                    Submissions are kept strictly private under the dealership data policy.
                  </p>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
