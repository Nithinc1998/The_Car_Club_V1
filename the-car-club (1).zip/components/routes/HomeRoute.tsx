import React from 'react';
import { ArrowRight, Shield, Award, Sparkles, Database } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { isSupabaseConfigured } from '@/lib/supabase/client';

interface HomeRouteProps {
  onNavigate: (path: string) => void;
}

export const HomeRoute: React.FC<HomeRouteProps> = ({ onNavigate }) => {
  const supabaseReady = isSupabaseConfigured();

  return (
    <div className="space-y-16 py-8 md:py-16">
      {/* Hero Section */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl space-y-6">
          <div className="inline-flex items-center gap-2 rounded-full border border-[#E5E5E5] bg-white px-3 py-1 text-xs text-[#6B6B6B]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#173F35]" />
            <span>Palakkad, Kerala • Certified Pre-Owned Dealership</span>
          </div>

          <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-[#111111] leading-[1.1]">
            Curated automobiles for the discerning driver.
          </h1>

          <p className="text-lg text-[#6B6B6B] leading-relaxed max-w-2xl">
            The Car Club provides transparent provenance, mechanical inspection rigor, and private consultations for acquiring distinguished luxury and performance motor vehicles.
          </p>

          <div className="flex flex-wrap items-center gap-4 pt-2">
            <Button
              variant="accent"
              size="lg"
              onClick={() => onNavigate('/cars')}
              className="gap-2 cursor-pointer"
            >
              <span>Explore Inventory</span>
              <ArrowRight className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={() => onNavigate('/about')}
              className="cursor-pointer"
            >
              Our Heritage & Standards
            </Button>
          </div>
        </div>
      </section>

      {/* Dealership Operations & Standards Card */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Card className="border-[#E5E5E5] bg-white shadow-sm">
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <CardTitle className="text-xl">Dealership Operations & Standards</CardTitle>
                <CardDescription>
                  Single-showroom operations in Palakkad, Kerala. Verified inventory and discrete concierge service.
                </CardDescription>
              </div>
              <Badge variant={supabaseReady ? 'success' : 'secondary'} className="self-start">
                <Database className="mr-1.5 h-3 w-3" />
                {supabaseReady ? 'Supabase Connected' : 'Supabase Config Ready'}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              <div className="rounded-lg border border-[#E5E5E5] p-4 bg-[#F7F7F5]/50">
                <div className="flex items-center gap-2 mb-2 text-[#111111] font-semibold text-sm">
                  <Shield className="h-4 w-4 text-[#173F35]" />
                  <span>Verified Provenance</span>
                </div>
                <p className="text-xs text-[#6B6B6B] leading-relaxed">
                  Every vehicle undergoes rigorous service history verification, odometer validation, and structural assessment.
                </p>
              </div>

              <div className="rounded-lg border border-[#E5E5E5] p-4 bg-[#F7F7F5]/50">
                <div className="flex items-center gap-2 mb-2 text-[#111111] font-semibold text-sm">
                  <Award className="h-4 w-4 text-[#173F35]" />
                  <span>Curated Presentation</span>
                </div>
                <p className="text-xs text-[#6B6B6B] leading-relaxed">
                  Transparent specifications, complete factory options list, genuine multi-angle photography, and honest pricing.
                </p>
              </div>

              <div className="rounded-lg border border-[#E5E5E5] p-4 bg-[#F7F7F5]/50">
                <div className="flex items-center gap-2 mb-2 text-[#111111] font-semibold text-sm">
                  <Sparkles className="h-4 w-4 text-[#173F35]" />
                  <span>Private Consultation</span>
                </div>
                <p className="text-xs text-[#6B6B6B] leading-relaxed">
                  Bespoke test-drive scheduling, purchase proposals, and direct callback requests handled by dedicated automotive advisors.
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-[#E5E5E5] flex flex-wrap items-center justify-between text-xs text-[#6B6B6B]">
              <span>The Car Club • Palakkad, Kerala • Operating System V1 Production Baseline</span>
              <button
                onClick={() => onNavigate('/admin')}
                className="text-[#173F35] font-medium hover:underline inline-flex items-center gap-1 cursor-pointer"
              >
                Access Dealership Terminal →
              </button>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
};
