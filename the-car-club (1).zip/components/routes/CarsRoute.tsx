import React, { useState, useEffect } from 'react';
import { Search, Filter, CarFront, ArrowRight, Gauge, Fuel, Cog } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  getPublicVehicles,
  PublicShowroomVehicle,
} from '@/lib/services/vehicle-service';

interface CarsRouteProps {
  onNavigate: (path: string) => void;
}

export const CarsRoute: React.FC<CarsRouteProps> = ({ onNavigate }) => {
  const [vehicles, setVehicles] = useState<PublicShowroomVehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [testSlug, setTestSlug] = useState('porsche-911-gt3-touring-992-2023');

  const loadVehicles = async (query?: string) => {
    setLoading(true);
    try {
      const res = await getPublicVehicles(query);
      setVehicles(res.vehicles || []);
    } catch {
      setVehicles([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVehicles();
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    loadVehicles(searchQuery);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      {/* Route Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#E5E5E5] pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-[#6B6B6B] mb-1">
            <span>Showroom:</span>
            <code className="bg-[#F0F0EE] px-1.5 py-0.5 rounded text-[#111111] font-mono">/cars</code>
          </div>
          <h1 className="font-heading text-3xl font-extrabold text-[#111111]">
            Curated Automobile Inventory
          </h1>
          <p className="text-sm text-[#6B6B6B] mt-1">
            Exclusively acquired, verified sports cars, luxury grand tourers, and bespoke performance vehicles.
          </p>
        </div>

        <Badge variant="outline" className="self-start md:self-auto text-xs border-[#173F35] text-[#173F35]">
          Active Inventory ({vehicles.length})
        </Badge>
      </div>

      {/* Filter / Search Bar */}
      <form onSubmit={handleSearch} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-4 rounded-lg border border-[#E5E5E5] bg-white shadow-xs">
        <div className="relative lg:col-span-2">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-[#6B6B6B]" />
          <Input
            placeholder="Search make or model (e.g. Porsche, AMG, BMW)..."
            className="pl-9 text-xs"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div>
          <Button
            type="submit"
            variant="default"
            size="sm"
            className="w-full text-xs h-9 bg-[#111111] hover:bg-[#222222]"
          >
            Filter Showroom
          </Button>
        </div>
        {searchQuery && (
          <div>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => {
                setSearchQuery('');
                loadVehicles('');
              }}
              className="w-full text-xs h-9"
            >
              Reset Filter
            </Button>
          </div>
        )}
      </form>

      {/* Vehicle Grid or Empty State */}
      {loading ? (
        <div className="py-20 text-center space-y-3">
          <div className="h-8 w-8 rounded-full border-2 border-[#173F35] border-t-transparent animate-spin mx-auto"></div>
          <p className="text-xs text-[#6B6B6B] font-mono">Retrieving published showroom inventory...</p>
        </div>
      ) : vehicles.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {vehicles.map((v) => (
            <Card
              key={v.id}
              className="overflow-hidden border border-[#E5E5E5] hover:border-[#173F35]/40 transition-all group cursor-pointer shadow-xs hover:shadow-md flex flex-col"
              onClick={() => onNavigate(`/cars/${v.slug}`)}
            >
              {/* Media Thumbnail */}
              <div className="relative aspect-16/10 bg-[#F0F0EE] overflow-hidden">
                {v.cover_image_url ? (
                  <img
                    src={v.cover_image_url}
                    alt={`${v.make} ${v.model}${v.variant ? ' ' + v.variant : ''}`}
                    loading="lazy"
                    className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                ) : (
                  <div className="h-full w-full flex items-center justify-center text-[#6B6B6B]">
                    <CarFront className="h-10 w-10 opacity-50" />
                  </div>
                )}
                <div className="absolute top-3 left-3">
                  <span className="font-mono text-[10px] uppercase font-bold tracking-wider bg-black/60 text-white px-2 py-0.5 rounded backdrop-blur-xs">
                    {v.stock_id}
                  </span>
                </div>
              </div>

              {/* Vehicle Specs Content */}
              <CardContent className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-1.5">
                  <div className="text-xs text-[#6B6B6B] font-medium">
                    {v.manufacturing_year} • {v.owners === 1 ? '1 Owner' : `${v.owners} Owners`}
                  </div>
                  <h3 className="font-heading text-lg font-bold text-[#111111] group-hover:text-[#173F35] transition-colors leading-tight">
                    {v.make} {v.model}
                  </h3>
                  {v.variant && (
                    <p className="text-xs text-[#6B6B6B] line-clamp-1">{v.variant}</p>
                  )}
                  {v.short_description && (
                    <p className="text-xs text-[#6B6B6B] line-clamp-2 pt-1">
                      {v.short_description}
                    </p>
                  )}
                </div>

                <div className="pt-3 border-t border-[#E5E5E5] space-y-3">
                  <div className="grid grid-cols-3 gap-2 text-[11px] text-[#6B6B6B]">
                    <div className="flex items-center gap-1">
                      <Gauge className="h-3 w-3 text-[#173F35]" />
                      <span>{v.kilometers.toLocaleString('en-IN')} km</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Fuel className="h-3 w-3 text-[#173F35]" />
                      <span className="truncate">{v.fuel_type}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Cog className="h-3 w-3 text-[#173F35]" />
                      <span className="truncate">{v.transmission}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <div>
                      <div className="text-[10px] text-[#6B6B6B] uppercase font-bold tracking-wider">
                        Asking Price
                      </div>
                      <div className="font-heading text-base font-extrabold text-[#111111]">
                        {formatPrice(v.asking_price)}
                      </div>
                    </div>

                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs gap-1 group-hover:bg-[#173F35] group-hover:text-white transition-colors"
                      onClick={(e) => {
                        e.stopPropagation();
                        onNavigate(`/cars/${v.slug}`);
                      }}
                    >
                      <span>Explore</span>
                      <ArrowRight className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="border-dashed border-2 border-[#E5E5E5] bg-white text-center py-16">
          <CardContent className="space-y-4 max-w-md mx-auto">
            <div className="h-12 w-12 rounded-full bg-[#F7F7F5] flex items-center justify-center mx-auto text-[#173F35]">
              <CarFront className="h-6 w-6" />
            </div>
            <h3 className="font-heading text-lg font-bold text-[#111111]">
              No Available Vehicles Published
            </h3>
            <p className="text-sm text-[#6B6B6B] leading-relaxed">
              Showroom displays strictly vehicles matching status <code className="text-xs font-mono font-bold">AVAILABLE</code> and <code className="text-xs font-mono font-bold">is_published = true</code> with photo verification.
            </p>

            <div className="pt-4 border-t border-[#E5E5E5]">
              <p className="text-xs font-medium text-[#111111] mb-3">
                Test dynamic vehicle detail route:
              </p>
              <div className="flex items-center gap-2">
                <Input
                  value={testSlug}
                  onChange={(e) => setTestSlug(e.target.value)}
                  placeholder="Enter sample slug"
                  className="text-xs font-mono"
                />
                <Button
                  variant="accent"
                  size="sm"
                  onClick={() => onNavigate(`/cars/${testSlug}`)}
                  className="shrink-0 gap-1 text-xs"
                >
                  <span>View Route</span>
                  <ArrowRight className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
