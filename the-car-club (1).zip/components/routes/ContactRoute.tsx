import React, { useState } from 'react';
import {
  Mail,
  Phone,
  MapPin,
  Clock,
  Send,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { submitPublicEnquiry, publicEnquirySchema } from '@/lib/services/enquiry-service';
import { EnquiryType } from '@/lib/validations/enquiry';

interface ContactRouteProps {
  onNavigate: (path: string) => void;
}

export const ContactRoute: React.FC<ContactRouteProps> = () => {
  const [enquiryType, setEnquiryType] = useState<EnquiryType>('GENERAL');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });
  const [validationErrors, setValidationErrors] = useState<{ [key: string]: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedMessage, setSubmittedMessage] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationErrors({});
    setSubmitError(null);

    const payload = {
      customer_name: formData.name,
      email: formData.email.trim() || undefined,
      phone: formData.phone,
      enquiry_type: enquiryType,
      message: formData.message.trim() || undefined,
    };

    const result = publicEnquirySchema.safeParse(payload);
    if (!result.success) {
      const errors: { [key: string]: string } = {};
      result.error.issues.forEach((err) => {
        if (err.path[0]) {
          errors[err.path[0].toString()] = err.message;
        }
      });
      setValidationErrors(errors);
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await submitPublicEnquiry(result.data);
      if (!res.success) {
        setSubmitError(res.error || 'Failed to submit enquiry.');
      } else {
        setSubmittedMessage(
          enquiryType === 'CALLBACK'
            ? `Your callback request has been logged. Our concierge will call you at ${formData.phone}.`
            : 'Your message has been received. Our team will review your inquiry and follow up shortly.'
        );
      }
    } catch (err: unknown) {
      setSubmitError(err instanceof Error ? err.message : 'An error occurred during submission.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-12">
      {/* Route Header */}
      <div className="max-w-3xl space-y-4 border-b border-[#E5E5E5] pb-6">
        <div className="flex items-center gap-2 text-xs text-[#6B6B6B]">
          <span>Contact Concierge:</span>
          <code className="bg-[#F0F0EE] px-1.5 py-0.5 rounded text-[#111111] font-mono">/contact</code>
        </div>
        <h1 className="font-heading text-3xl sm:text-4xl font-extrabold text-[#111111]">
          Concierge & Showroom Appointments
        </h1>
        <p className="text-base text-[#6B6B6B] leading-relaxed">
          Arrange a private viewing or speak directly with an automotive advisor regarding acquisitions, sourcing, and technical documentation.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Contact Info Card */}
        <div className="space-y-6">
          <Card className="border border-[#E5E5E5]">
            <CardHeader className="border-b border-[#E5E5E5] pb-4">
              <CardTitle className="text-base text-[#111111]">Showroom Location</CardTitle>
              <CardDescription className="text-xs">Private consultations by prior arrangement</CardDescription>
            </CardHeader>
            <CardContent className="pt-4 space-y-4 text-xs text-[#6B6B6B]">
              <div className="flex items-start gap-3">
                <MapPin className="h-4 w-4 text-[#173F35] shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-[#111111]">The Car Club</p>
                  <p>Near Govt College, Chittur (P.O)</p>
                  <p>Palakkad, Kerala</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Phone className="h-4 w-4 text-[#173F35] shrink-0" />
                <div>
                  <p className="font-semibold text-[#111111]">Direct Inquiries</p>
                  <p className="font-mono text-[#111111]">+91-9846678656</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-[#173F35] shrink-0" />
                <div>
                  <p className="font-semibold text-[#111111]">Email Correspondence</p>
                  <p className="font-mono">concierge@thecarclub.example</p>
                </div>
              </div>

              <div className="flex items-start gap-3 pt-2 border-t border-[#E5E5E5]">
                <Clock className="h-4 w-4 text-[#173F35] shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-[#111111]">Consultation Hours</p>
                  <p>Monday – Friday: 09:00 – 18:00</p>
                  <p>Saturday: By Appointment Only</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Contact / Enquiry Form */}
        <div className="lg:col-span-2">
          <Card className="border border-[#E5E5E5]">
            <CardHeader className="border-b border-[#E5E5E5] pb-4">
              <CardTitle className="text-lg text-[#111111]">Private Concierge Inquiry</CardTitle>
              <CardDescription className="text-xs">
                Inquiries are delivered directly to dealership management under secure privacy protocols.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              {submittedMessage ? (
                <div className="p-8 rounded-xl bg-emerald-50 border border-emerald-200 text-center space-y-3 animate-in fade-in">
                  <div className="h-12 w-12 rounded-full bg-emerald-100 flex items-center justify-center mx-auto text-emerald-800">
                    <CheckCircle2 className="h-7 w-7" />
                  </div>
                  <h4 className="font-heading text-base font-bold text-emerald-950">
                    Inquiry Received
                  </h4>
                  <p className="text-xs text-emerald-800 max-w-md mx-auto leading-relaxed">
                    {submittedMessage}
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSubmittedMessage(null);
                      setFormData({ name: '', email: '', phone: '', message: '' });
                    }}
                    className="text-xs mt-3"
                  >
                    Send Another Message
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Mode Selector: General Inquiry vs Callback */}
                  <div className="space-y-1.5">
                    <Label className="text-xs font-semibold text-[#111111]">
                      Inquiry Intent
                    </Label>
                    <div className="flex gap-2 max-w-xs">
                      <button
                        type="button"
                        onClick={() => setEnquiryType('GENERAL')}
                        className={`flex-1 py-1.5 px-3 rounded-md text-xs font-medium border transition-colors ${
                          enquiryType === 'GENERAL'
                            ? 'bg-[#111111] text-white border-[#111111]'
                            : 'bg-white text-[#6B6B6B] border-[#E5E5E5] hover:bg-[#F7F7F5]'
                        }`}
                      >
                        General Consultation
                      </button>
                      <button
                        type="button"
                        onClick={() => setEnquiryType('CALLBACK')}
                        className={`flex-1 py-1.5 px-3 rounded-md text-xs font-medium border transition-colors ${
                          enquiryType === 'CALLBACK'
                            ? 'bg-[#111111] text-white border-[#111111]'
                            : 'bg-white text-[#6B6B6B] border-[#E5E5E5] hover:bg-[#F7F7F5]'
                        }`}
                      >
                        Request Callback
                      </button>
                    </div>
                  </div>

                  {submitError && (
                    <div className="p-3 rounded bg-red-50 border border-red-200 text-xs text-red-800 flex items-start gap-2">
                      <AlertCircle className="h-4 w-4 text-red-600 shrink-0 mt-0.5" />
                      <span>{submitError}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label htmlFor="contact-name" className="text-xs font-semibold text-[#111111]">
                        Full Name <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="contact-name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. Vikramaditya Singhania"
                        className={`text-xs ${validationErrors.customer_name ? 'border-red-500' : ''}`}
                      />
                      {validationErrors.customer_name && (
                        <p className="text-[11px] text-red-600">{validationErrors.customer_name}</p>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <Label htmlFor="contact-email" className="text-xs font-semibold text-[#111111]">
                        Email Address <span className="text-[#6B6B6B] font-normal">(Optional)</span>
                      </Label>
                      <Input
                        id="contact-email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="v.singhania@example.com"
                        className={`text-xs ${validationErrors.email ? 'border-red-500' : ''}`}
                      />
                      {validationErrors.email && (
                        <p className="text-[11px] text-red-600">{validationErrors.email}</p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <Label htmlFor="contact-phone" className="text-xs font-semibold text-[#111111]">
                      Contact Phone <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="contact-phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+91 98765 43210"
                      className={`text-xs ${validationErrors.phone ? 'border-red-500' : ''}`}
                    />
                    {validationErrors.phone && (
                      <p className="text-[11px] text-red-600">{validationErrors.phone}</p>
                    )}
                  </div>

                  <div className="space-y-1.5">
                    <Label htmlFor="contact-message" className="text-xs font-semibold text-[#111111]">
                      Consultation Request / Vehicle Requirements
                    </Label>
                    <textarea
                      id="contact-message"
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Detail your automotive inquiries, sourcing requirements, or scheduling preferences..."
                      className={`w-full rounded-md border border-[#E5E5E5] bg-white p-3 text-xs text-[#111111] focus:outline-none focus:ring-1 focus:ring-[#173F35] ${
                        validationErrors.message ? 'border-red-500' : ''
                      }`}
                    />
                    {validationErrors.message && (
                      <p className="text-[11px] text-red-600">{validationErrors.message}</p>
                    )}
                  </div>

                  <div className="pt-2">
                    <Button
                      type="submit"
                      variant="accent"
                      disabled={isSubmitting}
                      className="gap-2 text-xs h-10 shadow-sm"
                    >
                      <Send className="h-3.5 w-3.5" />
                      <span>{isSubmitting ? 'Transmitting...' : 'Submit Concierge Inquiry'}</span>
                    </Button>
                  </div>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
