import React from 'react';
import { Menu, ExternalLink, User, LogOut, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/lib/auth';

interface AdminHeaderProps {
  title: string;
  onToggleSidebar: () => void;
  onNavigate: (path: string) => void;
}

export const AdminHeader: React.FC<AdminHeaderProps> = ({
  title,
  onToggleSidebar,
  onNavigate,
}) => {
  const { profile, user, signOut, isDevBypassActive } = useAuth();

  const displayName = profile?.full_name || user?.email?.split('@')[0] || 'Administrator';

  const handleSignOut = async () => {
    await signOut();
    onNavigate('/admin/login');
  };

  return (
    <header className="sticky top-0 z-30 flex h-20 w-full items-center justify-between border-b border-[#E5E5E5] bg-white px-4 sm:px-6 lg:px-8">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onToggleSidebar}
          className="rounded-md p-2 text-[#111111] hover:bg-[#F0F0EE] md:hidden focus:outline-none focus:ring-2 focus:ring-[#173F35]"
          aria-label="Open sidebar"
        >
          <Menu className="h-5 w-5" />
        </button>
        <div>
          <h1 className="font-heading text-lg font-bold text-[#111111] sm:text-xl">
            {title}
          </h1>
        </div>
      </div>

      <div className="flex items-center space-x-3">
        {isDevBypassActive && (
          <span className="hidden lg:inline-flex items-center gap-1 rounded bg-amber-50 px-2 py-0.5 text-[10px] font-medium text-amber-800 border border-amber-200">
            Dev Preview Mode
          </span>
        )}

        <Button
          variant="outline"
          size="sm"
          onClick={() => onNavigate('/')}
          className="hidden sm:inline-flex text-xs items-center gap-1.5"
        >
          <span>View Public Site</span>
          <ExternalLink className="h-3 w-3 text-[#6B6B6B]" />
        </Button>

        <div className="flex items-center gap-2 border-l border-[#E5E5E5] pl-3">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#111111] text-white">
              <User className="h-4 w-4" />
            </div>
            <div className="hidden md:flex flex-col text-left">
              <span className="text-xs font-semibold text-[#111111] leading-tight">
                {displayName}
              </span>
              <div className="flex items-center gap-1 mt-0.5">
                <ShieldCheck className="h-3 w-3 text-[#173F35]" />
                <span className="text-[10px] uppercase font-bold tracking-wider text-[#173F35]">
                  ADMIN
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={handleSignOut}
            title="Sign out of admin console"
            className="flex items-center gap-1 ml-2 rounded-md p-2 text-xs text-[#6B6B6B] hover:bg-[#F0F0EE] hover:text-red-700 transition-colors focus:outline-none"
            aria-label="Sign out"
          >
            <LogOut className="h-4 w-4" />
            <span className="hidden sm:inline text-xs font-medium">Sign Out</span>
          </button>
        </div>
      </div>
    </header>
  );
};
