import React, { useEffect } from 'react';
import { useAuth } from '@/lib/auth';
import { ShieldAlert, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface AdminProtectedRouteProps {
  children: React.ReactNode;
  currentPath: string;
  onNavigate: (path: string) => void;
}

export const AdminProtectedRoute: React.FC<AdminProtectedRouteProps> = ({
  children,
  currentPath,
  onNavigate,
}) => {
  const { isAdmin, isLoading, isConfigured, isDevBypassActive } = useAuth();

  useEffect(() => {
    if (!isLoading && !isAdmin) {
      const redirectUrl = `/admin/login?redirect=${encodeURIComponent(currentPath)}`;
      onNavigate(redirectUrl);
    }
  }, [isAdmin, isLoading, currentPath, onNavigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#F7F7F5] px-4">
        <div className="w-full max-w-sm rounded-xl border border-[#E5E5E5] bg-white p-8 text-center shadow-sm space-y-4">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[#111111] text-white">
            <Loader2 className="h-6 w-6 animate-spin text-white" />
          </div>
          <div>
            <h3 className="font-heading text-base font-bold text-[#111111]">
              Verifying Authorization
            </h3>
            <p className="text-xs text-[#6B6B6B] mt-1">
              Checking database credentials for administrator clearance...
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#F7F7F5] px-4">
        <div className="w-full max-w-md rounded-xl border border-[#E5E5E5] bg-white p-8 text-center shadow-sm space-y-4">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-red-50 text-red-700">
            <ShieldAlert className="h-6 w-6" />
          </div>
          <div>
            <h3 className="font-heading text-lg font-bold text-[#111111]">
              Administrative Access Required
            </h3>
            <p className="text-xs text-[#6B6B6B] mt-1.5 leading-relaxed">
              This terminal is strictly restricted to verified staff administrators. Please sign in with an authorized dealership account.
            </p>
          </div>
          <div className="pt-2 flex flex-col gap-2">
            <Button
              variant="default"
              onClick={() => onNavigate(`/admin/login?redirect=${encodeURIComponent(currentPath)}`)}
              className="w-full text-xs"
            >
              Sign In to Admin Portal
            </Button>
            <Button
              variant="outline"
              onClick={() => onNavigate('/')}
              className="w-full text-xs"
            >
              Return to Public Showroom
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};
