import React from 'react';
import {
  LayoutDashboard,
  CarFront,
  Inbox,
  Settings,
  ArrowLeft,
  ShieldCheck,
  LogOut,
  User,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/lib/auth';

interface AdminSidebarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  isOpen?: boolean;
  onClose?: () => void;
}

export const AdminSidebar: React.FC<AdminSidebarProps> = ({
  currentPath,
  onNavigate,
  isOpen = false,
  onClose,
}) => {
  const { profile, user, signOut } = useAuth();
  const displayName = profile?.full_name || user?.email?.split('@')[0] || 'Administrator';

  const navItems = [
    {
      label: 'Dashboard',
      path: '/admin',
      icon: LayoutDashboard,
      exact: true,
    },
    {
      label: 'Vehicles',
      path: '/admin/vehicles',
      icon: CarFront,
      exact: false,
    },
    {
      label: 'Enquiries',
      path: '/admin/enquiries',
      icon: Inbox,
      exact: false,
    },
    {
      label: 'Settings',
      path: '/admin/settings',
      icon: Settings,
      exact: false,
    },
  ];

  const handleSignOut = async () => {
    if (onClose) onClose();
    await signOut();
    onNavigate('/admin/login');
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/40 md:hidden backdrop-blur-xs"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 border-r border-[#E5E5E5] bg-[#FFFFFF] transition-transform duration-200 ease-in-out md:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } flex flex-col`}
        aria-label="Admin Sidebar"
      >
        {/* Brand Banner */}
        <div className="flex h-20 items-center justify-between border-b border-[#E5E5E5] px-6">
          <div className="flex flex-col">
            <span className="font-heading text-sm font-extrabold tracking-widest text-[#111111] uppercase">
              THE CAR CLUB
            </span>
            <div className="flex items-center gap-1.5 mt-0.5">
              <ShieldCheck className="h-3 w-3 text-[#173F35]" />
              <span className="text-[10px] uppercase tracking-wider text-[#6B6B6B] font-medium">
                Admin Console
              </span>
            </div>
          </div>
          <Badge variant="accent" className="text-[10px] px-1.5 py-0">
            V1
          </Badge>
        </div>

        {/* Navigation list */}
        <nav className="flex-1 space-y-1.5 px-3 py-6" aria-label="Admin Navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = item.exact
              ? currentPath === item.path
              : currentPath === item.path || currentPath.startsWith(`${item.path}/`);

            return (
              <button
                key={item.path}
                onClick={() => {
                  onNavigate(item.path);
                  if (onClose) onClose();
                }}
                className={`flex w-full items-center rounded-lg px-3.5 py-2.5 text-sm font-medium transition-colors cursor-pointer text-left ${
                  isActive
                    ? 'bg-[#111111] text-white'
                    : 'text-[#6B6B6B] hover:bg-[#F7F7F5] hover:text-[#111111]'
                }`}
              >
                <Icon
                  className={`mr-3 h-4 w-4 shrink-0 ${
                    isActive ? 'text-white' : 'text-[#6B6B6B]'
                  }`}
                />
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Authenticated Staff Card & Actions */}
        <div className="border-t border-[#E5E5E5] p-3 space-y-2">
          <div className="flex items-center justify-between rounded-lg bg-[#F7F7F5] p-2.5">
            <div className="flex items-center gap-2 overflow-hidden">
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#111111] text-white">
                <User className="h-3.5 w-3.5" />
              </div>
              <div className="flex flex-col truncate">
                <span className="text-xs font-semibold text-[#111111] truncate">
                  {displayName}
                </span>
                <span className="text-[10px] text-[#173F35] font-mono font-medium">
                  ROLE: ADMIN
                </span>
              </div>
            </div>
            <button
              onClick={handleSignOut}
              title="Sign Out"
              className="p-1.5 text-[#6B6B6B] hover:text-red-700 transition-colors rounded hover:bg-white"
            >
              <LogOut className="h-3.5 w-3.5" />
            </button>
          </div>

          <button
            onClick={() => {
              onNavigate('/');
              if (onClose) onClose();
            }}
            className="flex w-full items-center justify-center rounded-lg border border-[#E5E5E5] bg-white px-3 py-2 text-xs font-medium text-[#111111] hover:bg-[#F7F7F5] transition-colors"
          >
            <ArrowLeft className="mr-2 h-3.5 w-3.5" />
            Back to Public Showroom
          </button>
        </div>
      </aside>
    </>
  );
};
