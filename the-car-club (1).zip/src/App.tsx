import React, { useState, useEffect } from 'react';
import { PublicLayout } from '@/components/public/public-layout';
import { AdminLayout } from '@/components/admin/admin-layout';
import { AdminProtectedRoute } from '@/components/admin/admin-protected-route';
import { AuthProvider } from '@/lib/auth';
import { HomeRoute } from '@/components/routes/HomeRoute';
import { CarsRoute } from '@/components/routes/CarsRoute';
import { CarDetailRoute } from '@/components/routes/CarDetailRoute';
import { AboutRoute } from '@/components/routes/AboutRoute';
import { ContactRoute } from '@/components/routes/ContactRoute';
import { AdminLoginRoute } from '@/components/routes/admin/AdminLoginRoute';
import { AdminDashboardRoute } from '@/components/routes/admin/AdminDashboardRoute';
import { AdminVehiclesRoute } from '@/components/routes/admin/AdminVehiclesRoute';
import { AdminNewVehicleRoute } from '@/components/routes/admin/AdminNewVehicleRoute';
import { AdminVehicleDetailRoute } from '@/components/routes/admin/AdminVehicleDetailRoute';
import { AdminEnquiriesRoute } from '@/components/routes/admin/AdminEnquiriesRoute';
import { AdminEnquiryDetailRoute } from '@/components/routes/admin/AdminEnquiryDetailRoute';
import { AdminSettingsRoute } from '@/components/routes/admin/AdminSettingsRoute';
import { NotFoundRoute } from '@/components/routes/NotFoundRoute';
import { ErrorState } from '@/components/routes/ErrorState';
import { Compass, CheckCircle2, ChevronRight, Layers, ShieldCheck } from 'lucide-react';

function AppRouter() {
  const [currentPath, setCurrentPath] = useState<string>('/');
  const [hasError, setHasError] = useState<boolean>(false);
  const [showRouteDrawer, setShowRouteDrawer] = useState<boolean>(false);

  // Synchronize with browser URL and history
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const path = (window.location.pathname || '/') + (window.location.search || '');
      setCurrentPath(path);

      const handlePopState = () => {
        setCurrentPath((window.location.pathname || '/') + (window.location.search || ''));
      };

      window.addEventListener('popstate', handlePopState);
      return () => window.removeEventListener('popstate', handlePopState);
    }
  }, []);

  const navigate = (path: string) => {
    setHasError(false);
    setCurrentPath(path);
    if (typeof window !== 'undefined') {
      window.history.pushState({}, '', path);
      window.scrollTo(0, 0);
    }
  };

  if (hasError) {
    return <ErrorState onRetry={() => setHasError(false)} />;
  }

  // Parse base pathname without search parameters for route matching
  const basePath = currentPath.split('?')[0] || '/';

  // Route Dispatcher
  const renderRoute = () => {
    // 1. Home
    if (basePath === '/' || basePath === '') {
      return (
        <PublicLayout currentPath={currentPath} onNavigate={navigate}>
          <HomeRoute onNavigate={navigate} />
        </PublicLayout>
      );
    }

    // 2. Cars Inventory
    if (basePath === '/cars') {
      return (
        <PublicLayout currentPath={currentPath} onNavigate={navigate}>
          <CarsRoute onNavigate={navigate} />
        </PublicLayout>
      );
    }

    // 3. Cars Dynamic [slug]
    if (basePath.startsWith('/cars/')) {
      const slug = basePath.replace('/cars/', '');
      return (
        <PublicLayout currentPath={currentPath} onNavigate={navigate}>
          <CarDetailRoute slug={slug} onNavigate={navigate} />
        </PublicLayout>
      );
    }

    // 4. About
    if (basePath === '/about') {
      return (
        <PublicLayout currentPath={currentPath} onNavigate={navigate}>
          <AboutRoute onNavigate={navigate} />
        </PublicLayout>
      );
    }

    // 5. Contact
    if (basePath === '/contact') {
      return (
        <PublicLayout currentPath={currentPath} onNavigate={navigate}>
          <ContactRoute onNavigate={navigate} />
        </PublicLayout>
      );
    }

    // 6. Admin Login (Public entry point to admin area)
    if (basePath === '/admin/login') {
      return <AdminLoginRoute onNavigate={navigate} />;
    }

    // 7. Admin Dashboard (Protected)
    if (basePath === '/admin') {
      return (
        <AdminProtectedRoute currentPath={currentPath} onNavigate={navigate}>
          <AdminLayout
            title="Operations Dashboard"
            currentPath={currentPath}
            onNavigate={navigate}
          >
            <AdminDashboardRoute onNavigate={navigate} />
          </AdminLayout>
        </AdminProtectedRoute>
      );
    }

    // 8. Admin New Vehicle (Protected)
    if (basePath === '/admin/vehicles/new') {
      return (
        <AdminProtectedRoute currentPath={currentPath} onNavigate={navigate}>
          <AdminLayout
            title="New Vehicle Intake"
            currentPath={currentPath}
            onNavigate={navigate}
          >
            <AdminNewVehicleRoute onNavigate={navigate} />
          </AdminLayout>
        </AdminProtectedRoute>
      );
    }

    // 9. Admin Vehicles Master List (Protected)
    if (basePath === '/admin/vehicles' || basePath === '/admin/vehicles/') {
      return (
        <AdminProtectedRoute currentPath={currentPath} onNavigate={navigate}>
          <AdminLayout
            title="Vehicle Inventory"
            currentPath={currentPath}
            onNavigate={navigate}
          >
            <AdminVehiclesRoute onNavigate={navigate} />
          </AdminLayout>
        </AdminProtectedRoute>
      );
    }

    // 10. Admin Vehicle Detail [id] (Protected)
    if (basePath.startsWith('/admin/vehicles/')) {
      const id = basePath.replace('/admin/vehicles/', '').trim();
      if (id) {
        return (
          <AdminProtectedRoute currentPath={currentPath} onNavigate={navigate}>
            <AdminLayout
              title="Vehicle Record"
              currentPath={currentPath}
              onNavigate={navigate}
            >
              <AdminVehicleDetailRoute id={id} onNavigate={navigate} />
            </AdminLayout>
          </AdminProtectedRoute>
        );
      }
    }

    // 11. Admin Enquiries Master List (Protected)
    if (basePath === '/admin/enquiries' || basePath === '/admin/enquiries/') {
      return (
        <AdminProtectedRoute currentPath={currentPath} onNavigate={navigate}>
          <AdminLayout
            title="Customer Enquiries"
            currentPath={currentPath}
            onNavigate={navigate}
          >
            <AdminEnquiriesRoute onNavigate={navigate} />
          </AdminLayout>
        </AdminProtectedRoute>
      );
    }

    // 12. Admin Enquiry Detail [id] (Protected)
    if (basePath.startsWith('/admin/enquiries/')) {
      const id = basePath.replace('/admin/enquiries/', '').trim();
      if (id) {
        return (
          <AdminProtectedRoute currentPath={currentPath} onNavigate={navigate}>
            <AdminLayout
              title="Client Enquiry Review"
              currentPath={currentPath}
              onNavigate={navigate}
            >
              <AdminEnquiryDetailRoute id={id} onNavigate={navigate} />
            </AdminLayout>
          </AdminProtectedRoute>
        );
      }
    }

    // 13. Admin Settings (Protected)
    if (basePath === '/admin/settings') {
      return (
        <AdminProtectedRoute currentPath={currentPath} onNavigate={navigate}>
          <AdminLayout
            title="Dealership Settings"
            currentPath={currentPath}
            onNavigate={navigate}
          >
            <AdminSettingsRoute onNavigate={navigate} />
          </AdminLayout>
        </AdminProtectedRoute>
      );
    }

    // 14. 404 Not Found fallback
    return (
      <PublicLayout currentPath={currentPath} onNavigate={navigate}>
        <NotFoundRoute currentPath={currentPath} onNavigate={navigate} />
      </PublicLayout>
    );
  };

  const allDefinedRoutes = [
    { label: 'Public Home', path: '/' },
    { label: 'Public Inventory', path: '/cars' },
    { label: 'Public Car [slug]', path: '/cars/porsche-911-gt3-touring-992-2023' },
    { label: 'Public About', path: '/about' },
    { label: 'Public Contact', path: '/contact' },
    { label: 'Admin Login', path: '/admin/login' },
    { label: 'Admin Dashboard (Auth)', path: '/admin' },
    { label: 'Admin Vehicles (Auth)', path: '/admin/vehicles' },
    { label: 'Admin New Vehicle (Auth)', path: '/admin/vehicles/new' },
    { label: 'Admin Vehicle [id] (Auth)', path: '/admin/vehicles/e48a1d70-388d-4f11-8be9-0efb9423c911' },
    { label: 'Admin Enquiries (Auth)', path: '/admin/enquiries' },
    { label: 'Admin Enquiry [id] (Auth)', path: '/admin/enquiries/enq-911-001' },
    { label: 'Admin Settings (Auth)', path: '/admin/settings' },
  ];

  return (
    <div className="relative min-h-screen">
      {renderRoute()}

      {/* Development Quick Navigation Bar */}
      <div className="fixed bottom-3 right-3 z-50">
        {showRouteDrawer ? (
          <div className="w-80 rounded-lg border border-[#E5E5E5] bg-white p-4 shadow-xl text-[#111111] animate-in fade-in slide-in-from-bottom-2">
            <div className="flex items-center justify-between border-b border-[#E5E5E5] pb-2 mb-3">
              <div className="flex items-center gap-1.5">
                <Compass className="h-4 w-4 text-[#173F35]" />
                <span className="font-heading text-xs font-bold uppercase tracking-wider">
                  Route Navigator
                </span>
              </div>
              <button
                onClick={() => setShowRouteDrawer(false)}
                className="text-xs text-[#6B6B6B] hover:text-[#111111] p-1 cursor-pointer"
                aria-label="Close route drawer"
              >
                Close ✕
              </button>
            </div>

            <p className="text-[11px] text-[#6B6B6B] mb-2">
              All checkpoint routes are active with V1 Production baseline:
            </p>

            <div className="max-h-64 overflow-y-auto space-y-1 pr-1 text-xs">
              {allDefinedRoutes.map((r) => {
                const isActive = basePath === r.path.split('?')[0];
                return (
                  <button
                    key={r.path}
                    onClick={() => {
                      navigate(r.path);
                      setShowRouteDrawer(false);
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-left transition-colors cursor-pointer ${
                      isActive
                        ? 'bg-[#111111] text-white font-medium'
                        : 'hover:bg-[#F0F0EE] text-[#6B6B6B] hover:text-[#111111]'
                    }`}
                  >
                    <span className="truncate">{r.label}</span>
                    <span className="font-mono text-[10px] opacity-75 shrink-0 ml-2">
                      {r.path}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="mt-3 pt-2 border-t border-[#E5E5E5] flex items-center justify-between text-[10px] text-[#6B6B6B]">
              <span className="font-mono truncate max-w-[140px]">Active: {currentPath}</span>
              <span className="flex items-center gap-1 text-[#173F35] font-medium">
                <ShieldCheck className="h-3 w-3" />
                Phase 17 Verified
              </span>
            </div>
          </div>
        ) : (
          <button
            onClick={() => setShowRouteDrawer(true)}
            className="flex items-center gap-2 rounded-full border border-[#E5E5E5] bg-white px-3.5 py-2 text-xs font-medium text-[#111111] shadow-md hover:bg-[#F7F7F5] transition-all cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#173F35]"
            title="Inspect checkpoint routes"
          >
            <Layers className="h-3.5 w-3.5 text-[#173F35]" />
            <span className="hidden sm:inline">Routes ({allDefinedRoutes.length})</span>
            <ChevronRight className="h-3 w-3 text-[#6B6B6B]" />
          </button>
        )}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppRouter />
    </AuthProvider>
  );
}
