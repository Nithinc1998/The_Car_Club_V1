# THE CAR CLUB — TECHNICAL SPECIFICATION & BLUEPRINT

**Document Version:** 1.0.0  
**Project Status:** Milestone 1 — Project & Foundation Initialization  
**Target Environment:** Next.js / TypeScript / App Router Architecture adapted for AI Studio Container Runtime

---

## 1. PRODUCT OVERVIEW

**The Car Club** is a modern, minimal, premium automotive platform designed for curated vehicle presentation, inventory showcase, and customer enquiry management.

### Brand Direction & Personality
* **Aesthetic:** Modern, Minimal, Premium, Automotive, Trustworthy
* **Tone:** Objective, refined, understated luxury without sensationalism or exaggerated sales claims
* **Core Value Proposition:** Providing buyers and collectors with crystal-clear vehicle specifications, authentic imagery, transparent vehicle history, and a seamless channel for private enquiries and consultations.

---

## 2. V1 SCOPE

The V1 release focuses on the core public vehicle presentation platform and essential dealership management back-office:

1. **Public Vehicle Catalog:**
   * Curated inventory list with search, filter (make, model, year, body style, price, status), and sorting
   * High-resolution vehicle detail pages with multi-angle gallery, vehicle specifications, mileage, history highlights, and ownership provenance
   * Direct, frictionless private enquiry submission form for specific vehicles

2. **Public Informational Pages:**
   * Brand overview and philosophy (`/about`)
   * Dealership contact details, viewing hours, concierge location, and inquiry form (`/contact`)

3. **Dealership Administration (Admin Shell & Workflow):**
   * Authenticated admin portal (`/admin`)
   * Vehicle inventory management overview (`/admin/vehicles`)
   * New vehicle intake and specification drafting (`/admin/vehicles/new`)
   * Vehicle record management and status toggling (`/admin/vehicles/[id]`)
   * Inbound customer enquiries list with unread/contacted statuses (`/admin/enquiries`)
   * Enquiry details view with message trail and customer contact data (`/admin/enquiries/[id]`)
   * Platform dealership settings, operating hours, and contact email (`/admin/settings`)

---

## 3. V1 EXCLUSIONS (STRICTLY OUT OF SCOPE)

The following capabilities are explicitly deferred to future release milestones:
* Online vehicle purchasing, escrow, checkout, or deposit payment processing
* Integrated automotive financing calculators or third-party lender credit applications
* Trade-in estimation calculators or real-time vehicle valuation APIs
* Customer account registration (buyers enquire as guests without forced account creation)
* Live test drive booking engines with calendar synchronization
* Automated auction bidding or price negotiation engines
* Multi-branch inventory transfers or multi-tenant dealer groups
* Automated accounting, invoice generation, or DMV registration paperwork workflows

---

## 4. APPROVED TECHNOLOGY STACK

* **Framework:** Next.js (App Router convention, with client-side adaptive runtime compatibility)
* **Language:** TypeScript 5+ (Strict Mode enabled, no `any`)
* **Styling:** Tailwind CSS v4 with unified design system variables
* **Component Primitives:** shadcn/ui architectural patterns with accessible primitives
* **Database & Auth:** Supabase (PostgreSQL with Row Level Security, Auth, and Storage)
* **Schema & Form Validation:** Zod
* **Iconography:** Lucide Icons (`lucide-react`)
* **Package Manager:** npm

---

## 5. COMPLETE ROUTE HIERARCHY

### Public Routes
* `/` — Landing page with featured acquisitions, curated selection, brand philosophy
* `/cars` — Comprehensive inventory catalog with filters and vehicle search
* `/cars/[slug]` — Individual vehicle profile, specifications, gallery, and enquiry modal/form
* `/about` — The Car Club heritage, standards, curation process, and team
* `/contact` — Showroom location, private consultation appointments, general inquiries

### Admin Routes (Protected)
* `/admin/login` — Administrative authentication entry point
* `/admin` — Operational executive dashboard (inventory health, enquiry queue)
* `/admin/vehicles` — Vehicle inventory master list with status filters (Draft, Available, Reserved, Sold)
* `/admin/vehicles/new` — Vehicle intake form with Zod validation
* `/admin/vehicles/[id]` — Vehicle record inspection, editing, and status updates
* `/admin/enquiries` — Inbound prospective buyer communications queue
* `/admin/enquiries/[id]` — Detailed enquiry review, vehicle reference, and contact log
* `/admin/settings` — Dealership operational configurations and administrative preferences

---

## 6. CORE ENTITIES & DATA MODEL

### 1. `vehicles`
* `id` (UUID, Primary Key)
* `slug` (TEXT, Unique, URL-friendly slug)
* `make` (TEXT, e.g. "Porsche")
* `model` (TEXT, e.g. "911 Carrera S")
* `year` (INTEGER, e.g. 2023)
* `price` (NUMERIC, formatted currency)
* `mileage` (INTEGER, recorded distance in miles/km)
* `transmission` (TEXT, e.g. "Manual" | "PDK" | "Automatic")
* `fuel_type` (TEXT, e.g. "Petrol" | "Hybrid" | "Electric")
* `exterior_color` (TEXT)
* `interior_color` (TEXT)
* `vin` (TEXT, nullable / admin visible)
* `description` (TEXT)
* `features` (TEXT[], array of feature tags)
* `images` (TEXT[], Supabase storage URLs)
* `status` (TEXT: `'draft'` | `'available'` | `'reserved'` | `'sold'`)
* `featured` (BOOLEAN, default false)
* `created_at` (TIMESTAMPTZ)
* `updated_at` (TIMESTAMPTZ)

### 2. `enquiries`
* `id` (UUID, Primary Key)
* `vehicle_id` (UUID, Foreign Key to `vehicles.id`, nullable for general enquiries)
* `name` (TEXT, customer full name)
* `email` (TEXT, customer email)
* `phone` (TEXT, customer phone number)
* `message` (TEXT, enquiry message text)
* `status` (TEXT: `'unread'` | `'contacted'` | `'closed'`)
* `notes` (TEXT, admin notes)
* `created_at` (TIMESTAMPTZ)

### 3. `settings`
* `id` (UUID, Primary Key)
* `dealership_name` (TEXT)
* `contact_email` (TEXT)
* `contact_phone` (TEXT)
* `address` (TEXT)
* `opening_hours` (TEXT)

---

## 7. SECURITY & ACCESS CONTROL REQUIREMENTS

1. **Row Level Security (RLS):**
   * Public users have `SELECT` access only to vehicles where `status = 'available'` or `status = 'reserved'` or `status = 'sold'`.
   * Public users have `INSERT` permission for `enquiries` with strict input sanitization.
   * Admin roles (`authenticated` users with confirmed staff role) have full CRUD permissions on `vehicles`, `enquiries`, and `settings`.
2. **Environment Protection:**
   * Client-side code accesses Supabase via `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`.
   * Supabase Service Role Key is strictly server-only and NEVER bundled in client-side code.
   * `.env.local` is git-ignored and never committed.
3. **Data Sanitization:**
   * All user submissions are validated using strict Zod schemas before transmission to prevent injection or payload tampering.

---

## 8. DESIGN SYSTEM SPECIFICATIONS

* **Primary:** `#111111` (Deep Obsidian Black)
* **Background:** `#F7F7F5` (Refined Gallery Off-White)
* **White / Card Surface:** `#FFFFFF`
* **Secondary Text:** `#6B6B6B` (Muted Neutral Gray)
* **Border:** `#E5E5E5` (Subtle 1px Neutral Divider)
* **Accent:** `#173F35` (Heritage British Racing / Deep Forest Green)

### Typography
* **Headings:** `Manrope` (Weights: 600, 700, 800)
* **Body & UI:** `Inter` (Weights: 400, 500, 600)

### UI Radii & Elevation
* **Corner Radius:** Moderate (8px / `rounded-lg`)
* **Shadows:** Subtle low-elevation shadows (`shadow-sm`, `shadow`)
* **Banned Aesthetics:** Arbitrary neon gradients, glowing borders, high-saturation cards, heavy drop shadows, unsolicited hero eyebrow badges, marketing exaggerations.

---

## 9. CODE QUALITY & ARCHITECTURAL RULES

* Strict TypeScript: Zero `any`, complete interface definitions for all route params, states, and components.
* Modular architecture: Individual components under 150-200 lines, cleanly isolated in functional folders.
* Accessibility: Semantic HTML (`<header>`, `<main>`, `<footer>`, `<nav>`, `<section>`, `<aside>`), explicit labels, focus rings, keyboard navigability.
* Responsive Design: Mobile-first layout testing seamlessly across 360px mobile, 768px tablet, 1024px desktop, and 1440px wide monitors.

---

## 10. IMPLEMENTATION SEQUENCE CHECKPOINTS

* **Checkpoint 1 (Current):** Technical Foundation, Structure Setup, Design System, Route Placeholders, Types, Validations, and Supabase Client Configuration.
* **Checkpoint 2:** Supabase Database Schema, Migrations, RLS Policies, and Seed Scripts.
* **Checkpoint 3:** Public Vehicle Catalog, Filter Engine, and Vehicle Detail Page with Image Viewer.
* **Checkpoint 4:** Customer Enquiry Pipeline & Form Validation.
* **Checkpoint 5:** Admin Authentication, Protected Route Shells, and Session Handling.
* **Checkpoint 6:** Admin Vehicle Management (Create, Update, Status Controls, Storage Uploads).
* **Checkpoint 7:** Admin Enquiry Triage System & Operational Settings.
* **Checkpoint 8:** Production Polish, Performance Audit, and End-to-End Verification.
