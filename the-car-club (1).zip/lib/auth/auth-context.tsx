import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { getSupabaseBrowserClient, isSupabaseConfigured } from '@/lib/supabase/client';
import { Database } from '@/types/database';

export type AdminProfile = Database['public']['Tables']['profiles']['Row'];

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: AdminProfile | null;
  isAdmin: boolean;
  isLoading: boolean;
  isConfigured: boolean;
  error: string | null;
  signIn: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signOut: () => Promise<void>;
  setupFirstAdmin: (
    fullName: string,
    email: string,
    password: string
  ) => Promise<{ success: boolean; error?: string }>;
  resendConfirmationEmail: (email: string) => Promise<{ success: boolean; error?: string }>;
  clearError: () => void;
  // Development preview simulation helper when remote credentials are not configured
  isDevBypassActive: boolean;
  enableDevBypass: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<AdminProfile | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isConfigured, setIsConfigured] = useState<boolean>(false);
  const [isDevBypassActive, setIsDevBypassActive] = useState<boolean>(false);

  // Authoritative database-backed profile verification
  const verifyAdminProfile = useCallback(async (userId: string): Promise<AdminProfile | null> => {
    const supabase = getSupabaseBrowserClient();
    if (!supabase) return null;

    try {
      const { data, error: profileErr } = await supabase
        .from('profiles')
        .select('id, full_name, role, created_at, updated_at')
        .eq('id', userId)
        .maybeSingle();

      if (profileErr) {
        if (
          profileErr.code === 'PGRST205' ||
          profileErr.message?.includes('schema cache') ||
          profileErr.message?.includes('does not exist')
        ) {
          console.warn('Database profiles table pending migration:', profileErr.message);
        } else {
          console.warn('Admin profile query notice:', profileErr.message);
        }
        return null;
      }

      // Strictly verify that the profile role is ADMIN
      if (data && data.role === 'ADMIN') {
        return data as AdminProfile;
      }

      return null;
    } catch (err: unknown) {
      console.warn('Profile verification check notice:', err);
      return null;
    }
  }, []);

  // Initialize auth state
  useEffect(() => {
    const configured = isSupabaseConfigured();
    setIsConfigured(configured);

    if (!configured) {
      // In unconfigured environments, check if dev simulation was enabled in this session
      const savedDevMode = typeof sessionStorage !== 'undefined' && sessionStorage.getItem('tcc_dev_admin_active') === 'true';
      if (savedDevMode) {
        setIsDevBypassActive(true);
        setProfile({
          id: 'dev-admin-id',
          full_name: 'Lead Dealership Administrator',
          role: 'ADMIN',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        });
      }
      setIsLoading(false);
      return;
    }

    const supabase = getSupabaseBrowserClient();
    if (!supabase) {
      setIsLoading(false);
      return;
    }

    // Check existing session
    const initAuth = async () => {
      try {
        if (typeof window !== 'undefined') {
          const urlParams = new URLSearchParams(window.location.search);
          const code = urlParams.get('code');
          if (code) {
            const { error: exchangeErr } = await supabase.auth.exchangeCodeForSession(code);
            if (exchangeErr) {
              console.warn('Auth code exchange notice:', exchangeErr.message);
            } else {
              // Clean code from URL without refreshing
              const cleanUrl = window.location.pathname;
              window.history.replaceState({}, document.title, cleanUrl);
            }
          }
        }

        const { data: { session: initialSession }, error: sessionError } = await supabase.auth.getSession();
        if (sessionError) {
          console.error('Error retrieving session:', sessionError.message);
          setIsLoading(false);
          return;
        }

        if (initialSession?.user) {
          let verifiedProfile = await verifyAdminProfile(initialSession.user.id);
          
          // Auto-claim first admin if zero administrators currently exist in the database
          if (!verifiedProfile) {
            type RpcCount = (fn: string) => Promise<{ data: number | null; error: { message: string } | null }>;
            const { data: countData } = await (supabase.rpc as unknown as RpcCount)('count_admin_profiles');
            if (countData === 0) {
              type RpcCaller = (fn: string, params?: Record<string, unknown>) => Promise<{ error: { message: string } | null }>;
              const fullName = initialSession.user.user_metadata?.full_name || initialSession.user.email?.split('@')[0] || 'Primary Administrator';
              await (supabase.rpc as unknown as RpcCaller)('initialize_first_admin', {
                admin_full_name: fullName,
              });
              verifiedProfile = await verifyAdminProfile(initialSession.user.id);
            }
          }

          if (verifiedProfile) {
            setUser(initialSession.user);
            setSession(initialSession);
            setProfile(verifiedProfile);
          } else {
            // User exists in auth but lacks an active ADMIN profile record in the database
            console.warn('Authenticated user lacks active ADMIN profile. Revoking session.');
            await supabase.auth.signOut();
            setUser(null);
            setSession(null);
            setProfile(null);
          }
        }
      } catch (err) {
        console.error('Auth initialization error:', err);
      } finally {
        setIsLoading(false);
      }
    };

    initAuth();

    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, newSession) => {
      if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED' || event === 'USER_UPDATED') {
        if (newSession?.user) {
          let verifiedProfile = await verifyAdminProfile(newSession.user.id);

          // Auto-claim first admin if zero administrators currently exist in the database
          if (!verifiedProfile) {
            type RpcCount = (fn: string) => Promise<{ data: number | null; error: { message: string } | null }>;
            const { data: countData } = await (supabase.rpc as unknown as RpcCount)('count_admin_profiles');
            if (countData === 0) {
              type RpcCaller = (fn: string, params?: Record<string, unknown>) => Promise<{ error: { message: string } | null }>;
              const fullName = newSession.user.user_metadata?.full_name || newSession.user.email?.split('@')[0] || 'Primary Administrator';
              await (supabase.rpc as unknown as RpcCaller)('initialize_first_admin', {
                admin_full_name: fullName,
              });
              verifiedProfile = await verifyAdminProfile(newSession.user.id);
            }
          }

          if (verifiedProfile) {
            setUser(newSession.user);
            setSession(newSession);
            setProfile(verifiedProfile);
            setError(null);
          } else {
            // Unauthorized user without an ADMIN profile record in database
            await supabase.auth.signOut();
            setUser(null);
            setSession(null);
            setProfile(null);
            setError('Access restricted to authorized dealership administrators. Your account has not been provisioned with an administrator profile.');
          }
        }
      } else if (event === 'SIGNED_OUT') {
        setUser(null);
        setSession(null);
        setProfile(null);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [verifyAdminProfile]);

  const signIn = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    setError(null);

    // If Supabase credentials are not configured, handle preview mode
    if (!isConfigured) {
      // Allow dev test login in unconfigured environments
      if (email.toLowerCase().includes('admin') || password.length >= 8) {
        setIsDevBypassActive(true);
        if (typeof sessionStorage !== 'undefined') {
          sessionStorage.setItem('tcc_dev_admin_active', 'true');
        }
        setProfile({
          id: 'dev-admin-id',
          full_name: 'Lead Dealership Administrator',
          role: 'ADMIN',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        });
        return { success: true };
      }
      return { success: false, error: 'Invalid credentials. In unconfigured preview mode, use any email containing "admin" with an 8+ character password.' };
    }

    const supabase = getSupabaseBrowserClient();
    if (!supabase) {
      return { success: false, error: 'Authentication service is unavailable. Please check configuration.' };
    }

    try {
      const { data, error: authError } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (authError) {
        let msg = authError.message;
        if (msg.toLowerCase().includes('invalid login credentials')) {
          msg = 'Invalid administrative credentials. Please verify your email and password.';
        }
        setError(msg);
        return { success: false, error: msg };
      }

      if (!data.user) {
        return { success: false, error: 'Authentication failed. Please try again.' };
      }

      // Authoritative database check on profiles table
      let verifiedProfile = await verifyAdminProfile(data.user.id);

      // Auto-claim first admin if zero administrators currently exist in the database
      if (!verifiedProfile) {
        type RpcCount = (fn: string) => Promise<{ data: number | null; error: { message: string } | null }>;
        const { data: countData } = await (supabase.rpc as unknown as RpcCount)('count_admin_profiles');
        if (countData === 0) {
          type RpcCaller = (fn: string, params?: Record<string, unknown>) => Promise<{ error: { message: string } | null }>;
          const fullName = data.user.user_metadata?.full_name || data.user.email?.split('@')[0] || 'Primary Administrator';
          await (supabase.rpc as unknown as RpcCaller)('initialize_first_admin', {
            admin_full_name: fullName,
          });
          verifiedProfile = await verifyAdminProfile(data.user.id);
        }
      }

      if (!verifiedProfile) {
        // Sign out immediately to preserve security
        await supabase.auth.signOut();
        const forbiddenMsg = 'Access restricted: Your account does not have an active dealership administrator profile in the database.';
        setError(forbiddenMsg);
        return { success: false, error: forbiddenMsg };
      }

      setUser(data.user);
      setSession(data.session);
      setProfile(verifiedProfile);
      return { success: true };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'A network error occurred while contacting the authentication service.';
      setError(msg);
      return { success: false, error: msg };
    }
  };

  const signOut = async (): Promise<void> => {
    if (isDevBypassActive) {
      setIsDevBypassActive(false);
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.removeItem('tcc_dev_admin_active');
      }
      setUser(null);
      setSession(null);
      setProfile(null);
      return;
    }

    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        await supabase.auth.signOut();
      } catch (err) {
        console.error('Error signing out:', err);
      }
    }

    setUser(null);
    setSession(null);
    setProfile(null);
    setError(null);
  };

  const setupFirstAdmin = async (
    fullName: string,
    email: string,
    password: string
  ): Promise<{ success: boolean; error?: string }> => {
    setError(null);

    if (!isConfigured) {
      // In preview unconfigured mode
      setIsDevBypassActive(true);
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.setItem('tcc_dev_admin_active', 'true');
      }
      setProfile({
        id: 'dev-admin-id',
        full_name: fullName.trim() || 'Primary Administrator',
        role: 'ADMIN',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
      return { success: true };
    }

    const supabase = getSupabaseBrowserClient();
    if (!supabase) {
      return { success: false, error: 'Supabase client is not available.' };
    }

    try {
      // 1. Sign up the user with metadata and explicit redirect URL
      const redirectUrl = typeof window !== 'undefined' && window.location.origin
        ? `${window.location.origin}/admin/login`
        : undefined;

      const { data: signUpData, error: signUpErr } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName.trim(),
          },
          emailRedirectTo: redirectUrl,
        },
      });

      if (signUpErr) {
        let msg = signUpErr.message;
        if (msg.toLowerCase().includes('rate limit')) {
          msg = 'Email rate limit exceeded (Supabase free limit: 3-4 emails/hour). If you already submitted this email, go to Supabase Dashboard > Authentication > Users, click "..." > "Confirm email", then log in via Staff Login.';
        } else if (msg.toLowerCase().includes('already registered')) {
          msg = 'This email is already registered. Please switch to the Staff Login tab to sign in.';
        }
        setError(msg);
        return { success: false, error: msg };
      }

      if (!signUpData.user) {
        return { success: false, error: 'Failed to create user account.' };
      }

      // If email confirmation is required by Supabase project settings
      if (signUpData.session) {
        // Call initialize_first_admin RPC to ensure profile is created
        type RpcCaller = (fn: string, params?: Record<string, unknown>) => Promise<{ error: { message: string } | null }>;
        const { error: rpcErr } = await (supabase.rpc as unknown as RpcCaller)('initialize_first_admin', {
          admin_full_name: fullName.trim(),
        });

        if (rpcErr && !rpcErr.message.includes('duplicate')) {
          console.warn('RPC initialize_first_admin notice:', rpcErr.message);
        }

        // Verify profile
        const verifiedProfile = await verifyAdminProfile(signUpData.user.id);
        if (verifiedProfile) {
          setUser(signUpData.user);
          setSession(signUpData.session);
          setProfile(verifiedProfile);
          return { success: true };
        }
      }

      return {
        success: true,
        error: signUpData.session ? undefined : 'Account created. If email confirmation is enabled on your Supabase project, please check your inbox to confirm your email before signing in.',
      };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error executing first-admin setup.';
      setError(msg);
      return { success: false, error: msg };
    }
  };

  const resendConfirmationEmail = async (email: string): Promise<{ success: boolean; error?: string }> => {
    if (!isConfigured) {
      return { success: false, error: 'Supabase credentials are not configured.' };
    }
    const supabase = getSupabaseBrowserClient();
    if (!supabase) {
      return { success: false, error: 'Supabase client is not available.' };
    }
    try {
      const redirectUrl = typeof window !== 'undefined' && window.location.origin
        ? `${window.location.origin}/admin/login`
        : undefined;

      const { error: resendErr } = await supabase.auth.resend({
        type: 'signup',
        email: email.trim(),
        options: {
          emailRedirectTo: redirectUrl,
        },
      });

      if (resendErr) {
        let msg = resendErr.message;
        if (msg.toLowerCase().includes('rate limit')) {
          msg = 'Email rate limit exceeded (Supabase limit: ~3 emails/hour). Instant fix: Go to Supabase Dashboard > Authentication > Users, click "..." next to your email and select "Confirm email". Then log in directly!';
        }
        return { success: false, error: msg };
      }
      return { success: true };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to resend confirmation email.';
      return { success: false, error: msg };
    }
  };

  const enableDevBypass = () => {
    setIsDevBypassActive(true);
    if (typeof sessionStorage !== 'undefined') {
      sessionStorage.setItem('tcc_dev_admin_active', 'true');
    }
    setProfile({
      id: 'dev-admin-id',
      full_name: 'Lead Dealership Administrator',
      role: 'ADMIN',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    });
  };

  const clearError = () => setError(null);

  // Derived authorization: strictly authoritative based on verified profile role = 'ADMIN'
  const isAdmin = Boolean(profile && profile.role === 'ADMIN');

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        profile,
        isAdmin,
        isLoading,
        isConfigured,
        error,
        signIn,
        signOut,
        setupFirstAdmin,
        resendConfirmationEmail,
        clearError,
        isDevBypassActive,
        enableDevBypass,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
