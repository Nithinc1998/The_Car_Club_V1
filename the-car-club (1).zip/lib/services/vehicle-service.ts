import { getSupabaseBrowserClient, isSupabaseConfigured } from '@/lib/supabase/client';
import { Database, Json } from '@/types/database';
import {
  VehicleFormValues,
  validatePublishingIntegrity,
  vehicleSchema,
} from '@/lib/validations/vehicle';

export type Vehicle = Database['public']['Tables']['vehicles']['Row'];
export type VehicleMedia = Database['public']['Tables']['vehicle_media']['Row'];
export type VehicleEvent = Database['public']['Tables']['vehicle_events']['Row'];
export type VehicleStatus = Database['public']['Enums']['vehicle_status'];
export type VehicleEventType = Database['public']['Enums']['vehicle_event_type'];

export interface VehicleWithMedia extends Vehicle {
  media?: (VehicleMedia & { publicUrl?: string })[];
  cover_image_url?: string;
}

export interface VehicleDetailWithEvents extends VehicleWithMedia {
  events?: (VehicleEvent & { author_name?: string })[];
}

// -------------------------------------------------------------
// LOCAL STORAGE STORAGE ADAPTER FOR UNCONFIGURED / DEV PREVIEW
// Keeps admin workflow fully testable and responsive
// -------------------------------------------------------------
const STORAGE_KEY_VEHICLES = 'tcc_admin_inventory_vehicles';
const STORAGE_KEY_MEDIA = 'tcc_admin_inventory_media';
const STORAGE_KEY_EVENTS = 'tcc_admin_inventory_events';

// Initial authentic dealership inventory seed for dev preview
const INITIAL_DEV_VEHICLES: Vehicle[] = [
  {
    id: 'e48a1d70-388d-4f11-8be9-0efb9423c911',
    stock_id: 'TCC-00001',
    registration_number: 'MH 02 EF 9110',
    make: 'Porsche',
    model: '911 GT3 Touring',
    variant: '992 Package',
    slug: 'porsche-911-gt3-touring-992-2023',
    manufacturing_year: 2023,
    registration_year: 2023,
    fuel_type: 'PETROL',
    transmission: 'MANUAL',
    kilometers: 4200,
    owners: 1,
    color: 'GT Silver Metallic',
    asking_price: 27500000,
    purchase_price: 24500000,
    condition: 'EXCELLENT',
    condition_notes: 'Pristine factory condition. Single connoisseur ownership, PPF applied since delivery.',
    service_history: 'FULL',
    service_history_notes: '100% authorized Porsche Centre service records with complete stamp log.',
    inspection_notes: 'Passed 111-point Porsche certification inspection with zero faults.',
    features: [
      'PCCB Ceramic Brakes',
      'Front Axle Lift System',
      'Chrono Package',
      'Full Bucket Carbon Seats',
      'BOSE Surround Sound',
      'Matrix LED Headlights'
    ],
    accessories: [
      'Porsche Tequipment Indoor Car Cover',
      'Battery Maintainer',
      'Dual Key Fobs in Paint Color'
    ],
    short_description: 'Six-speed manual 992 GT3 Touring in classic GT Silver Metallic with carbon buckets.',
    description: 'A benchmark driver specification. Delivered new through Porsche Centre Mumbai, this GT3 Touring pairs the rev-happy 4.0-liter naturally aspirated flat-six with a crisp six-speed GT sports manual gearbox and touring rear spoiler.',
    status: 'AVAILABLE',
    is_published: true,
    created_at: new Date(Date.now() - 15 * 86400000).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'f92b7c12-9110-4321-9988-123456789abc',
    stock_id: 'TCC-00002',
    registration_number: 'DL 01 CA 4400',
    make: 'Mercedes-AMG',
    model: 'G 63',
    variant: 'V8 Biturbo Magno Edition',
    slug: 'mercedes-amg-g63-magno-2022',
    manufacturing_year: 2022,
    registration_year: 2022,
    fuel_type: 'PETROL',
    transmission: 'AUTOMATIC',
    kilometers: 9800,
    owners: 1,
    color: 'Night Black Magno',
    asking_price: 36000000,
    purchase_price: 32000000,
    condition: 'EXCELLENT',
    condition_notes: 'Mint matte paintwork with full satin stealth wrap. Zero accident history.',
    service_history: 'FULL',
    service_history_notes: 'Annual services completed strictly on schedule at Mercedes-Benz Stars.',
    inspection_notes: 'Brake pads at 85%, Michelin Pilot Sport tyres in excellent condition.',
    features: [
      'AMG Night Package II',
      'Burmester High-End 3D Surround',
      'Superior Line Interior',
      'AMG Performance Exhaust',
      'Exclusive Nappa Leather'
    ],
    accessories: ['Spare Wheel Ring in Obsidian Black', 'AMG Floor Mats'],
    short_description: 'Night Black Magno G63 with Bengal Red interior and factory Night Package.',
    description: 'The pinnacle of bespoke performance off-road luxury. Handcrafted 4.0L V8 Biturbo producing 577 horsepower paired with iconic side exhaust pipes and unmistakable AMG rumble.',
    status: 'AVAILABLE',
    is_published: true,
    created_at: new Date(Date.now() - 30 * 86400000).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'a1b2c3d4-e5f6-47a8-b9c0-112233445566',
    stock_id: 'TCC-00003',
    registration_number: 'KA 03 MN 0077',
    make: 'BMW',
    model: 'M4 Competition',
    variant: 'M xDrive Coupe',
    slug: 'bmw-m4-competition-m-xdrive-2023',
    manufacturing_year: 2023,
    registration_year: 2024,
    fuel_type: 'PETROL',
    transmission: 'AUTOMATIC',
    kilometers: 3100,
    owners: 1,
    color: 'Isle of Man Green',
    asking_price: 15800000,
    purchase_price: 14200000,
    condition: 'EXCELLENT',
    condition_notes: 'Like brand new. Stored in climate-controlled garage.',
    service_history: 'FULL',
    service_history_notes: 'Run-in service completed at 1,800 km at BMW authorized dealer.',
    inspection_notes: 'Showroom fresh condition throughout.',
    features: [
      'M Carbon Bucket Seats',
      'M Carbon Exterior Package',
      'Harman Kardon Audio',
      'M Drive Professional',
      'BMW Laserlight'
    ],
    accessories: ['M Performance Floor Mats', 'BMW Display Key'],
    short_description: 'Isle of Man Green M4 Competition with carbon buckets and M xDrive.',
    description: 'Dynamic supercar performance with daily usability. Featuring the legendary S58 twin-turbocharged straight-six delivering 503 hp to all four wheels.',
    status: 'DRAFT',
    is_published: false,
    created_at: new Date(Date.now() - 5 * 86400000).toISOString(),
    updated_at: new Date().toISOString(),
  }
];

const INITIAL_DEV_MEDIA: VehicleMedia[] = [
  {
    id: 'm1-911-cover',
    vehicle_id: 'e48a1d70-388d-4f11-8be9-0efb9423c911',
    media_type: 'IMAGE',
    storage_path: 'vehicle-images/e48a1d70-388d-4f11-8be9-0efb9423c911/porsche-gt3-front.jpg',
    sort_order: 0,
    is_cover: true,
    alt_text: 'Porsche 911 GT3 Touring front three-quarter dynamic stance',
    created_at: new Date(Date.now() - 14 * 86400000).toISOString(),
  },
  {
    id: 'm2-911-rear',
    vehicle_id: 'e48a1d70-388d-4f11-8be9-0efb9423c911',
    media_type: 'IMAGE',
    storage_path: 'vehicle-images/e48a1d70-388d-4f11-8be9-0efb9423c911/porsche-gt3-rear.jpg',
    sort_order: 1,
    is_cover: false,
    alt_text: 'Porsche 911 GT3 Touring rear decklid and dual center exhaust',
    created_at: new Date(Date.now() - 14 * 86400000).toISOString(),
  },
  {
    id: 'm3-g63-cover',
    vehicle_id: 'f92b7c12-9110-4321-9988-123456789abc',
    media_type: 'IMAGE',
    storage_path: 'vehicle-images/f92b7c12-9110-4321-9988-123456789abc/mercedes-g63-front.jpg',
    sort_order: 0,
    is_cover: true,
    alt_text: 'Mercedes-AMG G 63 Night Black Magno front grille and AMG badge',
    created_at: new Date(Date.now() - 29 * 86400000).toISOString(),
  },
  {
    id: 'm4-m4-cover',
    vehicle_id: 'a1b2c3d4-e5f6-47a8-b9c0-112233445566',
    media_type: 'IMAGE',
    storage_path: 'vehicle-images/a1b2c3d4-e5f6-47a8-b9c0-112233445566/bmw-m4-green.jpg',
    sort_order: 0,
    is_cover: true,
    alt_text: 'BMW M4 Competition Coupe in Isle of Man Green',
    created_at: new Date(Date.now() - 4 * 86400000).toISOString(),
  }
];

const INITIAL_DEV_EVENTS: VehicleEvent[] = [
  {
    id: 'evt-1',
    vehicle_id: 'e48a1d70-388d-4f11-8be9-0efb9423c911',
    event_type: 'ACQUIRED',
    notes: 'Acquired through trusted collector client. Verified pristine condition and zero track use.',
    created_by: null,
    created_at: new Date(Date.now() - 15 * 86400000).toISOString(),
  },
  {
    id: 'evt-2',
    vehicle_id: 'e48a1d70-388d-4f11-8be9-0efb9423c911',
    event_type: 'INSPECTION',
    notes: 'Completed comprehensive 111-point vehicle technical inspection. Perfect mechanical report.',
    created_by: null,
    created_at: new Date(Date.now() - 14 * 86400000).toISOString(),
  },
  {
    id: 'evt-3',
    vehicle_id: 'e48a1d70-388d-4f11-8be9-0efb9423c911',
    event_type: 'PUBLISHED',
    notes: 'Vehicle listed publicly on showroom portal after studio photography verification.',
    created_by: null,
    created_at: new Date(Date.now() - 14 * 86400000).toISOString(),
  }
];

// Helper to get fallback images for stock
function getFallbackImageUrl(path: string): string {
  if (path.includes('porsche-gt3-front')) {
    return 'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&w=1200&q=80';
  }
  if (path.includes('porsche-gt3-rear')) {
    return 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80';
  }
  if (path.includes('mercedes-g63')) {
    return 'https://images.unsplash.com/photo-1520031441872-265e4ff70366?auto=format&fit=crop&w=1200&q=80';
  }
  if (path.includes('bmw-m4')) {
    return 'https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=1200&q=80';
  }
  if (path.startsWith('http://') || path.startsWith('https://') || path.startsWith('data:')) {
    return path;
  }
  return 'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?auto=format&fit=crop&w=1200&q=80';
}

function getLocalVehicles(): Vehicle[] {
  if (typeof window === 'undefined') return INITIAL_DEV_VEHICLES;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_VEHICLES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_VEHICLES, JSON.stringify(INITIAL_DEV_VEHICLES));
      return INITIAL_DEV_VEHICLES;
    }
    return JSON.parse(raw);
  } catch (e) {
    return INITIAL_DEV_VEHICLES;
  }
}

function setLocalVehicles(vehicles: Vehicle[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_VEHICLES, JSON.stringify(vehicles));
  } catch (e) {
    console.error('Failed to save vehicles to localStorage:', e);
  }
}

export function getLocalMedia(): VehicleMedia[] {
  if (typeof window === 'undefined') return INITIAL_DEV_MEDIA;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_MEDIA);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_MEDIA, JSON.stringify(INITIAL_DEV_MEDIA));
      return INITIAL_DEV_MEDIA;
    }
    return JSON.parse(raw);
  } catch (e) {
    return INITIAL_DEV_MEDIA;
  }
}

export function setLocalMedia(media: VehicleMedia[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_MEDIA, JSON.stringify(media));
  } catch (e) {
    console.error('Failed to save media to localStorage:', e);
  }
}

function getLocalEvents(): VehicleEvent[] {
  if (typeof window === 'undefined') return INITIAL_DEV_EVENTS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_EVENTS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_EVENTS, JSON.stringify(INITIAL_DEV_EVENTS));
      return INITIAL_DEV_EVENTS;
    }
    return JSON.parse(raw);
  } catch (e) {
    return INITIAL_DEV_EVENTS;
  }
}

function setLocalEvents(events: VehicleEvent[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_EVENTS, JSON.stringify(events));
  } catch (e) {
    console.error('Failed to save events to localStorage:', e);
  }
}

// -------------------------------------------------------------
// VEHICLE SERVICE API
// -------------------------------------------------------------

export interface VehicleFilterOptions {
  status?: VehicleStatus | 'ALL';
  is_published?: boolean | 'ALL';
  search?: string;
  sortBy?: 'created_at' | 'asking_price' | 'kilometers' | 'manufacturing_year';
  sortOrder?: 'asc' | 'desc';
}

/**
 * Fetch all vehicles with cover image resolution
 */
export async function getAdminVehicles(
  filters?: VehicleFilterOptions
): Promise<{ vehicles: VehicleWithMedia[]; error?: string }> {
  const configured = isSupabaseConfigured();

  if (configured) {
    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        let query = supabase
          .from('vehicles')
          .select('*, vehicle_media(*)');

        if (filters?.status && filters.status !== 'ALL') {
          query = query.eq('status', filters.status);
        }

        if (filters?.is_published !== undefined && filters.is_published !== 'ALL') {
          query = query.eq('is_published', filters.is_published);
        }

        const sortBy = filters?.sortBy || 'created_at';
        const ascending = filters?.sortOrder === 'asc';
        query = query.order(sortBy, { ascending });

        const { data, error } = await query;
        if (error) {
          console.error('Supabase getAdminVehicles error:', error);
          return { vehicles: [], error: error.message };
        }

        const vehicles: VehicleWithMedia[] = (data || []).map((row) => {
          const v = row as Vehicle & { vehicle_media?: VehicleMedia[] };
          const rawMedia: VehicleMedia[] = v.vehicle_media || [];
          const sortedMedia = [...rawMedia].sort((a, b) => a.sort_order - b.sort_order);
          const cover = sortedMedia.find((m) => m.is_cover && m.media_type === 'IMAGE') ||
            sortedMedia.find((m) => m.media_type === 'IMAGE');

          let coverUrl = '';
          if (cover) {
            if (cover.storage_path.startsWith('http')) {
              coverUrl = cover.storage_path;
            } else {
              const { data: urlData } = supabase.storage
                .from('vehicle-images')
                .getPublicUrl(cover.storage_path);
              coverUrl = urlData?.publicUrl || '';
            }
          }

          return {
            ...v,
            media: sortedMedia,
            cover_image_url: coverUrl,
          };
        });

        // Search filter in memory if term supplied
        if (filters?.search && filters.search.trim() !== '') {
          const s = filters.search.toLowerCase().trim();
          const filtered = vehicles.filter(
            (v) =>
              v.make.toLowerCase().includes(s) ||
              v.model.toLowerCase().includes(s) ||
              (v.variant && v.variant.toLowerCase().includes(s)) ||
              v.stock_id.toLowerCase().includes(s) ||
              (v.registration_number && v.registration_number.toLowerCase().includes(s))
          );
          return { vehicles: filtered };
        }

        return { vehicles };
      } catch (err: unknown) {
        console.warn('Falling back to local inventory store due to connection notice:', err);
      }
    }
  }

  // Fallback local store
  let vehicles = getLocalVehicles();
  const allMedia = getLocalMedia();

  // Attach cover image
  const resolved: VehicleWithMedia[] = vehicles.map((v) => {
    const vMedia = allMedia
      .filter((m) => m.vehicle_id === v.id)
      .sort((a, b) => a.sort_order - b.sort_order);
    const cover = vMedia.find((m) => m.is_cover && m.media_type === 'IMAGE') ||
      vMedia.find((m) => m.media_type === 'IMAGE');
    const coverUrl = cover ? getFallbackImageUrl(cover.storage_path) : undefined;

    return {
      ...v,
      media: vMedia.map((m) => ({
        ...m,
        publicUrl: getFallbackImageUrl(m.storage_path),
      })),
      cover_image_url: coverUrl,
    };
  });

  // Apply filters
  let filtered = resolved;
  if (filters?.status && filters.status !== 'ALL') {
    filtered = filtered.filter((v) => v.status === filters.status);
  }
  if (filters?.is_published !== undefined && filters.is_published !== 'ALL') {
    filtered = filtered.filter((v) => v.is_published === filters.is_published);
  }
  if (filters?.search && filters.search.trim() !== '') {
    const s = filters.search.toLowerCase().trim();
    filtered = filtered.filter(
      (v) =>
        v.make.toLowerCase().includes(s) ||
        v.model.toLowerCase().includes(s) ||
        (v.variant && v.variant.toLowerCase().includes(s)) ||
        v.stock_id.toLowerCase().includes(s) ||
        (v.registration_number && v.registration_number.toLowerCase().includes(s))
    );
  }

  // Sort
  const sortBy = filters?.sortBy || 'created_at';
  const asc = filters?.sortOrder === 'asc';
  filtered.sort((a, b) => {
    const valA = a[sortBy as keyof VehicleWithMedia];
    const valB = b[sortBy as keyof VehicleWithMedia];
    if (typeof valA === 'string' && typeof valB === 'string') {
      return asc ? valA.localeCompare(valB) : valB.localeCompare(valA);
    }
    return asc ? Number(valA || 0) - Number(valB || 0) : Number(valB || 0) - Number(valA || 0);
  });

  return { vehicles: filtered };
}

/**
 * Fetch a single vehicle by ID or slug with media and timeline events
 */
export async function getAdminVehicleById(
  idOrSlug: string
): Promise<{ vehicle: VehicleDetailWithEvents | null; error?: string }> {
  const configured = isSupabaseConfigured();

  if (configured) {
    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(idOrSlug);
        let query = supabase.from('vehicles').select('*');
        if (isUuid) {
          query = query.eq('id', idOrSlug);
        } else if (idOrSlug.toUpperCase().startsWith('TCC-')) {
          query = query.eq('stock_id', idOrSlug.toUpperCase());
        } else {
          query = query.eq('slug', idOrSlug);
        }

        const { data: vehicle, error: vehicleErr } = await query.maybeSingle();
        if (vehicleErr) {
          return { vehicle: null, error: vehicleErr.message };
        }
        if (!vehicle) {
          return { vehicle: null, error: 'Vehicle not found.' };
        }

        // Fetch media
        const { data: mediaData } = await supabase
          .from('vehicle_media')
          .select('*')
          .eq('vehicle_id', vehicle.id)
          .order('sort_order', { ascending: true });

        const mediaWithUrls = (mediaData || []).map((m: VehicleMedia) => {
          let publicUrl = m.storage_path;
          if (!m.storage_path.startsWith('http')) {
            const bucket = m.media_type === 'VIDEO' ? 'vehicle-videos' : 'vehicle-images';
            const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(m.storage_path);
            publicUrl = urlData?.publicUrl || '';
          }
          return { ...m, publicUrl };
        });

        // Fetch events
        const { data: eventsData } = await supabase
          .from('vehicle_events')
          .select('*, profiles(full_name)')
          .eq('vehicle_id', vehicle.id)
          .order('created_at', { ascending: false });

        const formattedEvents = (eventsData || []).map((evRow) => {
          const ev = evRow as VehicleEvent & { profiles?: { full_name: string } | null };
          return {
            ...ev,
            author_name: ev.profiles?.full_name || 'System / Administrator',
          };
        });

        const cover = mediaWithUrls.find((m) => m.is_cover && m.media_type === 'IMAGE') ||
          mediaWithUrls.find((m) => m.media_type === 'IMAGE');

        return {
          vehicle: {
            ...vehicle,
            media: mediaWithUrls,
            cover_image_url: cover?.publicUrl,
            events: formattedEvents,
          },
        };
      } catch (err: unknown) {
        console.warn('Fallback to local store for vehicle record:', err);
      }
    }
  }

  // Local fallback
  const vehicles = getLocalVehicles();
  const found = vehicles.find(
    (v) =>
      v.id === idOrSlug ||
      v.stock_id.toLowerCase() === idOrSlug.toLowerCase() ||
      v.slug === idOrSlug
  );

  if (!found) {
    return { vehicle: null, error: `Vehicle record "${idOrSlug}" not found.` };
  }

  const allMedia = getLocalMedia();
  const vMedia = allMedia
    .filter((m) => m.vehicle_id === found.id)
    .sort((a, b) => a.sort_order - b.sort_order)
    .map((m) => ({
      ...m,
      publicUrl: getFallbackImageUrl(m.storage_path),
    }));

  const allEvents = getLocalEvents();
  const vEvents = allEvents
    .filter((e) => e.vehicle_id === found.id)
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .map((e) => ({
      ...e,
      author_name: 'Lead Dealership Administrator',
    }));

  const cover = vMedia.find((m) => m.is_cover && m.media_type === 'IMAGE') ||
    vMedia.find((m) => m.media_type === 'IMAGE');

  return {
    vehicle: {
      ...found,
      media: vMedia,
      cover_image_url: cover?.publicUrl,
      events: vEvents,
    },
  };
}

/**
 * Create a new vehicle record with server-side validation
 */
export async function createVehicle(
  formData: VehicleFormValues,
  adminUserId?: string
): Promise<{ vehicle: Vehicle | null; error?: string }> {
  // 1. Server-side validation via Zod
  const validation = vehicleSchema.safeParse(formData);
  if (!validation.success) {
    const firstIssue = validation.error.issues[0];
    return {
      vehicle: null,
      error: `Validation failed: ${firstIssue?.message || 'Invalid form data'}`,
    };
  }

  const validData = validation.data;

  // Publishing integrity check if attempting to create as published
  if (validData.is_published) {
    const pubCheck = validatePublishingIntegrity(validData, 0);
    if (!pubCheck.valid) {
      return {
        vehicle: null,
        error: pubCheck.reason || 'Vehicle cannot be published during initial creation without media.',
      };
    }
  }

  const configured = isSupabaseConfigured();

  if (configured) {
    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from('vehicles')
          .insert({
            make: validData.make,
            model: validData.model,
            variant: validData.variant || null,
            slug: validData.slug,
            registration_number: validData.registration_number || null,
            manufacturing_year: validData.manufacturing_year,
            registration_year: validData.registration_year || null,
            fuel_type: validData.fuel_type,
            transmission: validData.transmission,
            kilometers: validData.kilometers,
            owners: validData.owners,
            color: validData.color || null,
            asking_price: validData.asking_price,
            purchase_price: validData.purchase_price || null,
            condition: validData.condition || null,
            condition_notes: validData.condition_notes || null,
            service_history: validData.service_history || null,
            service_history_notes: validData.service_history_notes || null,
            inspection_notes: validData.inspection_notes || null,
            features: validData.features,
            accessories: validData.accessories,
            short_description: validData.short_description || null,
            description: validData.description || null,
            status: validData.status,
            is_published: validData.is_published,
          })
          .select()
          .single();

        if (error) {
          console.error('Supabase createVehicle error:', error);
          return { vehicle: null, error: error.message };
        }

        // Log initial ACQUIRED event
        if (data) {
          await supabase.from('vehicle_events').insert({
            vehicle_id: data.id,
            event_type: 'ACQUIRED',
            notes: `Initial intake of ${data.manufacturing_year} ${data.make} ${data.model}${data.variant ? ' ' + data.variant : ''}. Asking price: ₹${data.asking_price.toLocaleString('en-IN')}.`,
            created_by: adminUserId || null,
          });
        }

        return { vehicle: data };
      } catch (err: unknown) {
        console.warn('Fallback to local store on create error:', err);
      }
    }
  }

  // Local fallback
  const vehicles = getLocalVehicles();
  const stockSeq = vehicles.length + 1;
  const stockId = `TCC-${String(stockSeq).padStart(5, '0')}`;
  const newId = crypto.randomUUID();

  // Check unique slug
  if (vehicles.some((v) => v.slug === validData.slug)) {
    return {
      vehicle: null,
      error: `A vehicle with URL slug "${validData.slug}" already exists. Please adjust the slug.`,
    };
  }

  const newVehicle: Vehicle = {
    id: newId,
    stock_id: stockId,
    registration_number: validData.registration_number || null,
    make: validData.make,
    model: validData.model,
    variant: validData.variant || null,
    slug: validData.slug,
    manufacturing_year: validData.manufacturing_year,
    registration_year: validData.registration_year || null,
    fuel_type: validData.fuel_type,
    transmission: validData.transmission,
    kilometers: validData.kilometers,
    owners: validData.owners,
    color: validData.color || null,
    asking_price: validData.asking_price,
    purchase_price: validData.purchase_price || null,
    condition: validData.condition || null,
    condition_notes: validData.condition_notes || null,
    service_history: validData.service_history || null,
    service_history_notes: validData.service_history_notes || null,
    inspection_notes: validData.inspection_notes || null,
    features: validData.features,
    accessories: validData.accessories,
    short_description: validData.short_description || null,
    description: validData.description || null,
    status: validData.status,
    is_published: validData.is_published,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  vehicles.unshift(newVehicle);
  setLocalVehicles(vehicles);

  // Add initial ACQUIRED event
  const events = getLocalEvents();
  events.unshift({
    id: crypto.randomUUID(),
    vehicle_id: newId,
    event_type: 'ACQUIRED',
    notes: `Initial intake of ${newVehicle.manufacturing_year} ${newVehicle.make} ${newVehicle.model}${newVehicle.variant ? ' ' + newVehicle.variant : ''}. Asking price: ₹${newVehicle.asking_price.toLocaleString('en-IN')}.`,
    created_by: adminUserId || null,
    created_at: new Date().toISOString(),
  });
  setLocalEvents(events);

  return { vehicle: newVehicle };
}

/**
 * Update an existing vehicle record
 */
export async function updateVehicle(
  id: string,
  formData: Partial<VehicleFormValues>,
  adminUserId?: string
): Promise<{ vehicle: Vehicle | null; error?: string }> {
  const configured = isSupabaseConfigured();

  if (configured) {
    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        // Fetch current vehicle to compare for meaningful event logging and validate integrity
        const { data: current, error: fetchErr } = await supabase
          .from('vehicles')
          .select('*')
          .eq('id', id)
          .single();

        if (fetchErr || !current) {
          console.error('Supabase updateVehicle fetch error:', fetchErr);
          return { vehicle: null, error: fetchErr?.message || 'Vehicle record not found.' };
        }

        // Merge existing attributes with changes for authoritative integrity validation
        const mergedVehicle: Partial<VehicleFormValues> = {
          make: current.make,
          model: current.model,
          variant: current.variant,
          slug: current.slug,
          registration_number: current.registration_number,
          manufacturing_year: current.manufacturing_year,
          registration_year: current.registration_year,
          fuel_type: current.fuel_type,
          transmission: current.transmission,
          kilometers: current.kilometers,
          owners: current.owners,
          color: current.color,
          asking_price: current.asking_price,
          purchase_price: current.purchase_price,
          condition: current.condition,
          condition_notes: current.condition_notes,
          service_history: current.service_history,
          service_history_notes: current.service_history_notes,
          inspection_notes: current.inspection_notes,
          features: Array.isArray(current.features) ? (current.features as string[]) : [],
          accessories: Array.isArray(current.accessories) ? (current.accessories as string[]) : [],
          short_description: current.short_description,
          description: current.description,
          status: current.status,
          is_published: current.is_published,
          ...formData,
        };

        // If attempting to publish, verify integrity on the merged vehicle attributes
        if (mergedVehicle.is_published === true) {
          const { count } = await supabase
            .from('vehicle_media')
            .select('*', { count: 'exact', head: true })
            .eq('vehicle_id', id)
            .eq('media_type', 'IMAGE');
          const imageCount = count || 0;

          const pubCheck = validatePublishingIntegrity(mergedVehicle, imageCount);
          if (!pubCheck.valid) {
            return {
              vehicle: null,
              error: pubCheck.reason || 'Vehicle cannot be published: Requirements not met.',
            };
          }
        }

        // If publishing a DRAFT vehicle, automatically activate status to AVAILABLE
        const finalStatus = (formData.status !== undefined)
          ? formData.status
          : (mergedVehicle.is_published && current.status === 'DRAFT' ? 'AVAILABLE' : current.status);

        const updatePayload: Database['public']['Tables']['vehicles']['Update'] = {
          ...formData,
          status: finalStatus,
          features: (formData.features !== undefined ? formData.features : current.features) as Json | undefined,
          accessories: (formData.accessories !== undefined ? formData.accessories : current.accessories) as Json | undefined,
          updated_at: new Date().toISOString(),
        };

        const { data, error } = await supabase
          .from('vehicles')
          .update(updatePayload)
          .eq('id', id)
          .select()
          .single();

        if (error) {
          console.error('Supabase updateVehicle error:', error);
          return { vehicle: null, error: error.message };
        }

        // Log meaningful events
        if (current && data) {
          if (current.asking_price !== data.asking_price) {
            await supabase.from('vehicle_events').insert({
              vehicle_id: id,
              event_type: 'PRICING_UPDATED',
              notes: `Price revised from ₹${current.asking_price.toLocaleString('en-IN')} to ₹${data.asking_price.toLocaleString('en-IN')}.`,
              created_by: adminUserId || null,
            });
          }

          if (current.status !== data.status) {
            let eventType: VehicleEventType = 'NOTE';
            if (data.status === 'AVAILABLE') eventType = 'NOTE';
            if (data.status === 'RESERVED') eventType = 'RESERVED';
            if (data.status === 'SOLD') eventType = 'SOLD';
            if (data.status === 'ARCHIVED') eventType = 'ARCHIVED';

            await supabase.from('vehicle_events').insert({
              vehicle_id: id,
              event_type: eventType,
              notes: `Lifecycle status transitioned from ${current.status} to ${data.status}.`,
              created_by: adminUserId || null,
            });
          }

          if (current.is_published !== data.is_published) {
            await supabase.from('vehicle_events').insert({
              vehicle_id: id,
              event_type: data.is_published ? 'PUBLISHED' : 'UNPUBLISHED',
              notes: data.is_published
                ? 'Vehicle published to online showroom inventory.'
                : 'Vehicle withdrawn from public online showroom (unpublished).',
              created_by: adminUserId || null,
            });
          }
        }

        return { vehicle: data };
      } catch (err: unknown) {
        console.warn('Fallback to local store on update error:', err);
      }
    }
  }

  // Local fallback
  const vehicles = getLocalVehicles();
  const index = vehicles.findIndex((v) => v.id === id);
  if (index === -1) {
    return { vehicle: null, error: 'Vehicle not found.' };
  }

  const current = vehicles[index];
  const mergedVehicle: Partial<VehicleFormValues> = {
    ...current,
    features: Array.isArray(current.features) ? (current.features as string[]) : [],
    accessories: Array.isArray(current.accessories) ? (current.accessories as string[]) : [],
    ...formData,
  };

  // If attempting to publish, verify integrity on merged vehicle
  if (mergedVehicle.is_published === true) {
    const allMedia = getLocalMedia();
    const imageCount = allMedia.filter(
      (m) => m.vehicle_id === id && m.media_type === 'IMAGE'
    ).length;

    const pubCheck = validatePublishingIntegrity(mergedVehicle, imageCount);
    if (!pubCheck.valid) {
      return {
        vehicle: null,
        error: pubCheck.reason || 'Vehicle cannot be published: Requirements not met.',
      };
    }
  }

  // Slug uniqueness check if slug changed
  if (formData.slug && formData.slug !== current.slug) {
    if (vehicles.some((v) => v.id !== id && v.slug === formData.slug)) {
      return {
        vehicle: null,
        error: `URL slug "${formData.slug}" is already in use by another record.`,
      };
    }
  }

  const finalStatus = (formData.status !== undefined)
    ? formData.status
    : (mergedVehicle.is_published && current.status === 'DRAFT' ? 'AVAILABLE' : current.status);

  const updated: Vehicle = {
    ...current,
    ...formData,
    status: finalStatus,
    features: (formData.features !== undefined ? formData.features : current.features) as Json,
    accessories: (formData.accessories !== undefined ? formData.accessories : current.accessories) as Json,
    updated_at: new Date().toISOString(),
  };

  vehicles[index] = updated;
  setLocalVehicles(vehicles);

  // Log events
  const events = getLocalEvents();

  if (current.asking_price !== updated.asking_price) {
    events.unshift({
      id: crypto.randomUUID(),
      vehicle_id: id,
      event_type: 'PRICING_UPDATED',
      notes: `Asking price adjusted from ₹${current.asking_price.toLocaleString('en-IN')} to ₹${updated.asking_price.toLocaleString('en-IN')}.`,
      created_by: adminUserId || null,
      created_at: new Date().toISOString(),
    });
  }

  if (current.status !== updated.status) {
    let eventType: VehicleEventType = 'NOTE';
    if (updated.status === 'RESERVED') eventType = 'RESERVED';
    else if (updated.status === 'SOLD') eventType = 'SOLD';
    else if (updated.status === 'ARCHIVED') eventType = 'ARCHIVED';
    else if (current.status === 'RESERVED' && updated.status === 'AVAILABLE')
      eventType = 'RESERVATION_CANCELLED';

    events.unshift({
      id: crypto.randomUUID(),
      vehicle_id: id,
      event_type: eventType,
      notes: `Status changed from ${current.status} to ${updated.status}.`,
      created_by: adminUserId || null,
      created_at: new Date().toISOString(),
    });
  }

  if (current.is_published !== updated.is_published) {
    events.unshift({
      id: crypto.randomUUID(),
      vehicle_id: id,
      event_type: updated.is_published ? 'PUBLISHED' : 'UNPUBLISHED',
      notes: updated.is_published
        ? 'Vehicle published to online showroom inventory.'
        : 'Vehicle withdrawn from public online showroom.',
      created_by: adminUserId || null,
      created_at: new Date().toISOString(),
    });
  }

  setLocalEvents(events);

  return { vehicle: updated };
}

/**
 * Explicit toggle for status management
 */
export async function updateVehicleStatus(
  id: string,
  newStatus: VehicleStatus,
  adminUserId?: string
): Promise<{ success: boolean; error?: string }> {
  // If moving to ARCHIVED, automatically unpublish as per approved lifecycle
  const extraFields: Partial<VehicleFormValues> = { status: newStatus };
  if (newStatus === 'ARCHIVED') {
    extraFields.is_published = false;
  }

  const res = await updateVehicle(id, extraFields, adminUserId);
  if (res.error) {
    return { success: false, error: res.error };
  }
  return { success: true };
}

/**
 * Explicit toggle for publication with integrity enforcement
 */
export async function setVehiclePublished(
  id: string,
  isPublished: boolean,
  adminUserId?: string
): Promise<{ success: boolean; error?: string }> {
  const payload: Partial<VehicleFormValues> = { is_published: isPublished };
  if (isPublished) {
    payload.status = 'AVAILABLE';
  }
  const res = await updateVehicle(id, payload, adminUserId);
  if (res.error) {
    return { success: false, error: res.error };
  }
  return { success: true };
}

/**
 * Add a manual internal note to vehicle timeline
 */
export async function addVehicleEventNote(
  vehicleId: string,
  notes: string,
  adminUserId?: string
): Promise<{ success: boolean; error?: string }> {
  if (!notes || notes.trim() === '') {
    return { success: false, error: 'Note content cannot be empty.' };
  }

  const configured = isSupabaseConfigured();
  if (configured) {
    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        const { error } = await supabase.from('vehicle_events').insert({
          vehicle_id: vehicleId,
          event_type: 'NOTE',
          notes: notes.trim(),
          created_by: adminUserId || null,
        });
        if (error) {
          return { success: false, error: error.message };
        }
        return { success: true };
      } catch (err: unknown) {
        console.warn('Fallback to local store for event note:', err);
      }
    }
  }

  const events = getLocalEvents();
  events.unshift({
    id: crypto.randomUUID(),
    vehicle_id: vehicleId,
    event_type: 'NOTE',
    notes: notes.trim(),
    created_by: adminUserId || null,
    created_at: new Date().toISOString(),
  });
  setLocalEvents(events);

  return { success: true };
}

/**
 * Delete a vehicle and all associated records
 */
export async function deleteVehicle(
  id: string
): Promise<{ success: boolean; error?: string }> {
  const configured = isSupabaseConfigured();

  if (configured) {
    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        // Delete vehicle row (cascade will delete vehicle_media and vehicle_events in DB)
        const { error } = await supabase
          .from('vehicles')
          .delete()
          .eq('id', id);

        if (error) {
          return { success: false, error: error.message };
        }
        return { success: true };
      } catch (err: unknown) {
        console.warn('Fallback to local store for vehicle deletion:', err);
      }
    }
  }

  // Local fallback
  const vehicles = getLocalVehicles();
  const nextVehicles = vehicles.filter((v) => v.id !== id);
  if (vehicles.length === nextVehicles.length) {
    return { success: false, error: 'Vehicle not found.' };
  }
  setLocalVehicles(nextVehicles);

  // Clean local media & events
  const media = getLocalMedia();
  setLocalMedia(media.filter((m) => m.vehicle_id !== id));

  const events = getLocalEvents();
  setLocalEvents(events.filter((e) => e.vehicle_id !== id));

  return { success: true };
}

// -------------------------------------------------------------
// PUBLIC SHOWROOM VEHICLE ACCESS API
// STRICT BOUNDARY: Only AVAILABLE + is_published = true
// Dealer-private fields (purchase_price, inspection_notes, events)
// are strictly excluded from public consumption.
// -------------------------------------------------------------

export interface PublicShowroomVehicle {
  id: string;
  stock_id: string;
  slug: string;
  make: string;
  model: string;
  variant: string | null;
  manufacturing_year: number;
  registration_year: number | null;
  fuel_type: Database['public']['Enums']['vehicle_fuel_type'];
  transmission: Database['public']['Enums']['vehicle_transmission'];
  kilometers: number;
  owners: number;
  color: string | null;
  asking_price: number;
  condition: Database['public']['Enums']['vehicle_condition'] | null;
  service_history: Database['public']['Enums']['service_history_status'] | null;
  features: string[];
  accessories: string[];
  short_description: string | null;
  description: string | null;
  status: 'AVAILABLE';
  is_published: true;
  cover_image_url?: string;
  media?: {
    id: string;
    media_type: 'IMAGE' | 'VIDEO';
    publicUrl: string;
    alt_text: string | null;
    is_cover: boolean;
    sort_order: number;
  }[];
}

// Publicly readable columns excluding confidential purchase_price
const PUBLIC_VEHICLE_SELECT_FIELDS =
  'id, stock_id, registration_number, make, model, variant, slug, manufacturing_year, registration_year, fuel_type, transmission, kilometers, owners, color, asking_price, condition, condition_notes, service_history, service_history_notes, inspection_notes, features, accessories, short_description, description, status, is_published, created_at, updated_at, vehicle_media(*)';

/**
 * Public catalog fetcher - strictly enforces AVAILABLE + is_published = true
 * and strips all private internal fields.
 */
export async function getPublicVehicles(
  searchQuery?: string
): Promise<{ vehicles: PublicShowroomVehicle[]; error?: string }> {
  const configured = isSupabaseConfigured();

  if (configured) {
    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        let query = supabase
          .from('vehicles')
          .select(PUBLIC_VEHICLE_SELECT_FIELDS)
          .eq('status', 'AVAILABLE')
          .eq('is_published', true)
          .order('created_at', { ascending: false });

        const { data, error } = await query;
        if (error) {
          console.warn('Supabase vehicles query notice, using showroom catalog:', error.message);
        } else if (data && data.length > 0) {
          const publicList: PublicShowroomVehicle[] = (data || []).map((row) => {
          const v = row as Vehicle & { vehicle_media?: VehicleMedia[] };
          const rawMedia: VehicleMedia[] = v.vehicle_media || [];
          const sortedMedia = [...rawMedia].sort((a, b) => a.sort_order - b.sort_order);
          const cover =
            sortedMedia.find((m) => m.is_cover && m.media_type === 'IMAGE') ||
            sortedMedia.find((m) => m.media_type === 'IMAGE');

          let coverUrl = '';
          if (cover) {
            if (cover.storage_path.startsWith('http')) {
              coverUrl = cover.storage_path;
            } else {
              const { data: urlData } = supabase.storage
                .from('vehicle-images')
                .getPublicUrl(cover.storage_path);
              coverUrl = urlData?.publicUrl || '';
            }
          }

          // Strip all private fields explicitly
          return {
            id: v.id,
            stock_id: v.stock_id,
            slug: v.slug,
            make: v.make,
            model: v.model,
            variant: v.variant,
            manufacturing_year: v.manufacturing_year,
            registration_year: v.registration_year,
            fuel_type: v.fuel_type,
            transmission: v.transmission,
            kilometers: v.kilometers,
            owners: v.owners,
            color: v.color,
            asking_price: v.asking_price,
            condition: v.condition,
            service_history: v.service_history,
            features: Array.isArray(v.features) ? (v.features as string[]) : [],
            accessories: Array.isArray(v.accessories) ? (v.accessories as string[]) : [],
            short_description: v.short_description,
            description: v.description,
            status: 'AVAILABLE',
            is_published: true,
            cover_image_url: coverUrl,
          };
        });

        if (searchQuery && searchQuery.trim() !== '') {
          const s = searchQuery.toLowerCase().trim();
          return {
            vehicles: publicList.filter(
              (v) =>
                v.make.toLowerCase().includes(s) ||
                v.model.toLowerCase().includes(s) ||
                (v.variant && v.variant.toLowerCase().includes(s))
            ),
          };
        }

        return { vehicles: publicList };
        }
      } catch (err: unknown) {
        console.warn('Fallback to local store for public vehicles:', err);
      }
    }
  }

  // Local fallback
  const vehicles = getLocalVehicles();
  const allMedia = getLocalMedia();

  // Strict boundary: Only AVAILABLE and is_published = true
  const publicVehicles = vehicles.filter(
    (v) => v.status === 'AVAILABLE' && v.is_published === true
  );

  const resolved: PublicShowroomVehicle[] = publicVehicles.map((v) => {
    const vMedia = allMedia
      .filter((m) => m.vehicle_id === v.id)
      .sort((a, b) => a.sort_order - b.sort_order);
    const cover =
      vMedia.find((m) => m.is_cover && m.media_type === 'IMAGE') ||
      vMedia.find((m) => m.media_type === 'IMAGE');

    return {
      id: v.id,
      stock_id: v.stock_id,
      slug: v.slug,
      make: v.make,
      model: v.model,
      variant: v.variant,
      manufacturing_year: v.manufacturing_year,
      registration_year: v.registration_year,
      fuel_type: v.fuel_type,
      transmission: v.transmission,
      kilometers: v.kilometers,
      owners: v.owners,
      color: v.color,
      asking_price: v.asking_price,
      condition: v.condition,
      service_history: v.service_history,
      features: Array.isArray(v.features) ? (v.features as string[]) : [],
      accessories: Array.isArray(v.accessories) ? (v.accessories as string[]) : [],
      short_description: v.short_description,
      description: v.description,
      status: 'AVAILABLE',
      is_published: true,
      cover_image_url: cover ? getFallbackImageUrl(cover.storage_path) : undefined,
    };
  });

  if (searchQuery && searchQuery.trim() !== '') {
    const s = searchQuery.toLowerCase().trim();
    return {
      vehicles: resolved.filter(
        (v) =>
          v.make.toLowerCase().includes(s) ||
          v.model.toLowerCase().includes(s) ||
          (v.variant && v.variant.toLowerCase().includes(s))
      ),
    };
  }

  return { vehicles: resolved };
}

/**
 * Public vehicle detail fetcher by slug
 * Strict boundary: returns null if vehicle is not AVAILABLE or not is_published
 * Explicitly strips dealer-private fields (purchase_price, inspection notes, internal events).
 */
export async function getPublicVehicleBySlug(
  slug: string
): Promise<{ vehicle: PublicShowroomVehicle | null; error?: string }> {
  const configured = isSupabaseConfigured();

  if (configured) {
    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        const { data: v, error } = await supabase
          .from('vehicles')
          .select(PUBLIC_VEHICLE_SELECT_FIELDS)
          .eq('slug', slug)
          .eq('status', 'AVAILABLE')
          .eq('is_published', true)
          .maybeSingle();

        if (error) {
          console.warn('Supabase vehicle by slug notice, using showroom catalog:', error.message);
        } else if (v) {

        const rawMedia: VehicleMedia[] = v.vehicle_media || [];
        const sortedMedia = [...rawMedia].sort((a, b) => a.sort_order - b.sort_order);

        const mediaWithUrls = sortedMedia.map((m) => {
          let publicUrl = m.storage_path;
          if (!m.storage_path.startsWith('http')) {
            const bucket = m.media_type === 'VIDEO' ? 'vehicle-videos' : 'vehicle-images';
            const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(m.storage_path);
            publicUrl = urlData?.publicUrl || '';
          }
          return {
            id: m.id,
            media_type: m.media_type,
            publicUrl,
            alt_text: m.alt_text,
            is_cover: m.is_cover,
            sort_order: m.sort_order,
          };
        });

        const cover =
          mediaWithUrls.find((m) => m.is_cover && m.media_type === 'IMAGE') ||
          mediaWithUrls.find((m) => m.media_type === 'IMAGE');

        return {
          vehicle: {
            id: v.id,
            stock_id: v.stock_id,
            slug: v.slug,
            make: v.make,
            model: v.model,
            variant: v.variant,
            manufacturing_year: v.manufacturing_year,
            registration_year: v.registration_year,
            fuel_type: v.fuel_type,
            transmission: v.transmission,
            kilometers: v.kilometers,
            owners: v.owners,
            color: v.color,
            asking_price: v.asking_price,
            condition: v.condition,
            service_history: v.service_history,
            features: Array.isArray(v.features) ? (v.features as string[]) : [],
            accessories: Array.isArray(v.accessories) ? (v.accessories as string[]) : [],
            short_description: v.short_description,
            description: v.description,
            status: 'AVAILABLE',
            is_published: true,
            cover_image_url: cover?.publicUrl,
            media: mediaWithUrls,
          },
        };
        }
      } catch (err: unknown) {
        console.warn('Fallback to local store for public detail:', err);
      }
    }
  }

  // Local fallback
  const vehicles = getLocalVehicles();
  const v = vehicles.find((item) => item.slug === slug);

  // Strict boundary: Only AVAILABLE and is_published = true
  if (!v || v.status !== 'AVAILABLE' || !v.is_published) {
    return { vehicle: null, error: 'Vehicle profile not found in public inventory.' };
  }

  const allMedia = getLocalMedia();
  const vMedia = allMedia
    .filter((m) => m.vehicle_id === v.id)
    .sort((a, b) => a.sort_order - b.sort_order)
    .map((m) => ({
      id: m.id,
      media_type: m.media_type,
      publicUrl: getFallbackImageUrl(m.storage_path),
      alt_text: m.alt_text,
      is_cover: m.is_cover,
      sort_order: m.sort_order,
    }));

  const cover =
    vMedia.find((m) => m.is_cover && m.media_type === 'IMAGE') ||
    vMedia.find((m) => m.media_type === 'IMAGE');

  return {
    vehicle: {
      id: v.id,
      stock_id: v.stock_id,
      slug: v.slug,
      make: v.make,
      model: v.model,
      variant: v.variant,
      manufacturing_year: v.manufacturing_year,
      registration_year: v.registration_year,
      fuel_type: v.fuel_type,
      transmission: v.transmission,
      kilometers: v.kilometers,
      owners: v.owners,
      color: v.color,
      asking_price: v.asking_price,
      condition: v.condition,
      service_history: v.service_history,
      features: Array.isArray(v.features) ? (v.features as string[]) : [],
      accessories: Array.isArray(v.accessories) ? (v.accessories as string[]) : [],
      short_description: v.short_description,
      description: v.description,
      status: 'AVAILABLE',
      is_published: true,
      cover_image_url: cover?.publicUrl,
      media: vMedia,
    },
  };
}
