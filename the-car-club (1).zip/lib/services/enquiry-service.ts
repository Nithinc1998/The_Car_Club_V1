import { getSupabaseBrowserClient, isSupabaseConfigured } from '@/lib/supabase/client';
import { Database } from '@/types/database';
import {
  PublicEnquiryInput,
  publicEnquirySchema,
  EnquiryStatus,
  EnquiryType,
  EnquirySource,
  enquiryStatusSchema,
} from '@/lib/validations/enquiry';

export { publicEnquirySchema };

export type Enquiry = Database['public']['Tables']['enquiries']['Row'];

export interface RelatedVehicleSummary {
  id: string;
  stock_id: string;
  make: string;
  model: string;
  variant: string | null;
  manufacturing_year: number;
  asking_price: number;
  slug: string;
  status: Database['public']['Enums']['vehicle_status'];
  is_published: boolean;
  cover_image_url?: string;
}

export interface EnquiryWithVehicle extends Enquiry {
  vehicle?: RelatedVehicleSummary | null;
}

type SupabaseEnquiryJoin = Enquiry & { vehicles?: RelatedVehicleSummary | null };

// -------------------------------------------------------------
// LOCAL STORAGE ADAPTER FOR PREVIEW / DEV ENVIRONMENT
// Enables full testing without remote credentials
// -------------------------------------------------------------
const STORAGE_KEY_ENQUIRIES = 'tcc_admin_inventory_enquiries';

const INITIAL_DEV_ENQUIRIES: EnquiryWithVehicle[] = [
  {
    id: 'enq-911-001',
    vehicle_id: 'e48a1d70-388d-4f11-8be9-0efb9423c911',
    customer_name: 'Rajesh Mehra',
    phone: '+91 98201 44552',
    email: 'rajesh.mehra@example.com',
    enquiry_type: 'TEST_DRIVE',
    preferred_date: new Date(Date.now() + 2 * 86400000).toISOString().split('T')[0],
    preferred_time: '11:00',
    offer_amount: null,
    message: 'Interested in evaluating the GT3 Touring. Would like to verify the PCCB condition and front axle lift during a private test drive.',
    status: 'NEW',
    source: 'WEBSITE',
    created_at: new Date(Date.now() - 3 * 3600000).toISOString(),
    updated_at: new Date(Date.now() - 3 * 3600000).toISOString(),
    vehicle: {
      id: 'e48a1d70-388d-4f11-8be9-0efb9423c911',
      stock_id: 'TCC-00001',
      make: 'Porsche',
      model: '911 GT3 Touring',
      variant: '992 Package',
      manufacturing_year: 2023,
      asking_price: 27500000,
      slug: 'porsche-911-gt3-touring-992-2023',
      status: 'AVAILABLE',
      is_published: true,
      cover_image_url: 'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&w=1200&q=80',
    },
  },
  {
    id: 'enq-g63-002',
    vehicle_id: 'f92b7c12-9110-4321-9988-123456789abc',
    customer_name: 'Vikramaditya Singhania',
    phone: '+91 99100 23411',
    email: 'v.singhania@corp.example',
    enquiry_type: 'OFFER',
    preferred_date: null,
    preferred_time: null,
    offer_amount: 34500000,
    message: 'Direct acquisition proposal for the Night Black Magno G63. Ready for immediate wire transfer upon verification of service stamps.',
    status: 'CONTACTED',
    source: 'WEBSITE',
    created_at: new Date(Date.now() - 26 * 3600000).toISOString(),
    updated_at: new Date(Date.now() - 12 * 3600000).toISOString(),
    vehicle: {
      id: 'f92b7c12-9110-4321-9988-123456789abc',
      stock_id: 'TCC-00002',
      make: 'Mercedes-AMG',
      model: 'G 63',
      variant: 'V8 Biturbo Magno Edition',
      manufacturing_year: 2022,
      asking_price: 36000000,
      slug: 'mercedes-amg-g63-magno-2022',
      status: 'AVAILABLE',
      is_published: true,
      cover_image_url: 'https://images.unsplash.com/photo-1520031441872-265e4ff70366?auto=format&fit=crop&w=1200&q=80',
    },
  },
  {
    id: 'enq-gen-003',
    vehicle_id: null,
    customer_name: 'Aditi Roy',
    phone: '+91 97400 88910',
    email: 'aditi.roy@design.example',
    enquiry_type: 'GENERAL',
    preferred_date: null,
    preferred_time: null,
    offer_amount: null,
    message: 'Inquiring whether you source bespoke spec Aston Martin Vantage or DB12 coupes through your consignment channel.',
    status: 'FOLLOW_UP',
    source: 'WEBSITE',
    created_at: new Date(Date.now() - 48 * 3600000).toISOString(),
    updated_at: new Date(Date.now() - 20 * 3600000).toISOString(),
    vehicle: null,
  }
];

function getLocalEnquiries(): EnquiryWithVehicle[] {
  if (typeof window === 'undefined') return INITIAL_DEV_ENQUIRIES;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_ENQUIRIES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_ENQUIRIES, JSON.stringify(INITIAL_DEV_ENQUIRIES));
      return INITIAL_DEV_ENQUIRIES;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_DEV_ENQUIRIES;
  }
}

function setLocalEnquiries(enquiries: EnquiryWithVehicle[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_ENQUIRIES, JSON.stringify(enquiries));
  } catch (e) {
    console.error('Failed to save enquiries to localStorage:', e);
  }
}

// -------------------------------------------------------------
// PUBLIC CUSTOMER SUBMISSION (ANONYMOUS INSERT ONLY)
// -------------------------------------------------------------

export interface PublicEnquiryResult {
  success: boolean;
  message?: string;
  error?: string;
}

/**
 * Public customer submission
 * Server-side anti-tampering:
 * - Strictly enforces status = 'NEW'
 * - Strictly enforces source = 'WEBSITE'
 * - Validates schema and required business constraints
 */
export async function submitPublicEnquiry(
  input: PublicEnquiryInput
): Promise<PublicEnquiryResult> {
  // 1. Validate on the server side
  const validation = publicEnquirySchema.safeParse(input);
  if (!validation.success) {
    const firstErr = validation.error.issues[0]?.message || 'Invalid enquiry details.';
    return { success: false, error: firstErr };
  }

  const validData = validation.data;

  // 2. Anti-tampering enforcement
  const enforcedStatus: EnquiryStatus = 'NEW';
  const enforcedSource: EnquirySource = 'WEBSITE';

  const configured = isSupabaseConfigured();

  if (configured) {
    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        // Verify vehicle is publicly available if vehicle_id supplied
        if (validData.vehicle_id) {
          const { data: vehicleCheck, error: vehicleErr } = await supabase
            .from('vehicles')
            .select('id, status, is_published')
            .eq('id', validData.vehicle_id)
            .maybeSingle();

          if (vehicleErr || !vehicleCheck || !vehicleCheck.is_published) {
            return {
              success: false,
              error: 'The requested vehicle is currently not available for new inquiries.',
            };
          }
        }

        // Insert using anonymous INSERT policy and database defaults (status defaults to NEW)
        const { error: insertErr } = await supabase.from('enquiries').insert({
          vehicle_id: validData.vehicle_id || null,
          customer_name: validData.customer_name,
          phone: validData.phone,
          email: validData.email || null,
          enquiry_type: validData.enquiry_type,
          preferred_date: validData.preferred_date || null,
          preferred_time: validData.preferred_time || null,
          offer_amount: validData.offer_amount || null,
          message: validData.message || null,
          source: enforcedSource,
        });

        if (insertErr) {
          console.error('Supabase submitPublicEnquiry error:', insertErr);
          return {
            success: false,
            error: 'Unable to submit inquiry at this time. Please contact our concierge directly.',
          };
        }

        return {
          success: true,
          message: 'Your inquiry has been received. An automotive concierge will contact you shortly.',
        };
      } catch (err: unknown) {
        console.warn('Fallback to local store for public enquiry:', err);
      }
    }
  }

  // Local Storage / Dev Preview fallback
  const localEnquiries = getLocalEnquiries();
  const newId = `enq-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;

  // Find vehicle if associated
  let vehicleSummary: RelatedVehicleSummary | null = null;
  if (validData.vehicle_id) {
    try {
      const rawVehicles = localStorage.getItem('tcc_admin_inventory_vehicles');
      if (rawVehicles) {
        const parsedVehicles = JSON.parse(rawVehicles) as Array<{
          id: string;
          stock_id: string;
          make: string;
          model: string;
          variant: string | null;
          manufacturing_year: number;
          asking_price: number;
          slug: string;
          status: Database['public']['Enums']['vehicle_status'];
          is_published: boolean;
        }>;
        const match = Array.isArray(parsedVehicles)
          ? parsedVehicles.find((v) => v.id === validData.vehicle_id)
          : undefined;
        if (match) {
          vehicleSummary = {
            id: match.id,
            stock_id: match.stock_id,
            make: match.make,
            model: match.model,
            variant: match.variant,
            manufacturing_year: match.manufacturing_year,
            asking_price: match.asking_price,
            slug: match.slug,
            status: match.status,
            is_published: match.is_published,
          };
        }
      }
    } catch {
      vehicleSummary = null;
    }
  }

  const newEnquiry: EnquiryWithVehicle = {
    id: newId,
    vehicle_id: validData.vehicle_id || null,
    customer_name: validData.customer_name,
    phone: validData.phone,
    email: validData.email || null,
    enquiry_type: validData.enquiry_type,
    preferred_date: validData.preferred_date || null,
    preferred_time: validData.preferred_time || null,
    offer_amount: validData.offer_amount || null,
    message: validData.message || null,
    status: enforcedStatus,
    source: enforcedSource,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    vehicle: vehicleSummary,
  };

  localEnquiries.unshift(newEnquiry);
  setLocalEnquiries(localEnquiries);

  return {
    success: true,
    message: 'Your inquiry has been received. An automotive concierge will contact you shortly.',
  };
}

// -------------------------------------------------------------
// AUTHENTICATED ADMIN ENQUIRY MANAGEMENT API
// STRICTLY RESTRICTED TO ADMIN PROFILES
// -------------------------------------------------------------

export interface EnquiryFilterOptions {
  status?: EnquiryStatus | 'ALL';
  type?: EnquiryType | 'ALL';
  search?: string;
}

/**
 * Fetch all enquiries with related vehicle summaries (ADMIN only)
 */
export async function getAdminEnquiries(
  filters?: EnquiryFilterOptions
): Promise<{ enquiries: EnquiryWithVehicle[]; error?: string }> {
  const configured = isSupabaseConfigured();

  if (configured) {
    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        let query = supabase
          .from('enquiries')
          .select('*, vehicles(id, stock_id, make, model, variant, manufacturing_year, asking_price, slug, status, is_published)');

        if (filters?.status && filters.status !== 'ALL') {
          query = query.eq('status', filters.status);
        }

        if (filters?.type && filters.type !== 'ALL') {
          query = query.eq('enquiry_type', filters.type);
        }

        query = query.order('created_at', { ascending: false });

        const { data, error } = await query;
        if (error) {
          console.error('Supabase getAdminEnquiries error:', error);
          return { enquiries: [], error: error.message };
        }

        const enquiries: EnquiryWithVehicle[] = (data || []).map((raw) => {
          const row = raw as unknown as SupabaseEnquiryJoin;
          return {
            id: row.id,
            vehicle_id: row.vehicle_id,
            customer_name: row.customer_name,
            phone: row.phone,
            email: row.email,
            enquiry_type: row.enquiry_type,
            preferred_date: row.preferred_date,
            preferred_time: row.preferred_time,
            offer_amount: row.offer_amount,
            message: row.message,
            status: row.status,
            source: row.source,
            created_at: row.created_at,
            updated_at: row.updated_at,
            vehicle: row.vehicles || null,
          };
        });

        // Search filter in memory
        if (filters?.search && filters.search.trim() !== '') {
          const s = filters.search.toLowerCase().trim();
          return {
            enquiries: enquiries.filter(
              (e) =>
                e.customer_name.toLowerCase().includes(s) ||
                e.phone.toLowerCase().includes(s) ||
                (e.email && e.email.toLowerCase().includes(s)) ||
                (e.vehicle && e.vehicle.make.toLowerCase().includes(s)) ||
                (e.vehicle && e.vehicle.model.toLowerCase().includes(s)) ||
                (e.vehicle && e.vehicle.stock_id.toLowerCase().includes(s))
            ),
          };
        }

        return { enquiries };
      } catch (err: unknown) {
        console.warn('Fallback to local store for admin enquiries:', err);
      }
    }
  }

  // Local fallback
  let list = getLocalEnquiries();

  if (filters?.status && filters.status !== 'ALL') {
    list = list.filter((e) => e.status === filters.status);
  }

  if (filters?.type && filters.type !== 'ALL') {
    list = list.filter((e) => e.enquiry_type === filters.type);
  }

  if (filters?.search && filters.search.trim() !== '') {
    const s = filters.search.toLowerCase().trim();
    list = list.filter(
      (e) =>
        e.customer_name.toLowerCase().includes(s) ||
        e.phone.toLowerCase().includes(s) ||
        (e.email && e.email.toLowerCase().includes(s)) ||
        (e.vehicle && e.vehicle.make.toLowerCase().includes(s)) ||
        (e.vehicle && e.vehicle.model.toLowerCase().includes(s)) ||
        (e.vehicle && e.vehicle.stock_id.toLowerCase().includes(s))
    );
  }

  return { enquiries: list };
}

/**
 * Fetch a single enquiry record by ID with vehicle context (ADMIN only)
 */
export async function getAdminEnquiryById(
  id: string
): Promise<{ enquiry: EnquiryWithVehicle | null; error?: string }> {
  const configured = isSupabaseConfigured();

  if (configured) {
    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from('enquiries')
          .select('*, vehicles(id, stock_id, make, model, variant, manufacturing_year, asking_price, slug, status, is_published)')
          .eq('id', id)
          .maybeSingle();

        if (error || !data) {
          return { enquiry: null, error: error?.message || 'Enquiry record not found.' };
        }

        const joinData = data as unknown as SupabaseEnquiryJoin;
        const enquiry: EnquiryWithVehicle = {
          id: joinData.id,
          vehicle_id: joinData.vehicle_id,
          customer_name: joinData.customer_name,
          phone: joinData.phone,
          email: joinData.email,
          enquiry_type: joinData.enquiry_type,
          preferred_date: joinData.preferred_date,
          preferred_time: joinData.preferred_time,
          offer_amount: joinData.offer_amount,
          message: joinData.message,
          status: joinData.status,
          source: joinData.source,
          created_at: joinData.created_at,
          updated_at: joinData.updated_at,
          vehicle: joinData.vehicles || null,
        };

        return { enquiry };
      } catch (err: unknown) {
        console.warn('Fallback to local store for enquiry detail:', err);
      }
    }
  }

  // Local fallback
  const list = getLocalEnquiries();
  const match = list.find((e) => e.id === id);
  if (!match) {
    return { enquiry: null, error: `Enquiry record "${id}" not found.` };
  }

  return { enquiry: match };
}

/**
 * Update enquiry status (ADMIN only)
 * Transitions: NEW -> CONTACTED -> FOLLOW_UP -> CONVERTED -> CLOSED
 */
export async function updateAdminEnquiryStatus(
  id: string,
  newStatus: EnquiryStatus
): Promise<{ success: boolean; error?: string }> {
  // Validate status enum
  const validation = enquiryStatusSchema.safeParse(newStatus);
  if (!validation.success) {
    return { success: false, error: 'Invalid enquiry status value.' };
  }

  const configured = isSupabaseConfigured();

  if (configured) {
    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        const { error } = await supabase
          .from('enquiries')
          .update({
            status: newStatus,
            updated_at: new Date().toISOString(),
          })
          .eq('id', id);

        if (error) {
          console.error('Supabase updateAdminEnquiryStatus error:', error);
          return { success: false, error: error.message };
        }

        return { success: true };
      } catch (err: unknown) {
        console.warn('Fallback to local store for status update:', err);
      }
    }
  }

  // Local fallback
  const list = getLocalEnquiries();
  const index = list.findIndex((e) => e.id === id);
  if (index === -1) {
    return { success: false, error: 'Enquiry record not found.' };
  }

  list[index] = {
    ...list[index],
    status: newStatus,
    updated_at: new Date().toISOString(),
  };

  setLocalEnquiries(list);
  return { success: true };
}
