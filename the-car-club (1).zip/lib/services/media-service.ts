import { getSupabaseBrowserClient, isSupabaseConfigured } from '@/lib/supabase/client';
import { Database } from '@/types/database';
import { getLocalMedia, setLocalMedia } from './vehicle-service';

export type VehicleMedia = Database['public']['Tables']['vehicle_media']['Row'];
export type VehicleMediaType = Database['public']['Enums']['vehicle_media_type'];

export interface UploadMediaResult {
  media: (VehicleMedia & { publicUrl?: string }) | null;
  error?: string;
}

/**
 * Upload an image or video file for a vehicle
 * Stores in vehicle-images/{vehicle_id}/ or vehicle-videos/{vehicle_id}/
 */
export async function uploadVehicleMedia(
  vehicleId: string,
  file: File,
  mediaType: VehicleMediaType,
  altText?: string,
  isCover: boolean = false
): Promise<UploadMediaResult> {
  // Validate constraints
  if (isCover && mediaType === 'VIDEO') {
    return { media: null, error: 'Videos cannot be designated as a cover image.' };
  }

  // File size validation (15MB for images, 60MB for videos)
  const maxBytes = mediaType === 'IMAGE' ? 15 * 1024 * 1024 : 60 * 1024 * 1024;
  if (file.size > maxBytes) {
    const maxMb = maxBytes / (1024 * 1024);
    return {
      media: null,
      error: `File size exceeds the maximum permitted limit of ${maxMb}MB.`,
    };
  }

  const configured = isSupabaseConfigured();
  const bucketName = mediaType === 'VIDEO' ? 'vehicle-videos' : 'vehicle-images';

  // Sanitize filename and create unique path
  const sanitizedName = file.name.toLowerCase().replace(/[^a-z0-9.-]/g, '_');
  const uniquePrefix = `${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const storagePath = `${bucketName}/${vehicleId}/${uniquePrefix}_${sanitizedName}`;

  if (configured) {
    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        // 1. Upload to Supabase Storage
        const { error: uploadErr } = await supabase.storage
          .from(bucketName)
          .upload(`${vehicleId}/${uniquePrefix}_${sanitizedName}`, file, {
            cacheControl: '3600',
            upsert: false,
            contentType: file.type,
          });

        if (uploadErr) {
          console.error('Storage upload error:', uploadErr);
          return { media: null, error: uploadErr.message };
        }

        // 2. Determine sort order
        const { data: existingMedia } = await supabase
          .from('vehicle_media')
          .select('sort_order, is_cover')
          .eq('vehicle_id', vehicleId);

        const highestSort = (existingMedia || []).reduce(
          (max, m) => Math.max(max, m.sort_order),
          -1
        );
        const nextSortOrder = highestSort + 1;

        // 3. If setting as cover, clear any existing cover to satisfy unique partial index
        const shouldBeCover = isCover && mediaType === 'IMAGE';
        if (shouldBeCover) {
          await supabase
            .from('vehicle_media')
            .update({ is_cover: false })
            .eq('vehicle_id', vehicleId);
        }

        // If this is the very first image for the vehicle, automatically designate as cover
        const hasExistingCover = (existingMedia || []).some((m) => m.is_cover);
        const finalIsCover = shouldBeCover || (!hasExistingCover && mediaType === 'IMAGE');

        // 4. Insert row in vehicle_media
        const { data: inserted, error: insertErr } = await supabase
          .from('vehicle_media')
          .insert({
            vehicle_id: vehicleId,
            media_type: mediaType,
            storage_path: `${vehicleId}/${uniquePrefix}_${sanitizedName}`,
            sort_order: nextSortOrder,
            is_cover: finalIsCover,
            alt_text: altText ? altText.trim() : null,
          })
          .select()
          .single();

        if (insertErr) {
          console.error('Insert vehicle_media record error:', insertErr);
          return { media: null, error: insertErr.message };
        }

        const { data: urlData } = supabase.storage
          .from(bucketName)
          .getPublicUrl(`${vehicleId}/${uniquePrefix}_${sanitizedName}`);

        return {
          media: {
            ...inserted,
            publicUrl: urlData?.publicUrl || '',
          },
        };
      } catch (err: unknown) {
        console.warn('Fallback to local media upload:', err);
      }
    }
  }

  // Local Storage / Dev Preview fallback
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      const allMedia = getLocalMedia();
      const vehicleExisting = allMedia.filter((m) => m.vehicle_id === vehicleId);

      const highestSort = vehicleExisting.reduce(
        (max, m) => Math.max(max, m.sort_order),
        -1
      );
      const nextSortOrder = highestSort + 1;

      // Handle cover logic
      const hasExistingCover = vehicleExisting.some((m) => m.is_cover);
      const finalIsCover =
        (isCover && mediaType === 'IMAGE') || (!hasExistingCover && mediaType === 'IMAGE');

      if (finalIsCover) {
        allMedia.forEach((m) => {
          if (m.vehicle_id === vehicleId) m.is_cover = false;
        });
      }

      const newMedia: VehicleMedia = {
        id: crypto.randomUUID(),
        vehicle_id: vehicleId,
        media_type: mediaType,
        storage_path: dataUrl, // Stores clean data URL in preview
        sort_order: nextSortOrder,
        is_cover: finalIsCover,
        alt_text: altText ? altText.trim() : null,
        created_at: new Date().toISOString(),
      };

      allMedia.push(newMedia);
      setLocalMedia(allMedia);

      resolve({
        media: {
          ...newMedia,
          publicUrl: dataUrl,
        },
      });
    };

    reader.onerror = () => {
      resolve({ media: null, error: 'Failed to read media file.' });
    };

    reader.readAsDataURL(file);
  });
}

/**
 * Set an image as the exclusive cover image for a vehicle
 */
export async function setCoverImage(
  mediaId: string,
  vehicleId: string
): Promise<{ success: boolean; error?: string }> {
  const configured = isSupabaseConfigured();

  if (configured) {
    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        // Verify media item is an IMAGE
        const { data: item, error: itemErr } = await supabase
          .from('vehicle_media')
          .select('media_type')
          .eq('id', mediaId)
          .single();

        if (itemErr || !item) {
          return { success: false, error: 'Media record not found.' };
        }

        if (item.media_type !== 'IMAGE') {
          return { success: false, error: 'Only images can be set as the cover image.' };
        }

        // Unset any existing cover image for vehicle to satisfy DB partial index
        await supabase
          .from('vehicle_media')
          .update({ is_cover: false })
          .eq('vehicle_id', vehicleId);

        // Set target as cover
        const { error: updateErr } = await supabase
          .from('vehicle_media')
          .update({ is_cover: true })
          .eq('id', mediaId);

        if (updateErr) {
          return { success: false, error: updateErr.message };
        }

        return { success: true };
      } catch (err: unknown) {
        console.warn('Fallback to local setCoverImage:', err);
      }
    }
  }

  // Local fallback
  const allMedia = getLocalMedia();
  const target = allMedia.find((m) => m.id === mediaId);
  if (!target) {
    return { success: false, error: 'Media record not found.' };
  }

  if (target.media_type !== 'IMAGE') {
    return { success: false, error: 'Only images can be set as the cover image.' };
  }

  allMedia.forEach((m) => {
    if (m.vehicle_id === vehicleId) {
      m.is_cover = m.id === mediaId;
    }
  });

  setLocalMedia(allMedia);
  return { success: true };
}

/**
 * Reorder vehicle media by providing ordered list of media IDs
 */
export async function reorderVehicleMedia(
  vehicleId: string,
  orderedMediaIds: string[]
): Promise<{ success: boolean; error?: string }> {
  const configured = isSupabaseConfigured();

  if (configured) {
    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        // Update each item's sort_order sequentially
        for (let i = 0; i < orderedMediaIds.length; i++) {
          const id = orderedMediaIds[i];
          await supabase
            .from('vehicle_media')
            .update({ sort_order: i })
            .eq('id', id);
        }
        return { success: true };
      } catch (err: unknown) {
        console.warn('Fallback to local reorderVehicleMedia:', err);
      }
    }
  }

  // Local fallback
  const allMedia = getLocalMedia();
  allMedia.forEach((m) => {
    if (m.vehicle_id === vehicleId) {
      const idx = orderedMediaIds.indexOf(m.id);
      if (idx !== -1) {
        m.sort_order = idx;
      }
    }
  });

  setLocalMedia(allMedia);
  return { success: true };
}

/**
 * Delete a media item and remove from storage
 */
export async function deleteVehicleMedia(
  mediaId: string,
  vehicleId: string
): Promise<{ success: boolean; error?: string }> {
  const configured = isSupabaseConfigured();

  if (configured) {
    const supabase = getSupabaseBrowserClient();
    if (supabase) {
      try {
        // Check if vehicle is published and this is the only IMAGE
        const { data: vehicle } = await supabase
          .from('vehicles')
          .select('is_published')
          .eq('id', vehicleId)
          .single();

        const { data: mediaItem } = await supabase
          .from('vehicle_media')
          .select('*')
          .eq('id', mediaId)
          .single();

        if (!mediaItem) {
          return { success: false, error: 'Media record not found.' };
        }

        if (vehicle?.is_published && mediaItem.media_type === 'IMAGE') {
          const { count } = await supabase
            .from('vehicle_media')
            .select('*', { count: 'exact', head: true })
            .eq('vehicle_id', vehicleId)
            .eq('media_type', 'IMAGE');

          if (count !== null && count <= 1) {
            return {
              success: false,
              error:
                'Cannot delete the only image of an active published vehicle. Unpublish the vehicle first or upload an alternate image.',
            };
          }
        }

        // Remove from storage bucket
        const bucket = mediaItem.media_type === 'VIDEO' ? 'vehicle-videos' : 'vehicle-images';
        await supabase.storage.from(bucket).remove([mediaItem.storage_path]);

        // Delete row
        const { error: deleteErr } = await supabase
          .from('vehicle_media')
          .delete()
          .eq('id', mediaId);

        if (deleteErr) {
          return { success: false, error: deleteErr.message };
        }

        // If the deleted media was the cover, automatically promote the first remaining image
        if (mediaItem.is_cover) {
          const { data: remainingImages } = await supabase
            .from('vehicle_media')
            .select('id')
            .eq('vehicle_id', vehicleId)
            .eq('media_type', 'IMAGE')
            .order('sort_order', { ascending: true })
            .limit(1);

          if (remainingImages && remainingImages.length > 0) {
            await supabase
              .from('vehicle_media')
              .update({ is_cover: true })
              .eq('id', remainingImages[0].id);
          }
        }

        return { success: true };
      } catch (err: unknown) {
        console.warn('Fallback to local deleteVehicleMedia:', err);
      }
    }
  }

  // Local fallback
  const allMedia = getLocalMedia();
  const target = allMedia.find((m) => m.id === mediaId);
  if (!target) {
    return { success: false, error: 'Media record not found.' };
  }

  // Publishing integrity safeguard
  const remainingImages = allMedia.filter(
    (m) => m.vehicle_id === vehicleId && m.id !== mediaId && m.media_type === 'IMAGE'
  );

  const updatedMedia = allMedia.filter((m) => m.id !== mediaId);

  // If deleted target was cover, promote next image
  if (target.is_cover && remainingImages.length > 0) {
    const nextCover = updatedMedia.find((m) => m.id === remainingImages[0].id);
    if (nextCover) nextCover.is_cover = true;
  }

  setLocalMedia(updatedMedia);
  return { success: true };
}
