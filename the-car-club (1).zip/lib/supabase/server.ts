import { createServerClient } from '@supabase/ssr';
import { Database } from '@/types/database';

/**
 * Server-side Supabase client factory for Server Actions & Route Handlers using @supabase/ssr.
 * Cookies can be passed from next/headers.
 */
export function createSupabaseServerClient(
  cookieStore?: {
    getAll?: () => Array<{ name: string; value: string }>;
    get?: (name: string) => { value: string } | undefined;
    set?: (name: string, value: string, options?: Record<string, unknown>) => void;
  }
) {
  const supabaseUrl =
    (typeof process !== 'undefined' && process.env?.NEXT_PUBLIC_SUPABASE_URL) || '';
  const supabaseAnonKey =
    (typeof process !== 'undefined' && (process.env?.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env?.NEXT_PUBLIC_SUPABASE_ANON_KEY)) || '';

  if (!supabaseUrl || !supabaseAnonKey) {
    return null;
  }

  return createServerClient<Database>(supabaseUrl, supabaseAnonKey, {
    cookies: {
      getAll() {
        if (cookieStore?.getAll) {
          return cookieStore.getAll();
        }
        return [];
      },
      setAll(cookiesToSet) {
        if (cookieStore?.set) {
          cookiesToSet.forEach(({ name, value, options }) => {
            cookieStore.set?.(name, value, options);
          });
        }
      },
    },
  });
}
