import { createServerClient } from '@supabase/ssr';
import { Database } from '@/types/database';

/**
 * Session verification and refresh helper for Next.js App Router middleware.
 * Verifies session and database-backed ADMIN profile authorization.
 */
export async function updateSession(request: {
  headers: Headers;
  url: string;
  cookies?: {
    get: (name: string) => { value: string } | undefined;
    set: (name: string, value: string, options?: Record<string, unknown>) => void;
    getAll?: () => Array<{ name: string; value: string }>;
  };
}) {
  const supabaseUrl =
    (typeof process !== 'undefined' && process.env?.NEXT_PUBLIC_SUPABASE_URL) || '';
  const supabaseAnonKey =
    (typeof process !== 'undefined' && (process.env?.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env?.NEXT_PUBLIC_SUPABASE_ANON_KEY)) || '';

  if (!supabaseUrl || !supabaseAnonKey) {
    return {
      authenticated: false,
      isAdmin: false,
      user: null,
      profile: null,
    };
  }

  const supabase = createServerClient<Database>(supabaseUrl, supabaseAnonKey, {
    cookies: {
      getAll() {
        return request.cookies?.getAll ? request.cookies.getAll() : [];
      },
      setAll(cookiesToSet) {
        if (request.cookies?.set) {
          cookiesToSet.forEach(({ name, value, options }) => {
            request.cookies?.set(name, value, options);
          });
        }
      },
    },
  });

  // Authoritatively get user using getUser() (secure on server)
  const { data: { user }, error: userError } = await supabase.auth.getUser();

  if (userError || !user) {
    return {
      authenticated: false,
      isAdmin: false,
      user: null,
      profile: null,
    };
  }

  // Authoritative database check on profiles table
  const { data: profile } = await supabase
    .from('profiles')
    .select('id, full_name, role')
    .eq('id', user.id)
    .maybeSingle();

  const isAdmin = Boolean(profile && profile.role === 'ADMIN');

  return {
    authenticated: true,
    isAdmin,
    user,
    profile,
  };
}
