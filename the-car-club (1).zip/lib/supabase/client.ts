import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Database } from '@/types/database';

let supabaseBrowserClient: SupabaseClient<Database> | null = null;

interface ViteEnv {
  VITE_SUPABASE_URL?: string;
  VITE_SUPABASE_ANON_KEY?: string;
  VITE_SUPABASE_PUBLISHABLE_KEY?: string;
  [key: string]: string | boolean | undefined;
}

function getEnvVar(viteKey: keyof ViteEnv, nextKey: string): string {
  const nextVal = typeof process !== 'undefined' ? process.env?.[nextKey] : undefined;
  const metaEnv = typeof import.meta !== 'undefined' ? (import.meta as unknown as { env?: ViteEnv }).env : undefined;
  const viteVal = metaEnv?.[viteKey];
  return (typeof nextVal === 'string' && nextVal) || (typeof viteVal === 'string' && viteVal) || '';
}

/**
 * Creates or retrieves the singleton client-side Supabase client.
 * Safe fallback if environment variables are not yet configured.
 */
export function getSupabaseBrowserClient(): SupabaseClient<Database> | null {
  if (supabaseBrowserClient) {
    return supabaseBrowserClient;
  }

  const supabaseUrl = getEnvVar('VITE_SUPABASE_URL', 'NEXT_PUBLIC_SUPABASE_URL');
  const supabaseAnonKey =
    getEnvVar('VITE_SUPABASE_ANON_KEY', 'NEXT_PUBLIC_SUPABASE_ANON_KEY') ||
    getEnvVar('VITE_SUPABASE_PUBLISHABLE_KEY', 'NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY');

  if (!supabaseUrl || !supabaseAnonKey) {
    // Return null in development when credentials are not yet supplied
    return null;
  }

  supabaseBrowserClient = createClient<Database>(supabaseUrl, supabaseAnonKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
  });
  return supabaseBrowserClient;
}

export const isSupabaseConfigured = (): boolean => {
  const url = getEnvVar('VITE_SUPABASE_URL', 'NEXT_PUBLIC_SUPABASE_URL');
  const key =
    getEnvVar('VITE_SUPABASE_ANON_KEY', 'NEXT_PUBLIC_SUPABASE_ANON_KEY') ||
    getEnvVar('VITE_SUPABASE_PUBLISHABLE_KEY', 'NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY');
  return Boolean(url && key);
};
