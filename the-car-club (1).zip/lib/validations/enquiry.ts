import { z } from 'zod';

export const enquiryTypes = [
  'VEHICLE',
  'TEST_DRIVE',
  'CALLBACK',
  'OFFER',
  'GENERAL',
] as const;

export const enquiryStatuses = [
  'NEW',
  'CONTACTED',
  'FOLLOW_UP',
  'CONVERTED',
  'CLOSED',
] as const;

export const enquirySources = [
  'WEBSITE',
  'WHATSAPP',
  'PHONE',
  'INSTAGRAM',
  'FACEBOOK',
  'GOOGLE',
  'OTHER',
] as const;

export const enquiryTypeSchema = z.enum(enquiryTypes);
export const enquiryStatusSchema = z.enum(enquiryStatuses);
export const enquirySourceSchema = z.enum(enquirySources);

export type EnquiryType = (typeof enquiryTypes)[number];
export type EnquiryStatus = (typeof enquiryStatuses)[number];
export type EnquirySource = (typeof enquirySources)[number];

/**
 * Public customer enquiry submission schema
 * Enforces business rules:
 * - TEST_DRIVE requires preferred_date
 * - OFFER requires offer_amount > 0
 */
export const publicEnquirySchema = z
  .object({
    customer_name: z
      .string()
      .trim()
      .min(2, 'Full name must be at least 2 characters')
      .max(100, 'Name cannot exceed 100 characters'),
    phone: z
      .string()
      .trim()
      .min(7, 'Please provide a valid contact phone number')
      .max(25, 'Phone number is too long')
      .regex(/^[+0-9\s\-()]+$/, 'Phone number format is invalid'),
    email: z
      .string()
      .trim()
      .email('Please provide a valid email address')
      .optional()
      .or(z.literal('')),
    enquiry_type: enquiryTypeSchema,
    vehicle_id: z.string().uuid('Invalid vehicle identifier').optional().nullable(),
    preferred_date: z
      .string()
      .trim()
      .regex(/^\d{4}-\d{2}-\d{2}$/, 'Date format must be YYYY-MM-DD')
      .optional()
      .nullable()
      .or(z.literal('')),
    preferred_time: z
      .string()
      .trim()
      .max(10)
      .optional()
      .nullable()
      .or(z.literal('')),
    offer_amount: z
      .number()
      .positive('Offer amount must be greater than zero')
      .optional()
      .nullable(),
    message: z
      .string()
      .trim()
      .max(2000, 'Message cannot exceed 2000 characters')
      .optional()
      .nullable()
      .or(z.literal('')),
  })
  .refine(
    (data) => {
      if (data.enquiry_type === 'TEST_DRIVE') {
        return Boolean(data.preferred_date && data.preferred_date.trim() !== '');
      }
      return true;
    },
    {
      message: 'A preferred date is required for test-drive requests',
      path: ['preferred_date'],
    }
  )
  .refine(
    (data) => {
      if (data.enquiry_type === 'OFFER') {
        return Boolean(data.offer_amount && data.offer_amount > 0);
      }
      return true;
    },
    {
      message: 'A positive offer amount is required for purchase proposals',
      path: ['offer_amount'],
    }
  );

export type PublicEnquiryInput = z.infer<typeof publicEnquirySchema>;

/**
 * Admin status transition schema
 */
export const adminEnquiryStatusUpdateSchema = z.object({
  status: enquiryStatusSchema,
});

export type AdminEnquiryStatusUpdateInput = z.infer<
  typeof adminEnquiryStatusUpdateSchema
>;

/**
 * Backward compatibility alias for existing imports
 */
export const enquirySchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').max(100),
  email: z.string().email('Please enter a valid email address').optional().or(z.literal('')),
  phone: z.string().min(6, 'Please enter a valid contact phone number').max(25),
  message: z.string().min(5, 'Message must be at least 5 characters').max(2000).optional().or(z.literal('')),
});

export type EnquiryFormValues = z.infer<typeof enquirySchema>;
