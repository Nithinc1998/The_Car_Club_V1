import { z } from 'zod';

export const loginSchema = z.object({
  email: z.string().email('Please enter a valid administrative email'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
});

export type LoginFormValues = z.infer<typeof loginSchema>;

export const firstAdminSetupSchema = z.object({
  fullName: z.string().min(2, 'Full name must be at least 2 characters'),
  email: z.string().email('Please enter a valid administrative email'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
});

export type FirstAdminSetupFormValues = z.infer<typeof firstAdminSetupSchema>;

