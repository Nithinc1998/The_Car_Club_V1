import { z } from 'zod';

export const vehicleFuelTypes = [
  'PETROL',
  'DIESEL',
  'CNG',
  'ELECTRIC',
  'HYBRID',
  'OTHER',
] as const;

export const vehicleTransmissions = [
  'MANUAL',
  'AUTOMATIC',
  'AMT',
  'CVT',
  'DCT',
  'IMT',
  'OTHER',
] as const;

export const vehicleConditions = ['EXCELLENT', 'GOOD', 'FAIR'] as const;

export const serviceHistoryStatuses = [
  'FULL',
  'PARTIAL',
  'NOT_AVAILABLE',
  'UNKNOWN',
] as const;

export const vehicleStatuses = [
  'DRAFT',
  'AVAILABLE',
  'RESERVED',
  'SOLD',
  'ARCHIVED',
] as const;

export const vehicleMediaTypes = ['IMAGE', 'VIDEO'] as const;

export const vehicleEventTypes = [
  'ACQUIRED',
  'INSPECTION',
  'PRICING_UPDATED',
  'PUBLISHED',
  'UNPUBLISHED',
  'RESERVED',
  'RESERVATION_CANCELLED',
  'SOLD',
  'ARCHIVED',
  'NOTE',
] as const;

export const vehicleFuelTypeSchema = z.enum(vehicleFuelTypes);
export const vehicleTransmissionSchema = z.enum(vehicleTransmissions);
export const vehicleConditionSchema = z.enum(vehicleConditions);
export const serviceHistoryStatusSchema = z.enum(serviceHistoryStatuses);
export const vehicleStatusSchema = z.enum(vehicleStatuses);
export const vehicleMediaTypeSchema = z.enum(vehicleMediaTypes);
export const vehicleEventTypeSchema = z.enum(vehicleEventTypes);

export type VehicleFuelType = z.infer<typeof vehicleFuelTypeSchema>;
export type VehicleTransmission = z.infer<typeof vehicleTransmissionSchema>;
export type VehicleCondition = z.infer<typeof vehicleConditionSchema>;
export type ServiceHistoryStatus = z.infer<typeof serviceHistoryStatusSchema>;

const currentYear = new Date().getFullYear();

/**
 * Authoritative Zod schema matching database constraints in 00005_create_vehicles.sql
 */
export const vehicleSchema = z
  .object({
    make: z
      .string()
      .trim()
      .min(1, 'Make is required')
      .max(50, 'Make cannot exceed 50 characters'),
    model: z
      .string()
      .trim()
      .min(1, 'Model is required')
      .max(50, 'Model cannot exceed 50 characters'),
    variant: z.string().trim().max(50).optional().nullable(),
    slug: z
      .string()
      .trim()
      .min(2, 'Slug must be at least 2 characters')
      .max(100, 'Slug cannot exceed 100 characters')
      .regex(
        /^[a-z0-9]+(?:-[a-z0-9]+)*$/,
        'Slug must consist of lowercase letters, numbers, and single hyphens'
      ),
    registration_number: z.string().trim().max(20).optional().nullable(),
    manufacturing_year: z
      .number()
      .int('Manufacturing year must be a whole year')
      .min(1900, 'Manufacturing year cannot be before 1900')
      .max(2100, 'Manufacturing year cannot be beyond 2100'),
    registration_year: z
      .number()
      .int()
      .min(1900)
      .max(2100)
      .optional()
      .nullable(),
    fuel_type: vehicleFuelTypeSchema,
    transmission: vehicleTransmissionSchema,
    kilometers: z
      .number()
      .int()
      .min(0, 'Kilometers cannot be negative'),
    owners: z
      .number()
      .int()
      .min(0, 'Owners cannot be negative'),
    color: z.string().trim().max(50).optional().nullable(),
    asking_price: z
      .number()
      .positive('Asking price must be greater than zero'),
    purchase_price: z
      .number()
      .min(0, 'Purchase price cannot be negative')
      .optional()
      .nullable(),
    condition: vehicleConditionSchema.optional().nullable(),
    condition_notes: z.string().trim().max(2000).optional().nullable(),
    service_history: serviceHistoryStatusSchema.optional().nullable(),
    service_history_notes: z.string().trim().max(2000).optional().nullable(),
    inspection_notes: z.string().trim().max(2000).optional().nullable(),
    features: z.array(z.string()).default([]),
    accessories: z.array(z.string()).default([]),
    short_description: z.string().trim().max(250).optional().nullable(),
    description: z.string().trim().max(5000).optional().nullable(),
    status: vehicleStatusSchema.default('DRAFT'),
    is_published: z.boolean().default(false),
  })
  .refine(
    (data) => {
      if (
        data.registration_year !== undefined &&
        data.registration_year !== null &&
        data.registration_year !== 0
      ) {
        return data.registration_year >= data.manufacturing_year;
      }
      return true;
    },
    {
      message: 'Registration year cannot be earlier than manufacturing year',
      path: ['registration_year'],
    }
  );

export type VehicleFormValues = z.infer<typeof vehicleSchema>;

/**
 * Media specification validation
 */
export const vehicleMediaSchema = z
  .object({
    vehicle_id: z.string().uuid('Invalid vehicle ID'),
    media_type: vehicleMediaTypeSchema,
    storage_path: z.string().min(1, 'Storage path is required'),
    sort_order: z.number().int().min(0, 'Sort order cannot be negative').default(0),
    is_cover: z.boolean().default(false),
    alt_text: z.string().trim().max(255).optional().nullable(),
  })
  .refine(
    (data) => {
      // Database constraint: vehicle_media_cover_image_only
      if (data.is_cover && data.media_type === 'VIDEO') {
        return false;
      }
      return true;
    },
    {
      message: 'Only images can be designated as the cover image',
      path: ['is_cover'],
    }
  );

export type VehicleMediaFormValues = z.infer<typeof vehicleMediaSchema>;

/**
 * Vehicle Event schema
 */
export const vehicleEventSchema = z.object({
  vehicle_id: z.string().uuid(),
  event_type: vehicleEventTypeSchema,
  notes: z.string().trim().max(1000).optional().nullable(),
  created_by: z.string().uuid().optional().nullable(),
});

export type VehicleEventFormValues = z.infer<typeof vehicleEventSchema>;
export type VehicleStatus = (typeof vehicleStatuses)[number];

/**
 * Helper to validate vehicle publishing integrity (mirrors DB trigger check_vehicle_publishing_requirements)
 */
export function validatePublishingIntegrity(
  vehicle: Partial<VehicleFormValues>,
  imageCount: number
): { valid: boolean; reason?: string } {
  if (!vehicle.make || vehicle.make.trim() === '') {
    return { valid: false, reason: 'Make is required to publish.' };
  }
  if (!vehicle.model || vehicle.model.trim() === '') {
    return { valid: false, reason: 'Model is required to publish.' };
  }
  if (!vehicle.manufacturing_year || vehicle.manufacturing_year < 1900) {
    return { valid: false, reason: 'Valid manufacturing year is required to publish.' };
  }
  if (!vehicle.fuel_type) {
    return { valid: false, reason: 'Fuel type is required to publish.' };
  }
  if (!vehicle.transmission) {
    return { valid: false, reason: 'Transmission is required to publish.' };
  }
  if (vehicle.kilometers === undefined || vehicle.kilometers === null || vehicle.kilometers < 0) {
    return { valid: false, reason: 'Kilometers reading is required to publish.' };
  }
  if (!vehicle.asking_price || vehicle.asking_price <= 0) {
    return { valid: false, reason: 'Asking price must be greater than zero to publish.' };
  }
  if (imageCount < 1) {
    return {
      valid: false,
      reason: 'Vehicle cannot be published: Must have at least one media record of type IMAGE.',
    };
  }
  return { valid: true };
}
