export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          full_name: string;
          role: Database['public']['Enums']['profile_role'];
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          full_name: string;
          role?: Database['public']['Enums']['profile_role'];
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          full_name?: string;
          role?: Database['public']['Enums']['profile_role'];
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      settings: {
        Row: {
          id: string;
          is_singleton: boolean;
          dealership_name: string;
          phone: string | null;
          whatsapp_number: string | null;
          email: string | null;
          address: string | null;
          city: string | null;
          district: string | null;
          state: string | null;
          pincode: string | null;
          opening_hours: string | null;
          google_maps_url: string | null;
          instagram_url: string | null;
          facebook_url: string | null;
          youtube_url: string | null;
          logo_url: string | null;
          favicon_url: string | null;
          site_title: string | null;
          meta_description: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          is_singleton?: boolean;
          dealership_name: string;
          phone?: string | null;
          whatsapp_number?: string | null;
          email?: string | null;
          address?: string | null;
          city?: string | null;
          district?: string | null;
          state?: string | null;
          pincode?: string | null;
          opening_hours?: string | null;
          google_maps_url?: string | null;
          instagram_url?: string | null;
          facebook_url?: string | null;
          youtube_url?: string | null;
          logo_url?: string | null;
          favicon_url?: string | null;
          site_title?: string | null;
          meta_description?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          is_singleton?: boolean;
          dealership_name?: string;
          phone?: string | null;
          whatsapp_number?: string | null;
          email?: string | null;
          address?: string | null;
          city?: string | null;
          district?: string | null;
          state?: string | null;
          pincode?: string | null;
          opening_hours?: string | null;
          google_maps_url?: string | null;
          instagram_url?: string | null;
          facebook_url?: string | null;
          youtube_url?: string | null;
          logo_url?: string | null;
          favicon_url?: string | null;
          site_title?: string | null;
          meta_description?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      vehicles: {
        Row: {
          id: string;
          stock_id: string;
          registration_number: string | null;
          make: string;
          model: string;
          variant: string | null;
          slug: string;
          manufacturing_year: number;
          registration_year: number | null;
          fuel_type: Database['public']['Enums']['vehicle_fuel_type'];
          transmission: Database['public']['Enums']['vehicle_transmission'];
          kilometers: number;
          owners: number;
          color: string | null;
          asking_price: number;
          purchase_price: number | null;
          condition: Database['public']['Enums']['vehicle_condition'] | null;
          condition_notes: string | null;
          service_history: Database['public']['Enums']['service_history_status'] | null;
          service_history_notes: string | null;
          inspection_notes: string | null;
          features: Json;
          accessories: Json;
          short_description: string | null;
          description: string | null;
          status: Database['public']['Enums']['vehicle_status'];
          is_published: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          stock_id?: string;
          registration_number?: string | null;
          make: string;
          model: string;
          variant?: string | null;
          slug: string;
          manufacturing_year: number;
          registration_year?: number | null;
          fuel_type: Database['public']['Enums']['vehicle_fuel_type'];
          transmission: Database['public']['Enums']['vehicle_transmission'];
          kilometers: number;
          owners: number;
          color?: string | null;
          asking_price: number;
          purchase_price?: number | null;
          condition?: Database['public']['Enums']['vehicle_condition'] | null;
          condition_notes?: string | null;
          service_history?: Database['public']['Enums']['service_history_status'] | null;
          service_history_notes?: string | null;
          inspection_notes?: string | null;
          features?: Json;
          accessories?: Json;
          short_description?: string | null;
          description?: string | null;
          status?: Database['public']['Enums']['vehicle_status'];
          is_published?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          stock_id?: string;
          registration_number?: string | null;
          make?: string;
          model?: string;
          variant?: string | null;
          slug?: string;
          manufacturing_year?: number;
          registration_year?: number | null;
          fuel_type?: Database['public']['Enums']['vehicle_fuel_type'];
          transmission?: Database['public']['Enums']['vehicle_transmission'];
          kilometers?: number;
          owners?: number;
          color?: string | null;
          asking_price?: number;
          purchase_price?: number | null;
          condition?: Database['public']['Enums']['vehicle_condition'] | null;
          condition_notes?: string | null;
          service_history?: Database['public']['Enums']['service_history_status'] | null;
          service_history_notes?: string | null;
          inspection_notes?: string | null;
          features?: Json;
          accessories?: Json;
          short_description?: string | null;
          description?: string | null;
          status?: Database['public']['Enums']['vehicle_status'];
          is_published?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      vehicle_media: {
        Row: {
          id: string;
          vehicle_id: string;
          media_type: Database['public']['Enums']['vehicle_media_type'];
          storage_path: string;
          sort_order: number;
          is_cover: boolean;
          alt_text: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          vehicle_id: string;
          media_type: Database['public']['Enums']['vehicle_media_type'];
          storage_path: string;
          sort_order?: number;
          is_cover?: boolean;
          alt_text?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          vehicle_id?: string;
          media_type?: Database['public']['Enums']['vehicle_media_type'];
          storage_path?: string;
          sort_order?: number;
          is_cover?: boolean;
          alt_text?: string | null;
          created_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: 'vehicle_media_vehicle_id_fkey';
            columns: ['vehicle_id'];
            referencedRelation: 'vehicles';
            referencedColumns: ['id'];
          }
        ];
      };
      vehicle_events: {
        Row: {
          id: string;
          vehicle_id: string;
          event_type: Database['public']['Enums']['vehicle_event_type'];
          notes: string | null;
          created_by: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          vehicle_id: string;
          event_type: Database['public']['Enums']['vehicle_event_type'];
          notes?: string | null;
          created_by?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          vehicle_id?: string;
          event_type?: Database['public']['Enums']['vehicle_event_type'];
          notes?: string | null;
          created_by?: string | null;
          created_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: 'vehicle_events_vehicle_id_fkey';
            columns: ['vehicle_id'];
            referencedRelation: 'vehicles';
            referencedColumns: ['id'];
          },
          {
            foreignKeyName: 'vehicle_events_created_by_fkey';
            columns: ['created_by'];
            referencedRelation: 'profiles';
            referencedColumns: ['id'];
          }
        ];
      };
      enquiries: {
        Row: {
          id: string;
          vehicle_id: string | null;
          customer_name: string;
          phone: string;
          email: string | null;
          enquiry_type: Database['public']['Enums']['enquiry_type'];
          preferred_date: string | null;
          preferred_time: string | null;
          offer_amount: number | null;
          message: string | null;
          status: Database['public']['Enums']['enquiry_status'];
          source: Database['public']['Enums']['enquiry_source'];
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          vehicle_id?: string | null;
          customer_name: string;
          phone: string;
          email?: string | null;
          enquiry_type?: Database['public']['Enums']['enquiry_type'];
          preferred_date?: string | null;
          preferred_time?: string | null;
          offer_amount?: number | null;
          message?: string | null;
          status?: Database['public']['Enums']['enquiry_status'];
          source?: Database['public']['Enums']['enquiry_source'];
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          vehicle_id?: string | null;
          customer_name?: string;
          phone?: string;
          email?: string | null;
          enquiry_type?: Database['public']['Enums']['enquiry_type'];
          preferred_date?: string | null;
          preferred_time?: string | null;
          offer_amount?: number | null;
          message?: string | null;
          status?: Database['public']['Enums']['enquiry_status'];
          source?: Database['public']['Enums']['enquiry_source'];
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: 'enquiries_vehicle_id_fkey';
            columns: ['vehicle_id'];
            referencedRelation: 'vehicles';
            referencedColumns: ['id'];
          }
        ];
      };
    };
    Views: {
      public_vehicles: {
        Row: {
          id: string;
          stock_id: string;
          registration_number: string | null;
          make: string;
          model: string;
          variant: string | null;
          slug: string;
          manufacturing_year: number;
          registration_year: number | null;
          fuel_type: Database['public']['Enums']['vehicle_fuel_type'];
          transmission: Database['public']['Enums']['vehicle_transmission'];
          kilometers: number;
          owners: number;
          color: string | null;
          asking_price: number;
          condition: Database['public']['Enums']['vehicle_condition'] | null;
          condition_notes: string | null;
          service_history: Database['public']['Enums']['service_history_status'] | null;
          service_history_notes: string | null;
          inspection_notes: string | null;
          features: Json;
          accessories: Json;
          short_description: string | null;
          description: string | null;
          status: Database['public']['Enums']['vehicle_status'];
          is_published: boolean;
          created_at: string;
          updated_at: string;
        };
        Relationships: [];
      };
    };
    Functions: {
      is_admin: {
        Args: Record<string, never>;
        Returns: boolean;
      };
      count_admin_profiles: {
        Args: Record<string, never>;
        Returns: number;
      };
      initialize_first_admin: {
        Args: {
          admin_full_name: string;
        };
        Returns: boolean;
      };
    };
    Enums: {
      vehicle_fuel_type:
        | 'PETROL'
        | 'DIESEL'
        | 'CNG'
        | 'ELECTRIC'
        | 'HYBRID'
        | 'OTHER';
      vehicle_transmission:
        | 'MANUAL'
        | 'AUTOMATIC'
        | 'AMT'
        | 'CVT'
        | 'DCT'
        | 'IMT'
        | 'OTHER';
      vehicle_condition: 'EXCELLENT' | 'GOOD' | 'FAIR';
      service_history_status:
        | 'FULL'
        | 'PARTIAL'
        | 'NOT_AVAILABLE'
        | 'UNKNOWN';
      rc_status:
        | 'AVAILABLE'
        | 'TRANSFER_PENDING'
        | 'TRANSFERRED'
        | 'NOT_AVAILABLE'
        | 'OTHER';
      vehicle_status:
        | 'DRAFT'
        | 'AVAILABLE'
        | 'RESERVED'
        | 'SOLD'
        | 'ARCHIVED';
      vehicle_media_type: 'IMAGE' | 'VIDEO';
      vehicle_event_type:
        | 'ACQUIRED'
        | 'INSPECTION'
        | 'PRICING_UPDATED'
        | 'PUBLISHED'
        | 'UNPUBLISHED'
        | 'RESERVED'
        | 'RESERVATION_CANCELLED'
        | 'SOLD'
        | 'ARCHIVED'
        | 'NOTE';
      enquiry_type:
        | 'VEHICLE'
        | 'TEST_DRIVE'
        | 'CALLBACK'
        | 'OFFER'
        | 'GENERAL';
      enquiry_status:
        | 'NEW'
        | 'CONTACTED'
        | 'FOLLOW_UP'
        | 'CONVERTED'
        | 'CLOSED';
      enquiry_source:
        | 'WEBSITE'
        | 'WHATSAPP'
        | 'PHONE'
        | 'INSTAGRAM'
        | 'FACEBOOK'
        | 'GOOGLE'
        | 'OTHER';
      profile_role: 'ADMIN';
    };
  };
}

// -------------------------------------------------------------
// SECTION 35: APPLICATION / DOMAIN TYPES
// Derived strictly from the Database interface for client usage.
// -------------------------------------------------------------

export type PublicVehicle = Database['public']['Views']['public_vehicles']['Row'];

export interface VehicleCard {
  id: string;
  stock_id: string;
  slug: string;
  make: string;
  model: string;
  variant: string | null;
  manufacturing_year: number;
  kilometers: number;
  asking_price: number;
  fuel_type: Database['public']['Enums']['vehicle_fuel_type'];
  transmission: Database['public']['Enums']['vehicle_transmission'];
  cover_image_url?: string;
  status: Database['public']['Enums']['vehicle_status'];
}

export interface EnquirySummary {
  id: string;
  customer_name: string;
  phone: string;
  email: string | null;
  enquiry_type: Database['public']['Enums']['enquiry_type'];
  status: Database['public']['Enums']['enquiry_status'];
  created_at: string;
  vehicle_summary?: {
    make: string;
    model: string;
    stock_id: string;
  } | null;
}
