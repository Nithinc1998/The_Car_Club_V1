import { Database } from './database';

export type Vehicle = Database['public']['Tables']['vehicles']['Row'];
export type VehicleInsert = Database['public']['Tables']['vehicles']['Insert'];
export type VehicleUpdate = Database['public']['Tables']['vehicles']['Update'];

export type VehicleStatus = Database['public']['Enums']['vehicle_status'];
export type VehicleFuelType = Database['public']['Enums']['vehicle_fuel_type'];
export type VehicleTransmission = Database['public']['Enums']['vehicle_transmission'];
export type VehicleCondition = Database['public']['Enums']['vehicle_condition'];

export type VehicleMedia = Database['public']['Tables']['vehicle_media']['Row'];
export type VehicleEvent = Database['public']['Tables']['vehicle_events']['Row'];

export interface VehicleFilterState {
  search: string;
  make: string;
  minPrice?: number;
  maxPrice?: number;
  minYear?: number;
  maxYear?: number;
  transmission?: string;
  status?: VehicleStatus;
}
