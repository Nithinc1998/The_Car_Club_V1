import { Database } from './database';

export type Enquiry = Database['public']['Tables']['enquiries']['Row'];
export type EnquiryInsert = Database['public']['Tables']['enquiries']['Insert'];
export type EnquiryUpdate = Database['public']['Tables']['enquiries']['Update'];

export type EnquiryStatus = Database['public']['Enums']['enquiry_status'];
export type EnquiryType = Database['public']['Enums']['enquiry_type'];
export type EnquirySource = Database['public']['Enums']['enquiry_source'];
