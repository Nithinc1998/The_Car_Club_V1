# The Car Club — Curated Pre-Owned Automotive Dealership Platform

A modern, minimal, premium automotive dealership platform engineered for single-showroom operations in Palakkad, Kerala, India.

## 1. Overview & Business Model

* **Business Identity:** The Car Club (Single-showroom used-car dealership, Palakkad, Kerala)
* **Core Product Scope (V1):**
  * Public Vehicle Catalog & Inventory Showcase (`/cars`, `/cars/[slug]`)
  * Frictionless Customer Enquiries (`VEHICLE`, `TEST_DRIVE`, `CALLBACK`, `OFFER`, `GENERAL`)
  * Dealership Management Back-Office & Operations Dashboard (`/admin`, `/admin/vehicles`, `/admin/enquiries`, `/admin/settings`)
  * Authoritative Administrative Access Control (Database-backed `ADMIN` profile verification)
* **Explicit Exclusions:** Online checkout/purchasing, finance/EMI calculator, multi-branch ERP, auction engines, automated DMS.

## 2. Approved Technology Stack & Architecture

* **Application Runtime:** Vite + React 19 + TypeScript + Tailwind CSS
* **Type Safety:** Strict TypeScript (`strict: true`, zero `any`, Zod schemas)
* **Database & Auth:** Supabase PostgreSQL with Row Level Security (RLS) and client/server adapters with full development preview fallback
* **Iconography:** Lucide Icons (`lucide-react`)
* **SEO & Metadata:** Schema.org `AutoDealer` structured data, OpenGraph, Twitter Cards, SVG brand favicon

## 3. Route Map

### Public Routes
* `/` — Brand landing page, Palakkad showroom standards, featured curation
* `/cars` — Public inventory catalog with text search, specifications, asking prices
* `/cars/[slug]` — Vehicle profile, multi-angle gallery, specifications, private enquiry modal/forms
* `/about` — Heritage, curation philosophy, multi-point verification standards
* `/contact` — Showroom location, viewing hours, concierge callback / inquiry form

### Admin Routes (Authoritative Authentication Required)
* `/admin/login` — Administrative authentication & initial owner profile bootstrap
* `/admin` — Dealership operational dashboard (telemetry, inventory health, enquiry queue)
* `/admin/vehicles` — Vehicle inventory master list with lifecycle filters (`DRAFT`, `AVAILABLE`, `RESERVED`, `SOLD`, `ARCHIVED`)
* `/admin/vehicles/new` — Vehicle intake drafting with Zod validation
* `/admin/vehicles/[id]` — Vehicle record inspection, specifications editor, media manager, timeline log
* `/admin/enquiries` — Inbound prospective customer queue with status filter
* `/admin/enquiries/[id]` — Detailed enquiry review, vehicle reference, status workflow
* `/admin/settings` — Dealership operational settings and administrative preferences

## 4. Development & Build Scripts

```bash
npm run dev      # Start dev server on port 3000
npm run build    # Production Vite build
npm run lint     # Strict TypeScript verification (tsc --noEmit)
npm run preview  # Preview production build
```

## 5. Production Deployment & Supabase Integration (Phase 18)

### Supabase Remote Configuration
The application is configured to connect to remote Supabase project `zbjjdaajpautdhuulddj`:
* `VITE_SUPABASE_URL=https://zbjjdaajpautdhuulddj.supabase.co`
* `VITE_SUPABASE_ANON_KEY=sb_publishable_MBMu24SF-K5Vc4eXDMKWUg_7Qdfga7e`

### Deploying Database Migrations
All 12 validated schema migrations have been consolidated into `supabase/deploy_all_migrations.sql`:
1. In your **Supabase Dashboard** (`https://supabase.com/dashboard/project/zbjjdaajpautdhuulddj`), open the **SQL Editor**.
2. Paste the contents of `supabase/deploy_all_migrations.sql` and click **Run**.
3. This creates all enums, tables, RLS policies, storage buckets (`vehicle-images`, `vehicle-videos`), and the `initialize_first_admin()` helper.

### Vercel Deployment Configuration
The repository includes `vercel.json` configured for Vite SPA:
* **Framework:** `vite`
* **Build Command:** `npm run build`
* **Output Directory:** `dist`
* **Rewrites:** Client-side SPA route rewrites (`/(.*)` -> `/index.html`) ensuring direct deep linking works across `/cars`, `/about`, `/contact`, and `/admin/*`.

